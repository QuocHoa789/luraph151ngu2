# Changelog — V15.1 phase 7 (research-v7)

Baseline: research-v6. Verdict of the sample: PARTIAL (unchanged). V15 protected files: byte-identical.

## Fixed
* **Memory blow-up (kernel OOM-kill ≈6 GB)**: `table.unpack` of the register file with an infeasible range
  (`unpack(regs, 13, 13827)` from an operand of another record) materialised 13 800 `Reg` objects per visit. The range is
  now an `Unsupported` (unresolved) node, `DEVIRT_V151_MAX_UNPACK` (default 1024), recorded in `diagnostics.unpack_overflows`.
  (`engine.py` PATCHES + `engine_patch._v151_unpack_guard`.)
* **Return tables shared across caller contexts** (`retsite.py`): the token `LinkTok(reg, mode, entry)` is now
  `LinkTok(reg, mode, entry, ctx)` where `ctx` identifies the helper entry's non-link state; a return dispatch only
  contains the sites of callers with that context, so no (site of B, state of A) continuation is built.
  Knob `DEVIRT_V151_RETCTX=0` restores the old keying (ablation).
* Context bound is per helper entry (tuple of live link constants), not per register (product explosion).
* Deferred jump-register / pack-unstable discovery: one restart for all registers found within
  `DEVIRT_V151_DEFER_SLACK` states (`DEVIRT_V151_DEFER=0` = old behaviour).

## Added
* `cfg_stats.py`: bounded convergence diagnostics (states per instruction, which key component differs, predecessor histogram).
* `retsite.report`: `worklist_iterations`, `requeues`, `abstracted_entries`, `entry_contexts`, `return_sites_total`,
  `deferred_discoveries`, `helpers_below_bound`, `max_contexts_below_bound`; `walk_notes` and `unpack_overflows` in the diag JSON.
* Tests: `tests/test_v151_phase7.py` (21), `tests/test_v151_retsite.py` (23, now carries locals/packs through the fake VM).
* Docs: `V15.1-PHASE7.md`, `TEST-RESULTS-V15.1-phase7.md`, `research/phase7/` (metrics, logs, regenerated unlifted/nil reports, hashes).

## Not changed
`core/obfuscators/luraph_v15/{__init__,devirt,driver,vmmap}.py`, shared `core/{backend,codegen,structure,ir,luasym}.py`, installer/Termux setup.

## Known remaining
The proto-1 CFG still exceeds the 15 000-state walk limit (4 586 pending); no devirtualized output is emitted. See `V15.1-PHASE7.md` §10.

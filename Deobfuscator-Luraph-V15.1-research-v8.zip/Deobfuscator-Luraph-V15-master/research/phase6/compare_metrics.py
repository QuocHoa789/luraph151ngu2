#!/usr/bin/env python3
"""Baseline-vs-final metrics for the phase-6 report.  Every number is read from the artifacts of a real run
(`<out>.v151diag.json` + the pipeline log); nothing is estimated.

    python3 compare_metrics.py <baseline.v151diag.json> <baseline.log|-> <final.v151diag.json> <final.log> [out.json]

The two runs are measured with the SAME definitions (below).  Where a value is not present in an artifact
(e.g. the v5 baseline log was not kept) it is written as null, never filled in.
"""
import json
import re
import sys


def log_facts(path):
    f = {}
    if not path or path == "-":
        return f
    t = open(path, encoding="utf-8", errors="replace").read()
    m = re.findall(r"states explored: (\d+) kept, (\d+) in recovery", t)
    if m:
        f["states_kept"], f["states_recovery"] = int(m[-1][0]), int(m[-1][1])
    m = re.findall(r"most duplicated instruction: (\S+) reached in (\d+) distinct states \(distinct jump-register sets: (\d+), packs: (\d+), loop depths: (\d+)\)", t)
    if m:
        f["most_duplicated"] = {"pc": m[-1][0], "states": int(m[-1][1]), "jump_register_sets": int(m[-1][2]),
                                "packs": int(m[-1][3]), "loop_depths": int(m[-1][4])}
    m = re.findall(r"(\d+) blocks x (\d+) registers = (\d+) exceeds", t)
    if m:
        f["lowering_refused"] = {"blocks": int(m[-1][0]), "registers": int(m[-1][1]), "cells": int(m[-1][2])}
    m = re.findall(r"stop reason: (\w+)", t)
    if m:
        f["stop_reason"] = m[-1]
    m = re.findall(r"IR instructions: (\d+) state\(s\) in (\d+) walked function\(s\), (\d+) unlifted", t)
    if m:
        f["ir_states"], f["walked_functions"], f["unlifted_in_ir"] = map(int, m[-1])
    m = re.findall(r"unknown opcodes: (\d+) step", t)
    if m:
        f["unknown_opcode_steps"] = int(m[-1])
    m = re.findall(r"real\s+(\d+)m([\d.]+)s", t)
    if m:
        f["wall_seconds"] = int(m[-1][0]) * 60 + float(m[-1][1])
    m = re.findall(r"verdict: (\w+)", t)
    if m:
        f["verdict_line"] = m[-1]
    return f


def diag_facts(path):
    d = json.load(open(path, encoding="utf-8"))
    cl, cf, sm = d.get("closure") or {}, d.get("conformance") or {}, (d.get("diagnostics") or {}).get("summary") or {}
    tot = cf.get("total") or {}
    entered = cl.get("entered")
    return {
        "verdict": d.get("verdict"), "emit_source": d.get("emit_source"),
        "reasons": [r.get("code") for r in d.get("reasons", [])],
        "gate_unlifted_blocks": (d.get("metrics") or {}).get("unlifted_blocks"),
        "gate_nil_calls": (d.get("metrics") or {}).get("nil_calls"),
        "gate_unknown_opcode_steps": (d.get("metrics") or {}).get("unknown_opcode_steps"),
        "decode": (d.get("metrics") or {}).get("decode"),
        "diag_unlifted_blocks": sm.get("unlifted_blocks"), "diag_by_class": sm.get("by_class"),
        "diag_by_reason": sm.get("by_reason"), "diag_nil_calls": sm.get("nil_calls"),
        "diag_nil_by_kind": sm.get("nil_by_kind"),
        "runtime_entered_protos": entered, "runtime_entered_not_lifted": len(cl.get("entered_not_lifted") or []),
        "lifted_protos": cl.get("lifted"),
        "runtime_entered_lifted": (entered - len(cl.get("entered_not_lifted") or [])) if isinstance(entered, int) else None,
        "dangling_closure_edges": cl.get("dangling_edges"),
        "conformance_verdict": cf.get("verdict"), "conformance_ratio": cf.get("ratio"), "conformance_total": tot,
        "lift_stats": d.get("lift_stats"),
    }


def main(a):
    base = {"diag": diag_facts(a[0]), "log": log_facts(a[1])}
    fin = {"diag": diag_facts(a[2]), "log": log_facts(a[3])}
    out = {"definitions": {
        "gate_*": "validator measurement over the lifted functions (None = the lift stopped before the measurement existed)",
        "diag_*": "records of the walks that ran (diagnostics.DIAG); counts only walked functions, so a run that walks "
                  "fewer functions is NOT comparable with one that walks more -- see walked_functions",
        "runtime_entered_*": "protos the harness' real run entered (trace oracle) vs protos with a lifted walk",
        "conformance": "replay of the real step trace through the lifted CFG (ok/fail/nosrc/entry_ok/entry_fail)"},
        "baseline_v5": base, "final": fin}
    if len(a) > 4:
        json.dump(out, open(a[4], "w"), indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main(sys.argv[1:])

import sys,time,collections,os,pickle
sys.path.insert(0,"/home/claude/proj/dev/core")
from backend import run_big_stack
from obfuscators.luraph_v15_1 import devirt as D, engine_patch as EP, retsite as RS
E=D._E
S="/tmp/claude-0/-home-claude/c8a2874a-b281-53f3-8be4-e4741a52399e/scratchpad/r14"
def walk_node(n,ind=1,out=None):
    out=out if out is not None else []
    if n is None: return out
    for s in n.stmts: out.append("  "*ind+E.fmt_stmt(s))
    if n.cond is not None:
        out.append("  "*ind+"if %s (decided=%s)"%(E.fmt_expr(n.cond),getattr(n,'decided','-')))
        walk_node(n.then,ind+1,out); out.append("  "*ind+"else"); walk_node(n.els,ind+1,out)
    else:
        oc=n.outcome
        if isinstance(oc,E.Next): out.append("  "*ind+"-> Next %s:%s jr=%s locs=%s"%(oc.state.mode,E.fmt_any(oc.state.pc),oc.state.jregs,oc.state.locs))
        else: out.append("  "*ind+"-> "+type(oc).__name__)
    return out

ACC={}
_ostep=E.V151Stepper.step
def _step_rec(self,state,tprefix):
    try:
        return _ostep(self,state,tprefix)
    finally:
        try:
            acc=getattr(self,"_last_acc",None)
            lf=self.lf
            kl=self.key_locals
            kk=state.key(self.vm.kstack_link)
            ACC[kk]={"kread":frozenset(str(k) for k in (acc.reads_first if acc is not None else ()) if k in kl),
                     "kwrit":frozenset(str(k) for k in (acc.written if acc is not None else ()) if k in kl),
                     "jread":frozenset(getattr(lf,"jread",()) or ()),
                     "kcons":frozenset(getattr(lf,"kconsumed",()) or ()),
                     "keyloc":tuple(sorted(str(k) for k in kl)),
                     "op":tuple(lf.last_op) if getattr(lf,"last_op",None) else None,
                     "ovpc":tuple(sorted((repr(k),repr(v)[:40]) for k,v in (lf.ov.d.items() if getattr(lf,"ov",None) is not None else []) if isinstance(k,tuple) and len(k)==2 and k[1]==state.pc))[:6]}
        except Exception as ex:
            ACC.setdefault("_err",[]).append(repr(ex)[:100])
E.V151Stepper.step=_step_rec
_ow=E.Program._walk
def _w(self,vm,lf,st,limit):
    t=time.time(); r=_ow(self,vm,lf,st,limit); info=r[1].info
    print("WALK",len(r[1]),"restart",r[2],info.get("restart"),info.get("final_stop"),"link",sorted(getattr(lf,'link_regs',()) or ()),round(time.time()-t,1),flush=True)
    return r
E.Program._walk=_w
def main():
    prog=E.Program("sample/v15.1/sa-obfuscated.lua.txt",S+"/out.lua.protos.json",[])
    key=sys.argv[1]
    cap=prog.dump.protos[key]
    vm=prog.vm_of(cap); proto=vm.proto_of(cap)
    lf=E.ProtoLifter(vm,prog.dump,vm.vmobj_of(cap),proto,E.UpList(),prog.globals)
    st=E.make_stepper(vm,lf)
    t0=time.time()
    s0,order,_=prog.walk_fixpoint(vm,lf,st,E.WALK_LIMIT)
    info=order.info
    print("DONE walk",len(order),info.get("final_stop"),"closed",info.get("closed"),"pending",info.get("pending"),round(time.time()-t0,1),flush=True)
    from obfuscators.luraph_v15_1 import cfg_stats as CS
    import json
    print("CFGSTATS",json.dumps(CS.summary(order,5),default=str),flush=True)
    ks13=[k for k,_ in order if (k[0],k[1])==(239,13794)]
    regs=collections.defaultdict(set)
    for k in ks13:
        for r,v in k[3]: regs[r].add(v if not hasattr(v,"ctx") else ("tok",v.reg,v.entry,v.ctx))
    print("J13794 per-register distinct values:",{r:len(v) for r,v in sorted(regs.items())},flush=True)
    for r,v in sorted(regs.items()): print("   r%s"%r,sorted(map(str,v))[:8],flush=True)
    print("J13794 distinct (packs):",len({k[5] for k in ks13}),"locs:",len({k[6] for k in ks13}),"ov:",len({k[4] for k in ks13}),"depth:",len({k[2] for k in ks13}),flush=True)
    print("J13794 distinct jr-without-62:",len({tuple((r,v) for r,v in k[3] if r!=62) for k in ks13}),flush=True)
    rep=RS.report(lf); print("RETSITE",json.dumps({a:b for a,b in rep.items() if a!="helpers"}),flush=True); print("HELPERS",len(rep["helpers"]),flush=True)

    import json
    link=vm.kstack_link
    keyidx={k:i for i,(k,_) in enumerate(order)}
    nodes=dict(order)
    # liveness of decode-key locals over the explored graph (unexplored successor => all live)
    names=None
    for v in ACC.values():
        if isinstance(v,dict): names=v["keyloc"]
    names=list(names or ())
    succ={}
    unknown=set()
    for k,n in order:
        ss=[]
        for ns in E._node_successors(n):
            try: kk=ns.key(link)
            except Exception: unknown.add(k); continue
            if kk in nodes: ss.append(kk)
            else: unknown.add(k)
        if getattr(n,"error",None): unknown.add(k)
        succ[k]=ss
    live={k:set() for k in nodes}
    for k in unknown: live[k]=set(names)
    changed=True; it=0
    while changed and it<200:
        changed=False; it+=1
        for k in nodes:
            a=ACC.get(k)
            if a is None: new=set(names)
            else:
                out=set()
                for t in succ[k]: out|=live[t]
                new=set(a["kread"])|(out-set(a["kwrit"]))
            new|=live[k] if k in unknown else set()
            if new!=live[k]: live[k]=new; changed=True
    print("LIVENESS iterations",it,"key locals",names,"unknown(unexplored/error) states",len(unknown),flush=True)
    def proj(k):
        keys=k[-2]; lv=live[k]
        return tuple((str(a),b if str(a) in lv else "DEAD") for a,b in keys)
    byp=collections.defaultdict(list)
    for k in nodes: byp[(k[0],k[1])].append(k)
    raw=len(nodes); projd=len({(k[:-2]+(proj(k),)+k[-1:]) for k in nodes})
    print("LIVEPROJ states raw",raw,"after projecting dead decode keys",projd,flush=True)
    top=sorted(byp.items(),key=lambda kv:-len(kv[1]))[:6]
    for (m,pc),ks in top:
        rawk=len({k[-2] for k in ks}); pk=len({proj(k) for k in ks})
        rd=sorted({x for k in ks for x in (ACC.get(k) or {}).get("kread",())}); wr=sorted({x for k in ks for x in (ACC.get(k) or {}).get("kwrit",())})
        lvs=sorted({x for k in ks for x in live[k]})
        print("PC",m,pc,"states",len(ks),"distinct keys",rawk,"after dead-key projection",pk,"| step reads-first",rd,"writes",wr,"live-in union",lvs,flush=True)

    for pc_ in range(9260,9270):
        ops=collections.Counter(); ovs=collections.Counter()
        for k in nodes:
            if k[0]==239 and k[1]==pc_ and k in ACC:
                if k[2]==0 or True:
                    ops[ACC[k]["op"]]+=1; ovs[ACC[k]["ovpc"]]+=1
        print("OPSAT",pc_,dict(ops.most_common(4)),"OV",dict(list(ovs.most_common(2))),flush=True)

    from obfuscators.luraph_v15_1 import engine_patch as _EP
    wr=_EP.DIAG.writes
    print("WRITES total keys",len(wr),"nwrites",_EP.DIAG.nwrites,flush=True)
    for (pk,idx),slot in sorted(wr.items(),key=lambda kv:(str(kv[0][0]),kv[0][1])):
        if 9261<=idx<=9265:
            print("WRITE",pk,idx,json.dumps({a:[(str(x.get("writer")),str(x.get("old"))[:20],str(x.get("new"))[:20]) for x in v] for a,v in slot.items()},default=str)[:6000],flush=True)
    print("ACC errors",ACC.get("_err",[])[:3],flush=True)
    # representative differing components at 239:13794
    ks13=byp.get((239,13794),[])
    def tokrepr(v): return ("tok%s#%s"%(v.reg,v.ctx)) if hasattr(v,"ctx") else ("int" if isinstance(v,int) else str(v)[:20])
    nk=len({k[-2] for k in ks13}); npk=len({k[5] for k in ks13}); njr=len({k[3] for k in ks13})
    print("XTAB 13794 states",len(ks13),"keys",nk,"packs",npk,"jregs",njr,"keys x packs",len({(k[-2],k[5]) for k in ks13}),"keys x packs x nonlink-jr",len({(k[-2],k[5],tuple((r,tokrepr(v)) for r,v in k[3] if r not in(3,4,6,41,62))) for k in ks13}),flush=True)
    cnt=collections.Counter(tuple(sorted((r,"int" if isinstance(v,int) else "tok") for r,v in k[3])) for k in ks13)
    print("XTAB jr shapes",dict(cnt.most_common(6)),flush=True)
    print("XTAB pack regs per state",collections.Counter(tuple(r for r,_ in k[5]) for k in ks13).most_common(5),flush=True)
    ks=byp.get((239,13794),[])
    def comp_diff(a,b):
        names_=("mode","pc","depth","jregs","ov","packs","locs","keys","kvals")
        d={}
        for i,nm in enumerate(names_):
            if i<len(a) and i<len(b) and a[i]!=b[i]:
                if nm in("jregs","keys","kvals","locs"):
                    da=dict((str(x),y) for x,y in a[i]); db=dict((str(x),y) for x,y in b[i])
                    d[nm]={r:(str(da.get(r))[:40],str(db.get(r))[:40]) for r in sorted(set(da)|set(db)) if da.get(r)!=db.get(r)}
                else: d[nm]="differs"
        return d
    for i in range(0,min(len(ks)-1,12),3):
        print("PAIRDIFF",json.dumps(comp_diff(ks[i],ks[i+1]),default=str)[:700],flush=True)
    byk=collections.Counter((k[0],k[1]) for k,_ in order)
    print("top dup",byk.most_common(8))
    dep=collections.Counter()
    nodes=dict(order)
    for k,_ in order:
        dep[(k[0],k[1])]
    for spec in os.environ.get("INSPECT","").split(","):
        if not spec: continue
        m,pc=map(int,spec.split(":"))
        ks=[k for k,_ in order if k[0]==m and k[1]==pc]
        print("INSPECT",spec,len(ks),"states; depths",sorted(set(k[2] for k in ks))[:10],"...",max((k[2] for k in ks),default=None))
        for k in ks[:3]:
            print(" key depth",k[2],"jr",k[3],"locs",k[6])
            print("\n".join(walk_node(nodes[k])))
            ks_=nodes[k]
            def _oc(n,acc):
                if n is None: return
                if n.cond is not None: _oc(n.then,acc); _oc(n.els,acc)
                elif isinstance(n.outcome,E.Next): acc.append(n.outcome.state)
            acc=[]; _oc(ks_,acc)
            for st_ in acc:
                kk=st_.kstack
                print("   OUT kstack type",type(kk).__name__, (kk.__dict__ if hasattr(kk,"__dict__") else None) if not hasattr(kk,"h") else {a:(type(b).__name__,E.fmt_any(b) if not hasattr(b,"h") else "LTable") for a,b in kk.h.items()}, "locs",st_.locs)
            p=prog.pred.get(k); n=0
            while p is not None and n<4:
                print("   pred",p[0],p[1],"depth",p[2],"jr",p[3]); p=prog.pred.get(p); n+=1
    rep=RS.report(lf); print("helpers",len(rep["helpers"]),"calls",rep["call_transfers"],"rebuilds",rep["dispatch_rebuilds"])
run_big_stack(main)

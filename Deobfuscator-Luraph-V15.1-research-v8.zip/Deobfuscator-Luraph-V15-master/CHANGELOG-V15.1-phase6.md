# Changelog — V15.1 phase 6 (package `research-v6`, baseline `research-v5`)

V15 files `core/obfuscators/luraph_v15/{__init__,devirt,driver,vmmap}.py` are byte-identical to v5
(see `research/phase6/v15_protected_hashes.txt`). Shared `core/{backend,codegen,structure,ir,luasym}.py` are unchanged too.

## Added
* `core/obfuscators/luraph_v15_1/retsite.py` — return-site abstraction for outlined helpers that return through a
  register (`pc = r ± c`): the helper body is keyed by its *entry*, the return is a dispatch over the recorded return
  sites. Context-sensitivity bound (`DEVIRT_V151_RETSITE_MIN`, default 12): a helper with at most that many distinct
  return addresses keeps the engine's exact per-return-address cloning; only helpers that exceed it are abstracted.
  Switch off completely with `DEVIRT_V151_RETSITE=0`.
* `engine_patch.py`: hook `_v151_successors` (inserted through the existing exactly-once patch mechanism in `engine.py`),
  walk-knowledge persistence across walk restarts (`DEVIRT_V151_PERSIST`, default on), loop-stack depth widening
  (`DEVIRT_V151_DEPTH_WIDEN`, default off — see V15.1-PHASE6.md for the measurement), lowering-block ceiling
  (`DEVIRT_LOWER_BLOCKS`), `MemoryError` guard in the lowering.
* `diag_report.py` — machine-readable reports `<out>.v151-unlifted-blocks.json` (one entry per reachable unlifted block,
  with exit class, predecessors/successors, register facts, operands, runtime reachability, root-cause class and a
  proposed fix that is marked `LEAD_NOT_VERIFIED`) and `<out>.v151-nil-calls.json` (one entry per nil call, grouped by
  root cause, validity classified from the real trace; the observed runtime value is `NOT_CAPTURED` because the trace
  keeps (array, pc, opcode) only).
* `diagnostics.py`: new classes `UNKNOWN_RETURN_CONTINUATION`, `RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW`.
* `src/platform.js`: `launchCheck` (ABSENT / WRONG_FORMAT / CANNOT_LAUNCH / LAUNCHES) and `parseCheck` (OK / PARSE_FAILS).
* Tests: `tests/test_v151_retsite.py` (19, synthetic), `tests/test_v151_phase6.py` (27), 9 new cases in `tests/test_platform.js`.
* `research/phase6/compare_metrics.py` — baseline-vs-final metrics from the real artifacts.

## Fixed (found by the phase-6 tests, not by the report)
* The first version of the abstraction was applied to every helper and made proto 11 non-conformant (decode-key locals
  were not discovered: 31 instead of 75 pcs, 1 of 4 key locals). The dump-based replay test caught it; the
  context-sensitivity bound is the fix. `WRONG_BRANCH_TARGET` had no proposed fix in the diagnostic table.

## Not changed / limits
* See `V15.1-PHASE6.md` §4–§6 for what remains open on the real sample.

# Test results — V15.1 phase 8 (actual runs of the final source tree, logs in research/phase8/logs/)

| Suite | Command | Result | Log |
|---|---|---|---|
| phase 8 (helper summaries, scrub equivalence) — synthetic | `python3 -m unittest tests.test_v151_phase8` | **19 OK** | test_test_v151_phase8.log |
| phase 8b (path-sensitive overlay, structural identity, self-modifying helper, state diff) — synthetic | `python3 -m unittest tests.test_v151_phase8b` | **19 OK** | test_test_v151_phase8b.log |
| phase 8c (helper boundary effects, unknown semantics, resource limits, worklist order, protected files, verdicts) | `python3 -m unittest tests.test_v151_phase8c` | **16 OK** | test_test_v151_phase8c.log |
| retsite / phase 7 / phase 6 (regression) | `python3 -m unittest tests.test_v151_retsite tests.test_v151_phase7 tests.test_v151_phase6` | **23 + 23 + 27 OK** | test_test_v151_retsite.log, …phase7.log, …phase6.log |
| devirt recovery | `python3 -m unittest tests.test_devirt_recovery` | **9 OK** | test_test_devirt_recovery.log |
| round 2 with the real dump (incl. proto-11 conformance replay) | `DEOB_V151_DUMP=…/out.lua.protos.json python3 -m unittest tests.test_v151_round2` | **25 OK** (16.6 s) | test_test_v151_round2.log |
| core V15.1 + V15 regression | `DEOB_V151_DUMP=… DEOB_V15_BASELINE=… DEOB_V15_REFERENCE=… python3 -m unittest tests.test_v151` | **22 OK, 1 skipped** (end-to-end needs `DEOB_E2E`) | test_test_v151.log |
| Node platform | `node tests/test_platform.js` | **18 passed** | test_platform.log |
| native tools | `bin/luau`, `bin/luau-ast` executed (x86-64 Linux ELF) | print/exit 0; AST dump exit 0; syntax-error control exit 1 with parse error from both; `.exe` not run | native_tools.log |
| full pipeline, final tree | `DEVIRT_WALK_LIMIT=15000 DEVIRT_PLATEAU=300000 DEVIRT_V151_KVALS=0 node deob.js sample/v15.1/sa-obfuscated.lua.txt -o … --debug --debug-v151` | exit 0, verdict **PARTIAL** (`LIFT_BUDGET_EXHAUSTED`) | pipeline_final.log |

Positive / negative controls (state-merge and summary tests come in pairs): overlay identity (same content other order merges /
different cell differs / structurally equal `Reg` merges / different `Reg` differs); path-sensitive proxy (reads follow the
state's overlay / the global merge is a no-op); self-modifying helper (summary applied after the decode / **not** applied to a
path that did not decode); decode-key change inside a helper (impure) vs unchanged keys (pure); scrub equivalence in both
directions vs a non-decryptor opcode (fails); resource ceiling (partial) vs enough budget (closed).

A regression found and fixed in this phase by `tests.test_v151_round2…test_real_run_replays_through_the_lift`: with the
path-sensitive overlay a later activation of proto 11 sees a decoded cell (scrub no-op) where the lift (first activation) has the
decryptor; the conformance check now treats this pair as equivalent in both directions (reported as `ok_scrub_equivalent`).
Ablation of that fix: with `DEVIRT_V151_PATHOV=0` the test passes without it; with it on and the fix removed it failed
(147 failures at (73,67,76)→(97,27,24); observed in this session, the log of that failing run was overwritten by the passing re-run).

Synthetic tests prove properties of the abstractions on a miniature VM; they are not evidence that the real sample lifts.
Not run: Android / Termux (no device).

# Test results — V15.1 round 2

| suite | command | result |
|---|---|---|
| Python round 1 (+ dump-based, V15 regression) | `DEOB_V151_DUMP=<traced dump> DEOB_V15_BASELINE=<RideAPet baseline> python3 tests/test_v151.py` | 22 tests OK (skipped 2: needs original tree) |
| Python round 2 (validator, conformance, data flow, diagnostics, resource guards, key-carry, dump replay) | `DEOB_V151_DUMP=<dump> python3 tests/test_v151_round2.py` | 25 tests OK (without dump: 25 run / 2 skipped) |
| V15 devirt recovery | `python3 -m unittest tests.test_devirt_recovery` | 9 OK |
| Node platform / Termux | `node tests/test_platform.js` | 9 passed |
| V15 regression | RideAPet through `deob.js` vs v4 baseline | **byte-identical** |
| V15 files | `diff -r` of `core/obfuscators/luraph_v15`, `core/backend.py`, `core/codegen.py`, `core/structure.py`, `src/vmmap.js` vs the v4 ZIP | **identical** |
| V15.1 E2E | `DEOB_E2E=1 python3 tests/test_v151.py EndToEnd` (~33 min) | OK — verdict **PARTIAL** (unlifted 46, nil calls 119, unknown-opcode steps 358); no `.devirt.luau` written; PARTIAL asserted != PASS |

The E2E test asserts honesty, not success: it fails if PASS is reported with unlifted blocks/nil calls, or if source is
emitted without PASS. **The V15.1 sample is not devirtualized (PARTIAL).**

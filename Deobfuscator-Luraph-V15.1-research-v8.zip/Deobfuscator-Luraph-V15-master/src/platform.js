'use strict';
// Native runtime checks (round 2, phase 11).
//
// The dynamic harness needs a *native* Luau (`bin/luau`, `bin/luau-ast`).  On Termux/Linux a
// Windows build (PE, starts with "MZ") or an ELF built for another CPU cannot run.  This module
// looks at the file itself (magic bytes + e_machine), never at its name, and answers with a
// verdict-shaped object so the caller can report BLOCKED instead of crashing or faking a run.

const fs = require('fs');

// ELF e_machine values
const EM = { x64: 62, arm64: 183, arm: 40, ia32: 3 };

function readHead(file, n) {
  const fd = fs.openSync(file, 'r');
  try {
    const buf = Buffer.alloc(n);
    const got = fs.readSync(fd, buf, 0, n, 0);
    return buf.subarray(0, got);
  } finally {
    fs.closeSync(fd);
  }
}

// -> { kind: 'ELF'|'PE'|'SCRIPT'|'UNKNOWN'|'MISSING', machine?, bits?, littleEndian? }
function inspectBinary(file) {
  if (!file || !fs.existsSync(file)) return { kind: 'MISSING' };
  let h;
  try { h = readHead(file, 64); } catch (e) { return { kind: 'MISSING', error: String(e.message || e) }; }
  if (h.length >= 20 && h[0] === 0x7f && h[1] === 0x45 && h[2] === 0x4c && h[3] === 0x46) {
    const le = h[5] === 1;
    const machine = le ? h.readUInt16LE(18) : h.readUInt16BE(18);
    return { kind: 'ELF', bits: h[4] === 2 ? 64 : 32, littleEndian: le, machine };
  }
  if (h.length >= 2 && h[0] === 0x4d && h[1] === 0x5a) return { kind: 'PE' };
  if (h.length >= 2 && h[0] === 0x23 && h[1] === 0x21) return { kind: 'SCRIPT' };
  return { kind: 'UNKNOWN' };
}

// Is `info` runnable on (platform, arch)?  -> { ok, reason }
function runnableOn(info, platform = process.platform, arch = process.arch) {
  if (info.kind === 'MISSING') return { ok: false, reason: 'the file does not exist' };
  if (platform === 'win32') {
    return info.kind === 'PE' ? { ok: true } : { ok: false, reason: `expected a Windows executable (PE), found ${info.kind}` };
  }
  if (info.kind === 'PE') {
    return { ok: false, reason: 'it is a Windows executable (PE, "MZ"); it cannot run on ' + platform + '/' + arch };
  }
  if (info.kind === 'SCRIPT') return { ok: true };   // a wrapper script; its target is checked when it runs
  if (info.kind !== 'ELF') return { ok: false, reason: 'it is not an executable for ' + platform };
  const want = EM[arch];
  if (want !== undefined && info.machine !== want) {
    const name = Object.keys(EM).find((k) => EM[k] === info.machine) || ('e_machine ' + info.machine);
    return { ok: false, reason: `it was built for ${name} but this device is ${arch}` };
  }
  return { ok: true };
}

// Verdict-shaped runtime status for the validator: { available, reason, tools: {...} }
function checkRuntime(tools, platform = process.platform, arch = process.arch) {
  const out = { available: true, reason: null, platform, arch, tools: {} };
  const problems = [];
  for (const [name, file] of Object.entries(tools)) {
    const info = inspectBinary(file);
    const r = runnableOn(info, platform, arch);
    out.tools[name] = { file, kind: info.kind, ok: r.ok, reason: r.reason || null };
    if (!r.ok) problems.push(`${name}: ${r.reason}`);
  }
  if (problems.length) {
    out.available = false;
    out.reason = 'no usable native Luau runtime (' + problems.join('; ') + ')' +
      (platform === 'win32' ? '' : '. Run ./install-termux.sh (it builds or copies a native build); a Windows .exe cannot be used here');
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
// Launch / parse probes (phase 6, section 10).  Four different failures are kept apart:
//   ABSENT              no such file
//   WRONG_FORMAT        a file that cannot run here (PE on Linux/Android, ELF for another CPU)
//   CANNOT_LAUNCH       the file looks runnable but starting it fails (permissions, loader, signal)
//   PARSE_FAILS         it launches but does not parse a trivial chunk correctly
//   OK                  launches and parses
// A missing or broken native tool is BLOCKED for the verdict; it is never a devirtualization result.
const cp = require('child_process');
const os = require('os');
const path = require('path');

function launchCheck(file, args = ['--version'], timeoutMs = 10000) {
  const info = inspectBinary(file);
  if (info.kind === 'MISSING') return { state: 'ABSENT', detail: 'the file does not exist' };
  const fit = runnableOn(info);
  if (!fit.ok) return { state: 'WRONG_FORMAT', detail: fit.reason, info };
  const r = cp.spawnSync(file, args, { timeout: timeoutMs, encoding: 'utf8' });
  if (r.error) return { state: 'CANNOT_LAUNCH', detail: String(r.error.code || r.error.message), info };
  if (r.signal) return { state: 'CANNOT_LAUNCH', detail: 'killed by ' + r.signal, info };
  // a tool that starts (any exit code) has launched; whether it works is the parse probe's business
  return { state: 'LAUNCHES', exitCode: r.status, stdout: (r.stdout || '').slice(0, 200), stderr: (r.stderr || '').slice(0, 200), info };
}

// Parse a trivial Luau chunk with `luau-ast` (prints JSON) and check the structure.
function parseCheck(astFile, timeoutMs = 10000) {
  const l = launchCheck(astFile, ['--help'], timeoutMs);
  if (l.state !== 'LAUNCHES') return l;
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v151-parse-'));
  const src = path.join(dir, 'probe.lua');
  try {
    fs.writeFileSync(src, 'local x = 1\nreturn x + 1\n');
    const r = cp.spawnSync(astFile, [src], { timeout: timeoutMs, encoding: 'utf8', maxBuffer: 1 << 24 });
    if (r.error || r.signal) return { state: 'CANNOT_LAUNCH', detail: String((r.error && r.error.message) || r.signal) };
    let ok = false;
    try { const j = JSON.parse(r.stdout); ok = !!j && JSON.stringify(j).includes('AstStatReturn'); } catch (e) { ok = false; }
    return ok ? { state: 'OK', exitCode: r.status } : { state: 'PARSE_FAILS', exitCode: r.status, stderr: (r.stderr || '').slice(0, 200) };
  } finally {
    try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* ignore */ }
  }
}

module.exports = { inspectBinary, runnableOn, checkRuntime, launchCheck, parseCheck, EM };

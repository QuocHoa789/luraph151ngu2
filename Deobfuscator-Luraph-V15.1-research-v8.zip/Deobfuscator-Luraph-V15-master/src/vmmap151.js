'use strict';
// Luraph v15.1 mapper: the AST analysis lives in Python
// (core/obfuscators/luraph_v15_1/vmmap.py); this module only shells out to it.
// v15 and v14 keep using vmmap.js / vmmap14.js untouched.

const path = require('path');
const { execFileSync } = require('child_process');
const base = require('./vmmap');
const { getPythonBin } = require('./pyenv');

const CORE_DIR = path.join(__dirname, '..', 'core');
const PY_VMMAP = path.join(CORE_DIR, 'obfuscators', 'luraph_v15_1', 'vmmap.py');

function patchEntries(source, filePath, chunkTag) {
  const out = execFileSync(getPythonBin(), [PY_VMMAP, filePath, '--patch', chunkTag], {
    env: Object.assign({}, process.env, { PYTHONPATH: CORE_DIR }),
    maxBuffer: 1024 * 1024 * 1024,
    encoding: 'latin1',
  });
  return out;
}

function debugSummary(filePath) {
  return execFileSync(getPythonBin(), [PY_VMMAP, filePath], {
    env: Object.assign({}, process.env, { PYTHONPATH: CORE_DIR }),
    encoding: 'latin1',
  });
}

// Execution-trace oracle (--debug-v151): one record per VM dispatch step,
//   aid*2^40 + TAG*2^34 + pc*2^10 + opcode
// aid = per-run id of the instruction array table (identifies the proto), TAG = index of the
// loop in source order.  Table operations only; no calls.
// DEOB_V151_TRACE_KEYS="TAG:OP,OP:KEYLOCAL" (diagnostic, off by default) additionally appends, for
// every dispatch step of loop TAG whose opcode is one of OP, one record 2^52 + (KEYLOCAL & 0xFFFFFFFF):
// the decode-key local the handler is about to read.  trace_oracle keeps those in `keyrecs` (they are
// not dispatch steps) so a lifted key can be compared with the real one at the same step.
function patchTrace(src) {
  let tag = 0;
  const kspec = (process.env.DEOB_V151_TRACE_KEYS || '').split(':');
  const ktag = kspec.length === 3 ? parseInt(kspec[0], 10) : -1;
  const kops = kspec.length === 3 ? kspec[1].split(',').map((x) => parseInt(x, 10)) : [];
  const kname = kspec.length === 3 ? kspec[2] : '';
  return src.replace(
    /while true do (?:local )?([A-Za-z_]+)=([A-Za-z_]+)\[([A-Za-z_]+)\];/g,
    (m, op, arr, pc) => {
      const t = tag++;
      let extra = '';
      if (t === ktag && kops.length && /^[A-Za-z_]+$/.test(kname)) {
        const cond = kops.map((o) => `${op}==${o}`).join(' or ');
        extra = `if ${cond} then __VT.n=__VT.n+1;__VT[__VT.n]=4503599627370496+(type(${kname})=="number" and ${kname}%4294967296 or 4294967295) end;`;
      }
      return m + `if __VT and __VT.n<3000000 then local a=__VT.ids[${arr}];if not a then __VT.na=__VT.na+1;a=__VT.na;__VT.ids[${arr}]=a end;__VT.n=__VT.n+1;__VT[__VT.n]=a*1099511627776+${t}*17179869184+${pc}*1024+${op};${extra}end;`;
    }
  );
}

module.exports = Object.assign({}, base, { patchEntries, debugSummary, patchTrace });

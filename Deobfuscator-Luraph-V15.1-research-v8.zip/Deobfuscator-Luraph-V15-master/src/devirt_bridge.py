import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CORE_DIR = os.path.join(HERE, "..", "core")
if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

from backend import run_big_stack


def _profile_name(obfuscator=""):
    s = str(obfuscator or "").strip().lower().replace("-", "_")
    if "v15.1" in s or "v151" in s or "v15_1" in s:
        return "luraph_v15_1"
    if "v14" in s:
        return "luraph_v14"
    return "luraph_v15"

def engine_for(obfuscator="", env=None):
    forced = (env or os.environ).get("DEOB_ENGINE")
    profile = forced if forced in ("v14", "v15", "v15_1") else _profile_name(obfuscator)
    if profile == "v14":
        from obfuscators.luraph_v14 import devirt
        return devirt
    if profile == "luraph_v15_1" or profile == "v15_1":
        from obfuscators.luraph_v15_1 import devirt
        return devirt
    from obfuscators.luraph_v15 import devirt
    return devirt


cmd = sys.argv[1]

if cmd == "collect":
    source_path = sys.argv[2]
    protos_path = sys.argv[3]
    chunk_paths = sys.argv[4:]
    obfuscator = chunk_paths.pop() if chunk_paths and chunk_paths[-1].startswith('luraph_') else ''
    devirt = engine_for(obfuscator)
    stats, reqs, bufs = run_big_stack(
        devirt.collect_requests, source_path, protos_path, chunk_paths
    )
    result = {
        "stats": stats,
        "requests": sorted(list(reqs)),
        "bufs": bufs,
    }
    print(json.dumps(result))

elif cmd == "lift":
    source_path = sys.argv[2]
    protos_path = sys.argv[3]
    out_path = sys.argv[4]
    chunk_paths = sys.argv[5:]
    obfuscator = chunk_paths.pop() if chunk_paths and chunk_paths[-1].startswith('luraph_') else ''
    devirt = engine_for(obfuscator)
    text_out, stats, reqs, bufs = run_big_stack(
        devirt.lift_program, source_path, protos_path, chunk_paths
    )
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(devirt.finish_text(text_out) + "\n")
    print(json.dumps({
        "stats": stats,
        "requests": sorted(list(reqs)),
        "bufs": bufs,
        "output": out_path,
    }))

elif cmd == "pipeline":

    config_file = sys.argv[2]
    with open(config_file, "r", encoding="utf-8") as f:
        c = json.load(f)

    from obfuscators.base import Job
    import harness
    profile = _profile_name(c.get('obfuscator'))
    if profile == 'luraph_v14':
        from obfuscators.luraph_v14 import driver
    elif profile == 'luraph_v15_1':
        from obfuscators.luraph_v15_1 import driver
    else:
        from obfuscators.luraph_v15 import driver

    class DummyArgs:
        def __init__(self, d):
            for k, v in d.items():
                setattr(self, k, v)

    args = DummyArgs(c["args"])
    job = Job(c["input"], c["source"], args, c["trace_path"], c["debug"], c["obfuscator"])
    job.source_path = c["source_path"]
    job.credit_header = lambda: ""

    runner = harness.Runner(job)
    runner.luau = c["luau_exe"]

    driver.lift(
        job,
        runner,
        c["patched"],
        c["cfg"],
        c.get("chunks", {}),
        c["run_text"],
        c["ppath"],
        c["dpath"],
        c.get("chunk_paths", []),
    )
    runner.finish()

    if profile == 'luraph_v15_1' and os.environ.get("DEOB_DEBUG_V151"):
        try:
            from obfuscators.luraph_v15_1 import debug_report, engine_patch
            for ln in debug_report.report_lines(c["source_path"], c["ppath"], engine_patch):
                print(ln, file=sys.stderr)
        except Exception as ex:                       # diagnostics must never fail the run
            print("[V15.1] report failed: %s: %s" % (type(ex).__name__, ex), file=sys.stderr)

    dpath = c["dpath"]
    if os.path.exists(dpath):
        with open(dpath, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        clean = []
        skip_header = True
        for line in lines:
            stripped = line.strip()
            if skip_header and (
                stripped.startswith("-- Deobfuscated by") or
                stripped.startswith("-- Detected obfuscation") or
                stripped.startswith("-- Local names are inferred") or
                stripped.startswith("-- source:") or
                stripped.startswith("-- NOTE: reconstructed") or
                stripped.startswith("--       during the trace")
            ):
                continue
            if skip_header and stripped == "":
                continue
            skip_header = False
            clean.append(line)
        with open(dpath, "w", encoding="utf-8", newline="\n") as f:
            f.writelines(clean)

    if os.path.exists(c["dpath"]):
        print(json.dumps({"success": True, "output": c["dpath"]}))
    else:   # V15.1 gate: PARTIAL / BLOCKED / FAIL emit no source (evidence is in the .v151-report.txt)
        print(json.dumps({"success": False, "output": None, "reason": "no devirtualized source emitted (validator verdict is not PASS)"}))

elif cmd == "debug151":
    from obfuscators.luraph_v15_1 import debug_report
    for ln in debug_report.report_lines(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None):
        print(ln, file=sys.stderr)

else:
    sys.exit(f"Unknown command: {cmd}")

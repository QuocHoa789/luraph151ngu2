#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

die() { echo "[!] $*" >&2; exit 1; }

# A native tool must be an ELF executable for THIS CPU. A Windows build
# (PE32+, starts with "MZ": luau.exe) or an ELF built for another architecture
# (x86-64 binary on an aarch64 phone) cannot run on Termux, so it is rebuilt.
native_ok() {
  f="$1"
  [ -f "$f" ] || return 1
  [ "$(head -c4 "$f" | od -An -tx1 | tr -d ' \n')" = "7f454c46" ] || return 1
  want=""
  case "$(uname -m)" in
    aarch64|arm64) want="b700" ;;
    x86_64|amd64)  want="3e00" ;;
    armv7*|armv8l|arm) want="2800" ;;
    i686|i386)     want="0300" ;;
  esac
  [ -z "$want" ] && return 0
  [ "$(head -c20 "$f" | tail -c2 | od -An -tx1 | tr -d ' \n')" = "$want" ]
}

echo "[1/5] Installing Termux packages..."
pkg update -y
pkg install -y nodejs python git clang cmake make unzip
command -v node >/dev/null 2>&1 || die "node is not installed (pkg install nodejs)"
command -v npm  >/dev/null 2>&1 || die "npm is not installed (pkg install nodejs)"
command -v python3 >/dev/null 2>&1 || die "python3 is not installed (pkg install python)"
echo "[OK] node $(node --version), npm $(npm --version), python $(python3 --version 2>&1)"

echo "[2/5] Installing Discord bot dependency..."
cd "$ROOT/bot"
npm install --omit=dev
cd "$ROOT"

build_luau() {
  if [ ! -d "$HOME/luau/.git" ]; then
    echo "[+] Cloning Luau source..."
    git clone --depth 1 https://github.com/luau-lang/luau.git "$HOME/luau"
  fi
  cd "$HOME/luau"
  cmake -B build -DCMAKE_BUILD_TYPE=Release
  cmake --build build --target Luau.Repl.CLI Luau.Ast.CLI -j2
}

echo "[3/5] Checking/building native Luau..."
if ! native_ok "$ROOT/bin/luau" || ! native_ok "$ROOT/bin/luau-ast"; then
  [ -e "$ROOT/bin/luau" ] && echo "[!] bin/luau is not a native executable for $(uname -m) (Windows .exe or other CPU?): replacing it"
  rm -f "$ROOT/bin/luau" "$ROOT/bin/luau-ast"
  if [ -x "$HOME/luau/build/luau" ] && [ -x "$HOME/luau/build/luau-ast" ]; then
    cp "$HOME/luau/build/luau" "$ROOT/bin/luau"
    cp "$HOME/luau/build/luau-ast" "$ROOT/bin/luau-ast"
    echo "[OK] copied native Luau + AST parser from ~/luau/build"
  else
    build_luau
    cp "$HOME/luau/build/luau" "$ROOT/bin/luau"
    cp "$HOME/luau/build/luau-ast" "$ROOT/bin/luau-ast"
    echo "[OK] built and copied luau + luau-ast"
  fi
else
  echo "[OK] bin/luau and bin/luau-ast already exist"
fi

command -v luau >/dev/null 2>&1 || true
[ -f "$ROOT/bin/luau" ]     || die "bin/luau is missing; devirt cannot run (re-run, or build Luau manually into ~/luau/build)"
[ -f "$ROOT/bin/luau-ast" ] || die "bin/luau-ast is missing; devirt cannot run"
native_ok "$ROOT/bin/luau"     || die "bin/luau is not an ELF executable for $(uname -m) (run: file bin/luau)"
native_ok "$ROOT/bin/luau-ast" || die "bin/luau-ast is not an ELF executable for $(uname -m) (run: file bin/luau-ast)"

echo "[4/5] Verifying native tools..."
chmod +x "$ROOT/bin/luau" "$ROOT/bin/luau-ast"
"$ROOT/bin/luau" --version 2>/dev/null || die "bin/luau does not run on this device"
"$ROOT/bin/luau-ast" --help >/dev/null 2>&1 || echo "[!] bin/luau-ast gave no --help output (it may still work)"
echo 'print("luau ok")' > "$ROOT/.luau_selftest.lua"
"$ROOT/bin/luau" "$ROOT/.luau_selftest.lua" | grep -q "luau ok" || { rm -f "$ROOT/.luau_selftest.lua"; die "bin/luau cannot execute a script"; }
rm -f "$ROOT/.luau_selftest.lua"

echo "[5/5] Permissions..."
chmod +x "$ROOT/deob.js" "$ROOT/start-bot.sh" "$ROOT/bin/luau" "$ROOT/bin/luau-ast"

echo
echo "=== INSTALL COMPLETE ==="
echo "Test v15.1 detection:"
echo "  node deob.js sample/v15.1/sa-obfuscated.lua.txt --detect"
echo "Start Discord bot: ./start-bot.sh"
echo "The bot asks for DISCORD_TOKEN when no token environment variable is set."

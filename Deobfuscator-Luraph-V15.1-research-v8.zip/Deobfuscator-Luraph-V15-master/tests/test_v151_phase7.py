"""Phase 7 regression tests: CFG completion with shared helpers, return continuations and jump registers.

EVIDENCE CLASS: SYNTHETIC (the miniature register VM of test_v151_retsite.py, walked by the real patched
v15.1 walk).  All assertions are invariants (identity of states / continuations / edges), none is a size
threshold.  The real sample is exercised by the full-pipeline run, not here.

Scenario map (task list of phase 7, section D):
  1 shared helper, many return sites          test_shared_helper_many_return_sites
  2 two callers, different continuations      test_two_callers_distinct_continuations
  3 nested helpers                            test_nested_helpers_keep_their_own_continuations
  4 helper called inside a loop               test_helper_in_loop_is_analysed_once
  5 loop revisiting the same abstract state   test_loop_revisit_is_deduplicated
  6 jump register, several candidate targets  test_jump_register_with_several_candidates
  7 helper register side effects on caller    test_helper_side_effect_reaches_the_caller_continuation
  8 unknown destinations stay unresolved      test_unknown_destination_stays_unresolved
  9 recursive / cyclic flow                   test_recursion_keeps_outer_and_inner_continuation
 10 identical shape, different semantics      test_identical_shape_different_helpers_are_not_merged
 +  runtime order is a path of the CFG        test_every_concrete_step_is_an_edge_of_the_cfg
 +  unpack guard (infeasible register range)  TestUnpackGuard
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.join(ROOT, "tests"))

from test_v151_retsite import walk, states_at, successors_of, FakeStepper, FakeLifter, _Vm   # noqa: E402
from obfuscators.luraph_v15_1 import engine_patch as EP               # noqa: E402
from obfuscators.luraph_v15_1 import devirt as D                       # noqa: E402
from obfuscators.luraph_v15_1 import retsite as RS                     # noqa: E402
from obfuscators.luraph_v15_1 import cfg_stats                         # noqa: E402

E = D._E


def all_successor_pcs(order):
    """pc -> set of successor pcs over every state of that pc (the pc-level CFG of the walk)."""
    out = {}
    nodes = dict(order)
    for k, n in order:
        out.setdefault(k[1], set()).update(ns.pc for ns in E._node_successors(n))
    return out


def execute(code, pc=0, branch=None, limit=400):
    """Concrete run of the fake ISA; returns the list of executed pcs.  `branch(pc, n)` decides `br`."""
    regs, trace, n = {}, [], 0
    while n < limit:
        n += 1
        ins = code[pc]
        trace.append(pc)
        op = ins[0]
        if op == "set":
            regs[ins[1]] = ins[2]; pc += 1
        elif op == "mov":
            regs[ins[1]] = regs.get(ins[2]); pc += 1
        elif op == "call":
            regs[ins[2]] = ins[3]; pc = ins[1]
        elif op == "ret":
            pc = regs[ins[1]] + ins[2]
        elif op == "jmp":
            pc = ins[1]
        elif op == "br":
            pc = ins[2] if (branch(pc, n) if branch else False) else pc + 1
        elif op == "halt":
            return trace
    return trace


class TestScenarios(unittest.TestCase):
    def test_shared_helper_many_return_sites(self):
        n = 40
        code, pc, sites = {0: ("jmp", 20)}, 20, []
        for _ in range(n):
            code[pc] = ("call", 10, 62, pc + 1)
            code[pc + 1] = ("jmp", pc + 2)
            sites.append(pc + 1)
            pc += 2
        code[pc] = ("halt",)
        code[10] = ("set", 7, 1)
        code[11] = ("ret", 62, 0)
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 10)), 1, "helper body analysed once")
        self.assertEqual(sorted(successors_of(order, states_at(order, 11)[0])), sorted(sites),
                         "every return site is preserved as a distinct successor")

    def test_two_callers_distinct_continuations(self):
        code = {0: ("call", 10, 62, 1), 1: ("set", 3, 1), 2: ("halt",), 5: ("call", 10, 62, 6), 6: ("set", 3, 2),
                7: ("halt",), 10: ("ret", 62, 0), 20: ("jmp", 5)}
        code[0] = ("br", 9, 20)
        code[1] = ("call", 10, 62, 2)
        code[2] = ("set", 3, 1); code[3] = ("halt",)
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(sorted(successors_of(order, states_at(order, 10)[0])), [2, 6])
        pcs = all_successor_pcs(order)
        self.assertEqual(pcs[2], {3})
        self.assertEqual(pcs[6], {7})

    def test_nested_helpers_keep_their_own_continuations(self):
        # outer helper 10 calls inner helper 20 through another link register
        code = {0: ("call", 10, 62, 1), 1: ("halt",),
                10: ("call", 20, 61, 11), 11: ("ret", 62, 0),
                20: ("set", 4, 4), 21: ("ret", 61, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        pcs = all_successor_pcs(order)
        self.assertEqual(pcs[21], {11})
        self.assertEqual(pcs[11], {1})
        self.assertEqual(D._E._closure_missing(order, dict(order), None), [])

    def test_helper_in_loop_is_analysed_once(self):
        code = {0: ("set", 1, 1), 1: ("call", 10, 62, 2), 2: ("br", 8, 1), 3: ("halt",), 10: ("set", 2, 2),
                11: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 10)), 1)
        self.assertEqual(successors_of(order, states_at(order, 11)[0]), [2])
        self.assertEqual(all_successor_pcs(order)[2], {1, 3}, "loop back edge and loop exit both kept")

    def test_loop_revisit_is_deduplicated(self):
        # a loop whose back edge reaches an abstract state that was already seen: no state is created twice
        code = {0: ("set", 1, 1), 1: ("set", 2, 5), 2: ("mov", 3, 2), 3: ("br", 8, 1), 4: ("halt",)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        keys = [k for k, _ in order]
        self.assertEqual(len(keys), len(set(keys)), "every abstract state exists exactly once")
        for pc in (1, 2, 3):
            self.assertEqual(len(states_at(order, pc)), 1)
        self.assertIn(1, all_successor_pcs(order)[3])

    def test_jump_register_with_several_candidates(self):
        # r9 receives one of three destinations on three different paths; the consumer keeps exactly those
        code = {0: ("br", 8, 10), 1: ("br", 7, 20), 2: ("set", 9, 30), 3: ("jmp", 50),
                10: ("set", 9, 31), 11: ("jmp", 50), 20: ("set", 9, 32), 21: ("jmp", 50),
                50: ("ret", 9, 0), 30: ("halt",), 31: ("halt",), 32: ("halt",)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        targets = set()
        for k in states_at(order, 50):
            targets |= set(successors_of(order, k))
        self.assertEqual(targets, {30, 31, 32})
        self.assertEqual(D._E._closure_missing(order, dict(order), None), [])

    def test_helper_side_effect_reaches_the_caller_continuation(self):
        # helper 20 writes r9=77 and the caller consumes r9 afterwards: the target is the helper's value,
        # not the value the caller had before the call
        code = {0: ("set", 9, 40), 1: ("call", 20, 62, 2), 2: ("ret", 9, 0), 40: ("halt",), 77: ("halt",),
                20: ("set", 9, 77), 21: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(successors_of(order, states_at(order, 2)[0]), [77])
        self.assertNotIn(40, all_successor_pcs(order)[2])

    def test_caller_register_survives_the_helper(self):
        # the helper does not touch r9: each caller keeps its own destination across the shared helper body
        code = {0: ("br", 8, 10), 1: ("set", 9, 40), 2: ("call", 20, 62, 3), 3: ("ret", 9, 0),
                10: ("set", 9, 50), 11: ("call", 20, 62, 12), 12: ("ret", 9, 0),
                20: ("set", 2, 2), 21: ("ret", 62, 0), 40: ("halt",), 50: ("halt",)}
        order, restart, lf, _ = walk(code, bound=12)                   # below the bound: exact clones
        self.assertFalse(restart)
        self.assertEqual(successors_of(order, states_at(order, 3)[0]), [40])
        self.assertEqual(successors_of(order, states_at(order, 12)[0]), [50])
        order, restart, lf, _ = walk(code, bound=0)                    # abstracted: helper once, dispatch tests r9
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 20)), 1)
        self.assertIn(40, successors_of(order, states_at(order, 3)[0]))   # the real destination is never lost
        self.assertIn(50, successors_of(order, states_at(order, 12)[0]))

    def test_unknown_destination_stays_unresolved(self):
        code = {0: ("call", 10, 62, 1), 1: ("halt",), 5: ("mov", 62, 3), 6: ("call", 10, 61, 7), 7: ("halt",),
                10: ("ret", 62, 0)}
        code[0] = ("br", 8, 5)
        code[2] = ("call", 10, 62, 1)
        code[1] = ("halt",)
        order, restart, lf, _ = walk(code)
        unresolved = [n for _k, n in order if getattr(n, "error", None)]
        self.assertTrue(unresolved, "a return through a register without a known constant is reported, not guessed")

    def test_recursion_keeps_outer_and_inner_continuation(self):
        code = {0: ("mov", 1, 50), 1: ("call", 10, 62, 2), 2: ("halt",),
                10: ("br", 1, 13), 11: ("jmp", 14), 13: ("call", 10, 62, 14), 14: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        tokd = [k for k in states_at(order, 14) if any(isinstance(v, RS.LinkTok) for _, v in k[3])]
        self.assertEqual(sorted(successors_of(order, tokd[0])), [2, 14])

    def test_identical_shape_different_helpers_are_not_merged(self):
        # two helpers with the same instruction shape at different pcs and different return sites
        code = {0: ("br", 8, 5), 1: ("call", 10, 62, 2), 2: ("halt",), 5: ("call", 20, 62, 6), 6: ("halt",),
                10: ("set", 4, 1), 11: ("ret", 62, 0), 20: ("set", 4, 1), 21: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(successors_of(order, states_at(order, 11)[0]), [2])
        self.assertEqual(successors_of(order, states_at(order, 21)[0]), [6])
        self.assertEqual(len(states_at(order, 10)), 1)
        self.assertEqual(len(states_at(order, 20)), 1)


class LocStepper(FakeStepper):
    """Adds ("loc", name, value): a carried local, i.e. caller state that is NOT a link register."""

    def step(self, state, prefix):
        ins = self.code[state.pc]
        if ins[0] != "loc":
            return FakeStepper.step(self, state, prefix)
        lf = self.lf
        lf.jvals = dict(state.jregs)
        lf.jread = set()
        lf.link_new = {}
        ns = E.State(0, state.pc + 1, None, tuple(sorted(lf.jvals.items())), None, state.packs,
                     state.locs + ((ins[1], ins[2]),))
        return E.Node([], outcome=E.Next(RS.finish_state(lf, state, ns)))


def walk_loc(code, bound=0):
    old_on, old_b = EP.RETSITE_ON, RS.MIN_SITES
    EP.RETSITE_ON, RS.MIN_SITES = True, bound
    try:
        lf = FakeLifter()
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(_Vm(), lf, LocStepper(code, lf), 50000)
        return order, restart, lf
    finally:
        EP.RETSITE_ON, RS.MIN_SITES = old_on, old_b


class TestCallerStateIsNotMixed(unittest.TestCase):
    """The helper body is shared, the return continuations are not: a continuation after caller A's call
    carries A's state only, never state that entered the helper from caller B (return continuations must be
    independent of which caller the shared body was analysed for)."""
    CODE = {0: ("br", 8, 10), 1: ("loc", "a", 1), 2: ("call", 30, 62, 3), 3: ("halt",),
            10: ("loc", "b", 2), 11: ("call", 30, 62, 12), 12: ("halt",),
            30: ("set", 7, 1), 31: ("ret", 62, 0)}

    def check(self, bound):
        order, restart, lf = walk_loc(self.CODE, bound)
        self.assertFalse(restart)
        self.assertEqual({k[6] for k in states_at(order, 3)}, {(("a", 1),)})
        self.assertEqual({k[6] for k in states_at(order, 12)}, {(("b", 2),)})
        # both sites of the shared helper are still reachable (nothing dropped to avoid the mixing)
        self.assertEqual(sorted({ns.pc for k in states_at(order, 31) for ns in E._node_successors(dict(order)[k])}), [3, 12])
        return order, lf

    def test_above_the_bound(self):
        self.check(0)

    def test_below_the_bound(self):
        self.check(12)

    def test_undecided_dispatch_does_not_cross_caller_contexts(self):
        """Caller context a enters the shared helper from two sites (the facts of the helper entry join, so the
        return dispatch cannot be decided by constants); caller context b has a third site.  Above the
        bound the old table (one per entry) built (b's site, a's state) -- an infeasible state."""
        code = {0: ("br", 8, 10), 1: ("loc", "a", 1), 2: ("br", 7, 5), 3: ("call", 30, 62, 4), 4: ("halt",),
                5: ("call", 30, 62, 6), 6: ("halt",),
                10: ("loc", "b", 2), 11: ("call", 30, 62, 12), 12: ("halt",),
                30: ("set", 7, 1), 31: ("ret", 62, 0)}
        for bound in (0, 12):
            with self.subTest(bound=bound):
                order, restart, lf = walk_loc(code, bound)
                self.assertFalse(restart)
                self.assertEqual({k[6] for k in states_at(order, 4)}, {(("a", 1),)})
                self.assertEqual({k[6] for k in states_at(order, 6)}, {(("a", 1),)})
                self.assertEqual({k[6] for k in states_at(order, 12)}, {(("b", 2),)}, "no (site of b, state of a)")
                succ = {ns.pc for k in states_at(order, 31) for ns in E._node_successors(dict(order)[k])}
                self.assertEqual(succ, {4, 6, 12}, "every site is still reachable")

    def test_helper_body_is_still_per_entry_context_only(self):
        order, lf = self.check(0)
        # one helper body per distinct caller state (a and b), not one per (state x site)
        self.assertEqual(len(states_at(order, 30)), 2)


class KeyStepper(FakeStepper):
    """Carries decode keys the way V151Stepper does: State151.keys, and `lf.v151_frame` set before finish_state.
    ("key", name, value) sets a decode-key local."""

    def initial(self):
        return E.State151.of(E.State(0, 0, None, (), None, (), ()), ())

    def step(self, state, prefix):
        ins = self.code[state.pc]
        keys = tuple(state.keys)
        if ins[0] == "key":
            keys = tuple(sorted(dict(keys, **{ins[1]: ins[2]}).items()))
            node = FakeStepper.step(self, state, prefix) if False else None
            lf = self.lf
            lf.jvals = dict(state.jregs); lf.jread = set(); lf.link_new = {}
            ns = E.State(0, state.pc + 1, None, tuple(sorted(lf.jvals.items())), None, state.packs, state.locs)
            lf.v151_frame = (keys, ())
            try:
                ns = RS.finish_state(lf, state, ns)
            finally:
                lf.v151_frame = ()
            return E.Node([], outcome=E.Next(E.State151.of(ns, keys)))
        self.lf.v151_frame = (keys, ())
        try:
            node = FakeStepper.step(self, state, prefix)
        finally:
            self.lf.v151_frame = ()
        stack = [node]
        while stack:
            n = stack.pop()
            if n is None:
                continue
            oc = getattr(n, "outcome", None)
            if oc is not None and getattr(oc, "state", None) is not None and not isinstance(oc.state, E.State151):
                oc.state = E.State151.of(oc.state, keys)
            stack.extend([getattr(n, "then", None), getattr(n, "els", None)])
        return node


def walk_keys(code, bound=0):
    old_on, old_b = EP.RETSITE_ON, RS.MIN_SITES
    EP.RETSITE_ON, RS.MIN_SITES = True, bound
    try:
        lf = FakeLifter()
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(_Vm(), lf, KeyStepper(code, lf), 50000)
        return order, restart, lf
    finally:
        EP.RETSITE_ON, RS.MIN_SITES = old_on, old_b


class TestDecodeKeysAreNotMixed(unittest.TestCase):
    """Decode keys are part of the caller context: a return continuation of caller B never carries caller A's keys
    (found in phase 8: finish_state ran before keys were attached, so the v7 context id ignored them)."""
    CODE = {0: ("br", 8, 10), 1: ("key", "k", 1), 2: ("br", 7, 5), 3: ("call", 30, 62, 4), 4: ("halt",),
            5: ("call", 30, 62, 6), 6: ("halt",),
            10: ("key", "k", 2), 11: ("call", 30, 62, 12), 12: ("halt",),
            30: ("set", 7, 1), 31: ("ret", 62, 0)}

    def test_no_site_of_b_with_keys_of_a(self):
        for bound in (0, 12):
            with self.subTest(bound=bound):
                order, restart, lf = walk_keys(self.CODE, bound)
                self.assertFalse(restart)
                self.assertEqual({k[-2] for k in states_at(order, 4)}, {(("k", 1),)})
                self.assertEqual({k[-2] for k in states_at(order, 6)}, {(("k", 1),)})
                self.assertEqual({k[-2] for k in states_at(order, 12)}, {(("k", 2),)})
                succ = {ns.pc for k in states_at(order, 31) for ns in E._node_successors(dict(order)[k])}
                self.assertEqual(succ, {4, 6, 12}, "every site stays reachable")

    def test_negative_control_without_the_keys_in_the_context(self):
        """If the frame were not part of the context the product would appear: the test must be able to fail."""
        old = RS.RETCTX
        RS.RETCTX = False
        try:
            order, restart, lf = walk_keys(self.CODE, 0)
        finally:
            RS.RETCTX = old
        self.assertIn((("k", 1),), {k[-2] for k in states_at(order, 12)}, "baseline mixes caller keys (control)")


class TestRuntimeOrder(unittest.TestCase):
    PROGRAMS = {}

    @classmethod
    def setUpClass(cls):
        n = 12
        many, pc = {0: ("jmp", 20)}, 20
        for _ in range(n):
            many[pc] = ("call", 10, 62, pc + 1); many[pc + 1] = ("jmp", pc + 2); pc += 2
        many[pc] = ("halt",); many[10] = ("set", 7, 1); many[11] = ("ret", 62, 0)
        cls.PROGRAMS["many_sites"] = many
        cls.PROGRAMS["nested"] = {0: ("call", 10, 62, 1), 1: ("halt",), 10: ("call", 20, 61, 11),
                                  11: ("ret", 62, 0), 20: ("set", 4, 4), 21: ("ret", 61, 0)}
        cls.PROGRAMS["two_callers"] = {0: ("call", 10, 62, 1), 1: ("call", 10, 62, 2), 2: ("halt",),
                                       10: ("set", 3, 3), 11: ("ret", 62, 0)}
        cls.PROGRAMS["loop"] = {0: ("set", 1, 1), 1: ("call", 10, 62, 2), 2: ("br", 8, 1), 3: ("halt",),
                                10: ("ret", 62, 0)}

    def test_every_concrete_step_is_an_edge_of_the_cfg(self):
        for name, code in self.PROGRAMS.items():
            with self.subTest(program=name):
                order, restart, lf, _ = walk(code)
                self.assertFalse(restart)
                cfg = all_successor_pcs(order)
                calls = {"n": 0}

                def br(pc, n):          # leave the loop after three iterations
                    calls["n"] += 1
                    return calls["n"] <= 3
                trace = execute(code, branch=br)
                self.assertEqual(code[trace[-1]][0], "halt", "the concrete run terminates")
                for a, b in zip(trace, trace[1:]):
                    self.assertIn(b, cfg.get(a, set()), "executed transfer %d -> %d is a CFG edge" % (a, b))

    def test_return_continuation_order_matches_call_order(self):
        code = self.PROGRAMS["two_callers"]
        order, restart, lf, _ = walk(code)
        trace = execute(code)
        rets = [b for a, b in zip(trace, trace[1:]) if code[a][0] == "ret"]
        self.assertEqual(rets, [1, 2], "first return goes to the first site, the second to the second")
        self.assertEqual(set(successors_of(order, states_at(order, 11)[0])), {1, 2})


class TestDiagnostics(unittest.TestCase):
    def test_cfg_stats_reports_duplication_reason(self):
        n = 30
        code, pc = {0: ("jmp", 20)}, 20
        for _ in range(n):
            code[pc] = ("call", 10, 62, pc + 1); code[pc + 1] = ("jmp", pc + 2); pc += 2
        code[pc] = ("halt",); code[10] = ("set", 7, 1); code[11] = ("ret", 62, 0)
        base, _, _, _ = walk(code, links_on=False)
        new, _, _, _ = walk(code, links_on=True)
        sb, sn = cfg_stats.summary(base), cfg_stats.summary(new)
        self.assertEqual(sb["most_duplicated"][0]["varying"][:1], ["jregs"], "baseline duplication is explained by jump registers")
        self.assertLess(sn["most_duplicated"][0]["states"], sb["most_duplicated"][0]["states"])
        self.assertEqual(sn["error_nodes"], 0)


class TestUnpackGuard(unittest.TestCase):
    class _Lf:
        jvals = {}

    def test_small_range_is_unchanged(self):
        m = E.ProtoLifter.unpack(self._Lf(), E.Multi([E.RegFile(), 13, 16]))
        self.assertEqual(len(m.items), 4)

    def test_infeasible_range_is_unsupported_not_materialised(self):
        with self.assertRaises(E.Unsupported):
            E.ProtoLifter.unpack(self._Lf(), E.Multi([E.RegFile(), 13, 13827]))

    def test_diag_records_the_refusal(self):
        from obfuscators.luraph_v15_1 import engine_patch as EP
        EP.DIAG.unpack_overflows[:] = []
        with self.assertRaises(E.Unsupported):
            E.ProtoLifter.unpack(self._Lf(), E.Multi([E.RegFile(), 13, 13827]))
        self.assertEqual(EP.DIAG.unpack_overflows[-1]["to"], 13827)


if __name__ == "__main__":
    unittest.main()

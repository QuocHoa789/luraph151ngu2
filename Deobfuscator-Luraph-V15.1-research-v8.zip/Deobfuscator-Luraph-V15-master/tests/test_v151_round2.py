"""Round-2 tests of the Luraph v15.1 backend: diagnostics, data-flow, key carrying,
conformance replay and the validation gate.  Pure unit tests (no sample, no harness)
plus dump-based tests that run only when DEOB_V151_DUMP points at a traced dump.

    python3 tests/test_v151_round2.py
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1 import validator as V             # noqa: E402
from obfuscators.luraph_v15_1 import conformance as CF          # noqa: E402
from obfuscators.luraph_v15_1 import dataflow as DF             # noqa: E402
from obfuscators.luraph_v15_1 import diagnostics as DG          # noqa: E402
from obfuscators.luraph_v15_1 import trace_oracle as TO         # noqa: E402

CLEAN = {"decode": {"protos": 3, "instructions": 10}, "lift": {"ran": True}, "unlifted_blocks": 0,
         "nil_calls": 0, "unknown_opcode_steps": 0, "closure": {"entered_not_lifted": [], "dangling_edges": 0},
         "conformance": {"verdict": "CONFORMANT", "total": {}, "failures": []}}


def with_(**kw):
    d = dict(CLEAN)
    d.update(kw)
    return d


class ValidatorGate(unittest.TestCase):
    def test_clean_run_passes(self):
        r = V.evaluate(CLEAN)
        self.assertEqual(r["verdict"], "PASS")
        self.assertTrue(r["emit_source"])
        self.assertTrue(r["validated_against_trace"])

    def test_unlifted_blocks_never_pass(self):
        r = V.evaluate(with_(unlifted_blocks=1))
        self.assertEqual(r["verdict"], "PARTIAL")
        self.assertNotEqual(r["verdict"], "PASS")
        self.assertFalse(r["emit_source"])
        self.assertIn("UNLIFTED_BLOCKS", [x["code"] for x in r["reasons"]])

    def test_nil_calls_never_pass(self):
        r = V.evaluate(with_(nil_calls=3))
        self.assertEqual(r["verdict"], "PARTIAL")
        self.assertIn("NIL_CALLS", [x["code"] for x in r["reasons"]])

    def test_missing_measurement_is_not_clean(self):
        d = dict(CLEAN)
        del d["nil_calls"]
        self.assertEqual(V.evaluate(d)["verdict"], "PARTIAL")

    def test_invalid_closure_graph(self):
        r = V.evaluate(with_(closure={"entered_not_lifted": ["7"], "dangling_edges": 0}))
        self.assertEqual(r["verdict"], "PARTIAL")
        self.assertIn("INVALID_CLOSURE_GRAPH", [x["code"] for x in r["reasons"]])

    def test_trace_not_conformant(self):
        r = V.evaluate(with_(conformance={"verdict": "NOT_CONFORMANT", "total": {"fail": 2}, "failures": []}))
        self.assertEqual(r["verdict"], "PARTIAL")

    def test_no_trace_is_partial_unless_not_required(self):
        d = with_(conformance={"verdict": "NO_TRACE"})
        self.assertEqual(V.evaluate(d)["verdict"], "PARTIAL")
        r = V.evaluate(d, trace_required=False)
        self.assertEqual(r["verdict"], "PASS")
        self.assertFalse(r["validated_against_trace"])

    def test_blocked_and_fail(self):
        self.assertEqual(V.evaluate(with_(runtime={"available": False, "reason": "no luau"}))["verdict"], "BLOCKED")
        self.assertEqual(V.evaluate(with_(harness={"ok": False, "error": "crash"}))["verdict"], "FAIL")
        self.assertEqual(V.evaluate(with_(decode={"protos": 0}))["verdict"], "FAIL")
        self.assertEqual(V.evaluate(with_(lift={"ran": True, "error": "boom"}))["verdict"], "FAIL")


class Node:
    def __init__(self, op, error=None):
        self.op, self.error = op, error


def key(mode, pc):
    return (mode, pc, 0, (), 0, (), (), (), ())


def rec(proto, steps, edges):
    order = [(key(m, p), Node((m, o))) for (m, p, o) in steps]
    ed = {}
    for a, b in edges:
        ed.setdefault(key(*a), set()).add(key(*b))
    return CF.record_walk(proto, "c", order, ed)


def trace_of(steps, aid=1, tags=None):
    out = []
    for (tag, pc, op) in steps:
        out.append(aid * CF.AID + tag * CF.TAG + pc * CF.PC + op)
    return out


class Conformance(unittest.TestCase):
    def oracle(self, steps):
        return TO.Oracle(trace_of(steps), {0: 73}, {"10": 1}, {"p": ["10"]})

    def test_replay_conformant(self):
        r = rec("p", [(73, 0, 5), (73, 1, 6), (73, 2, 7)], [((73, 0), (73, 1)), ((73, 1), (73, 2))])
        out = CF.check(self.oracle([(0, 0, 5), (0, 1, 6), (0, 2, 7)]), [r], {(73, 7)})
        self.assertTrue(out["conformant"], out)
        self.assertEqual(out["total"]["ok"], 2)

    def test_missing_edge_is_a_failure(self):
        r = rec("p", [(73, 0, 5), (73, 1, 6), (73, 2, 7)], [((73, 0), (73, 1))])
        out = CF.check(self.oracle([(0, 0, 5), (0, 1, 6), (0, 2, 7)]), [r], {(73, 7)})
        self.assertFalse(out["conformant"])
        self.assertEqual(out["total"]["fail"], 1)

    def test_other_opcode_is_a_failure(self):
        r = rec("p", [(73, 0, 5), (73, 1, 9)], [((73, 0), (73, 1))])
        out = CF.check(self.oracle([(0, 0, 5), (0, 1, 6)]), [r], set())
        self.assertFalse(out["conformant"])

    def test_redispatch_steps_are_collapsed(self):
        # real run: pc 1 executed twice in a row (an in-place decode re-dispatched it)
        r = rec("p", [(73, 0, 5), (73, 1, 6)], [((73, 0), (73, 1))])
        out = CF.check(self.oracle([(0, 0, 5), (0, 1, 77), (0, 1, 6)]), [r], set())
        self.assertTrue(out["conformant"], out)

    def test_instances_are_merged(self):
        a = rec("p", [(73, 0, 5), (73, 1, 6)], [])
        b = rec("p", [(73, 0, 5), (73, 1, 6)], [((73, 0), (73, 1))])
        out = CF.check(self.oracle([(0, 0, 5), (0, 1, 6)]), [a, b], set())
        self.assertTrue(out["conformant"])

    def test_empty_trace_is_not_conformant(self):
        out = CF.check(TO.Oracle([], {}), [], set())
        self.assertFalse(out["conformant"])


class DataFlow(unittest.TestCase):
    def test_pure_names(self):
        self.assertTrue(DF.pure_name("bit32.bxor"))
        self.assertTrue(DF.pure_name("math.floor"))
        self.assertFalse(DF.pure_name("math.random"))
        self.assertFalse(DF.pure_name("string.rep"))
        self.assertFalse(DF.pure_name(None))

    def test_is_int_excludes_bool(self):
        self.assertTrue(DF.is_int(3))
        self.assertFalse(DF.is_int(True))
        self.assertFalse(DF.is_int(3.0))
        self.assertFalse(DF.is_int(b"3"))

    def test_pending_and_symkey_hash(self):
        self.assertEqual(DF.SymKey(1), DF.SymKey(1))
        self.assertNotEqual(DF.SymKey(1), DF.SymKey(2))
        self.assertEqual(len({DF.SymKey(1), DF.SymKey(1)}), 1)
        self.assertNotEqual(DF.Pending(None, "r1", 5), DF.Pending(None, "r2", 5))


class Diagnostics(unittest.TestCase):
    def test_reason_enums_are_closed(self):
        for r in ("UNKNOWN_OPCODE", "BAD_SUCCESSOR", "INVALID_REGISTER", "MISSING_CONSTANT", "MISSING_CLOSURE",
                  "DYNAMIC_EXPANSION", "UNSUPPORTED_CALL", "TYPE_MISMATCH", "UNKNOWN"):
            self.assertIn(r, DG.REASONS)
        for c in ("MISSING_CFG_SUCCESSOR", "WRONG_BRANCH_TARGET", "DYNAMIC_MATERIALIZATION", "UNKNOWN_OPCODE_SEMANTIC",
                  "MISSING_CLOSURE_EDGE", "MISSING_PROTO_EDGE", "BAD_REGISTER_STATE", "BAD_CONSTANT", "UNSUPPORTED_CALL",
                  "JUNK_UNREACHABLE", "OTHER"):
            self.assertIn(c, DG.CLASSES)

    def test_types_are_exact(self):
        self.assertEqual(DG.type_of(1), "INTEGER")
        self.assertNotEqual(DG.type_of(True), "INTEGER")
        self.assertNotEqual(DG.type_of(1.5), "INTEGER")
        self.assertNotEqual(DG.type_of(b"1"), "INTEGER")


DUMP = os.environ.get("DEOB_V151_DUMP")
SAMPLE = os.path.join(ROOT, "sample", "v15.1", "sa-obfuscated.lua.txt")


class ResourceGuards(unittest.TestCase):
    """A CFG too large to lower must end as a verdict, never as an OOM kill."""

    def _run(self, code, env):
        import subprocess
        e = dict(os.environ, PYTHONPATH=os.path.join(ROOT, "core"), **env)
        return subprocess.run([sys.executable, "-c", code], env=e, capture_output=True, text=True, timeout=60)

    def test_memory_cap_turns_oom_into_memory_error(self):
        code = ("import sys\nfrom obfuscators.luraph_v15_1 import driver\ndriver._cap_memory()\n"
                "try:\n    x = bytearray(1500*1024*1024)\n    print('ALLOCATED')\n"
                "except MemoryError:\n    print('MEMORY_ERROR')\n")
        r = self._run(code, {"DEOB_V151_MEM_MB": "1000"})
        self.assertIn("MEMORY_ERROR", r.stdout, r.stderr[-500:])

    def test_memory_cap_can_be_disabled(self):
        code = ("import resource\nfrom obfuscators.luraph_v15_1 import driver\ndriver._cap_memory()\n"
                "print(resource.getrlimit(resource.RLIMIT_AS)[0] == resource.RLIM_INFINITY)\n")
        r = self._run(code, {"DEOB_V151_MEM_MB": "0"})
        self.assertIn("True", r.stdout, r.stderr[-500:])

    def test_lower_budget_is_configurable(self):
        code = "from obfuscators.luraph_v15_1 import engine_patch as EP\nprint(EP.LOWER_BUDGET)\n"
        r = self._run(code, {"DEVIRT_LOWER_BUDGET": "1234"})
        self.assertIn("1234", r.stdout, r.stderr[-500:])

    def test_budget_and_memory_stops_are_partial_not_pass(self):
        from obfuscators.luraph_v15_1 import gate as G
        from obfuscators.luraph_v15_1 import engine_patch as EP
        for msg in ("Unsupported: V151_LOWER_BUDGET: 9 blocks x 9 registers", "Unsupported: V151_LOWER_MEMORY: oom"):
            lift = G.failure_facts(EP, None, msg)
            r = V.evaluate(with_(lift=lift))
            self.assertEqual(r["verdict"], "PARTIAL", msg)
            self.assertFalse(r["emit_source"])
            self.assertIn("LIFT_BUDGET_EXHAUSTED", [x["code"] for x in r["reasons"]])
        r = V.evaluate(with_(lift=G.failure_facts(EP, None, "KeyError: 5")))
        self.assertEqual(r["verdict"], "FAIL")


@unittest.skipUnless(DUMP and os.path.exists(DUMP), "set DEOB_V151_DUMP to a traced harness dump (--debug-v151)")
class DumpBased(unittest.TestCase):
    """Lifts small protos of the sample from a traced dump and replays the real run through them."""

    @classmethod
    def setUpClass(cls):
        from backend import run_big_stack
        from obfuscators.luraph_v15_1 import devirt as D, engine_patch as EP, vmmap as VM, opcode_maps as OM
        cls.D, cls.EP = D, EP
        E = D._E

        def lift(keys):
            EP.STATS["source"], EP.STATS["dump_path"] = SAMPLE, DUMP
            prog = E.Program(SAMPLE, DUMP, [])
            out = {}
            for key in keys:
                cap = prog.dump.protos[key]
                vm = prog.vm_of(cap)
                lf = E.ProtoLifter(vm, prog.dump, vm.vmobj_of(cap), vm.proto_of(cap), E.UpList(), prog.globals)
                st = E.make_stepper(vm, lf)
                prog.walk_fixpoint(vm, lf, st, E.WALK_LIMIT)
                out[key] = st
            return out

        cls.steppers = run_big_stack(lift, ["11", "21"])
        mp = OM.load(SAMPLE)
        cls.kinds = {(m, s.opcode) for m, x in mp.items() for s in x.handlers() if s.kind == "RETURN"}

    def test_key_locals_are_carried(self):
        st = self.steppers["11"]
        self.assertGreaterEqual(len(st.key_locals), 1)
        self.assertEqual(self.EP.DIAG.summary()["unlifted_blocks"], 0)

    def test_real_run_replays_through_the_lift(self):
        rep = self.EP.conformance_report()
        self.assertEqual(rep["verdict"], "CONFORMANT", rep.get("failures"))
        self.assertEqual(rep["total"]["fail"], 0)
        self.assertGreater(rep["total"]["ok"], 1000)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Phase 8: helper summaries (core/obfuscators/luraph_v15_1/helpersum.py).

EVIDENCE CLASS: SYNTHETIC (miniature register VM on the real patched walk; only the stepper is a stand-in, as in
test_v151_retsite.py).  None of these tests is evidence that the sample is devirtualised.  The stand-in stepper
reports each executed step to `helpersum.note_step` exactly where `V151Stepper.run_once` does.

Instruction set (mode 0): see test_v151_retsite.py, plus
    ("use", reg)                    emits an IR statement that reads `reg` (a register effect: impure helper step)
    ("brd", reg, pc_true)           data-dependent branch (helper with control flow)
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from obfuscators.luraph_v15_1 import devirt as D                     # noqa: E402
from obfuscators.luraph_v15_1 import engine_patch as EP              # noqa: E402
from obfuscators.luraph_v15_1 import retsite as RS                   # noqa: E402
from obfuscators.luraph_v15_1 import helpersum as HS                 # noqa: E402
from obfuscators.luraph_v15_1 import conformance as CF               # noqa: E402
import test_v151_retsite as T                                        # noqa: E402

E = D._E


class P8Stepper(T.FakeStepper):
    def step(self, state, prefix):
        lf = self.lf
        lf.jvals = dict(state.jregs)
        lf.jread = set()
        lf.link_new = {}
        lf.mutated = False
        ins = self.code[state.pc]
        out = []
        op = ins[0]
        nxt = state.pc + 1
        cond = None
        pc_expr = None
        ret = False
        if op == "set":
            self._emit_assign(lf, ins[1], E.Const(ins[2]), out)
        elif op == "mov":
            self._emit_assign(lf, ins[1], self._read(lf, ins[2]), out)
        elif op == "call":
            self._emit_assign(lf, ins[2], E.Const(ins[3]), out)
            nxt = ins[1]
        elif op == "jmp":
            nxt = ins[1]
        elif op == "ret":
            v = self._read(lf, ins[1])
            pc_expr = v if ins[2] == 0 else (v + ins[2] if isinstance(v, int) else E.Bin("Add", v, E.Const(ins[2])))
        elif op == "use":
            out.append(E.Assign(E.Reg(90), E.Reg(ins[1])))
        elif op in ("br", "brd"):
            cond = E.Reg(ins[1])
        elif op == "halt":
            ret = True
        lf.last_op = (0, op)

        def state_to(pc):
            jr = tuple(sorted(((k, v) for k, v in lf.jvals.items() if k not in lf.jread), key=lambda kv: kv[0]))
            ns = E.State(0, pc, None, jr, None, state.packs, state.locs)
            rs = RS.of(lf)
            HS.note_step(lf, rs, state, ns, (), (), len(out), 1 if cond is not None else 0, None)
            return RS.finish_state(lf, state, ns)

        if ret:
            return E.Node(out, outcome=E.Ret(E.Multi([])))
        if cond is not None:
            lf.jvals = dict(state.jregs)
            t = E.Node([], outcome=E.Next(state_to(ins[2])))
            e = E.Node([], outcome=E.Next(state_to(nxt)))
            return E.Node(out, cond=cond, then=t, els=e)
        if pc_expr is not None:
            return E.Node(out, outcome=E.Next(state_to(pc_expr)))
        return E.Node(out, outcome=E.Next(state_to(nxt)))


def walk(code, summary=True, bound=12, limit=50000):
    old = (EP.RETSITE_ON, RS.MIN_SITES, HS.ON)
    EP.RETSITE_ON, RS.MIN_SITES, HS.ON = True, bound, summary
    try:
        lf = T.FakeLifter()
        st = P8Stepper(code, lf)
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, limit)
        return order, restart, lf, prog
    finally:
        EP.RETSITE_ON, RS.MIN_SITES, HS.ON = old


def pcs(order):
    return sorted({k[1] for k, _ in order})


def at(order, pc):
    return [k for k, _ in order if k[1] == pc]


def succ_pcs(order, k):
    return sorted(ns.pc for ns in E._node_successors(dict(order)[k]))


def trampoline(ncallers, link=62, entry=100, ret_off=0):
    """`ncallers` call sites, each followed by a continuation `set r20, i`; helper = 3 pure steps + return."""
    code, pc = {}, 0
    for i in range(ncallers):
        code[pc] = ("call", entry, link, pc + 1 - ret_off)
        code[pc + 1] = ("set", 20, i)
        pc += 2
    code[pc] = ("halt",)
    code[entry] = ("jmp", entry + 1)
    code[entry + 1] = ("jmp", entry + 2)
    code[entry + 2] = ("ret", link, ret_off)
    return code


class TestPureHelperSummary(unittest.TestCase):
    def test_trampoline_is_summarised_and_callers_go_straight_to_their_continuation(self):
        code = trampoline(6, ret_off=1)
        order, restart, lf, _ = walk(code)
        rs = RS.of(lf)
        self.assertFalse(restart)
        self.assertIn((0, 100), rs.summaries)
        s = rs.summaries[(0, 100)]
        self.assertEqual((s["reg"], s["off"], s["exit_pc"], len(s["chain"])), (62, 1, 102, 3))
        self.assertGreaterEqual(rs.sum_hits, 4)
        # the helper body exists for the first traversals only, not once per caller
        self.assertLess(len(at(order, 102)), 6)
        # every call site that used the summary reaches ITS OWN continuation (call at pc 2i stores K = 2i, offset 1)
        used = 0
        for i in range(6):
            for k in at(order, 2 * i):
                if rs.sum_apps.get(k):
                    used += 1
                    self.assertEqual(succ_pcs(order, k), [2 * i + 1])
        self.assertGreaterEqual(used, 4)
        self.assertEqual(E._closure_missing(order, dict(order), None), [])

    def test_summary_vs_direct_interpretation_same_continuations(self):
        """Differential: the CFG restricted to non-helper pcs is the same with and without summaries."""
        code = trampoline(8, ret_off=1)
        a, ra, lfa, _ = walk(code, summary=False, bound=100)          # exact clones: the direct interpretation
        b, rb, lfb, _ = walk(code, summary=True, bound=100)
        self.assertFalse(ra)
        self.assertFalse(rb)
        helper = {100, 101, 102}
        self.assertEqual([p for p in pcs(a) if p not in helper], [p for p in pcs(b) if p not in helper])
        self.assertLess(len(b), len(a))
        # the non-helper reachable pcs after a call are exactly the caller's continuation, never another caller's
        for i in range(8):
            conts = {ns.pc for k in at(b, 2 * i) for ns in E._node_successors(dict(b)[k])}
            self.assertTrue(conts <= {100, 2 * i + 1}, conts)       # the helper entry (first traversals) or its own continuation
            self.assertIn(2 * i + 1, {ns.pc for k in at(b, 2 * i) if RS.of(lfb).sum_apps.get(k) for ns in E._node_successors(dict(b)[k])} | {2 * i + 1} )

    def test_summary_keeps_distinct_continuations_distinct(self):
        code = {0: ("call", 10, 62, 1), 1: ("jmp", 2), 2: ("call", 10, 62, 3), 3: ("set", 20, 9), 4: ("halt",),
                10: ("jmp", 11), 11: ("ret", 62, 1)}
        code[3] = ("jmp", 4)
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        # no return exit mixes the two sites: the call at 0 can only continue at 2, the call at 2 only at 4
        for k in at(order, 0):
            self.assertEqual(succ_pcs(order, k), [2] if RS.of(lf).sum_apps.get(k) else succ_pcs(order, k))
        reach = set(pcs(order))
        self.assertTrue({2, 4} <= reach)

    def test_negative_control_without_summary_the_exit_mixes_return_sites(self):
        """Without summaries, abstracting the link (bound 0) makes the exit one node dispatching to every site."""
        code = {0: ("call", 10, 62, 1), 1: ("jmp", 2), 2: ("call", 10, 62, 3), 3: ("jmp", 4), 4: ("halt",),
                10: ("jmp", 11), 11: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code, summary=False, bound=0)
        exit_states = at(order, 11)
        self.assertEqual(len(exit_states), 1)
        self.assertEqual(succ_pcs(order, exit_states[0]), [2, 4])

    def test_register_side_effects_after_return_are_preserved(self):
        """A caller's own register write after the helper returns is still emitted (the summary does not drop code)."""
        code = trampoline(2, ret_off=1)
        order, restart, lf, _ = walk(code)
        sets = [s for _, n in order for s in n.stmts if isinstance(s, E.Assign) and getattr(s.target, "n", None) == 20]
        self.assertGreaterEqual(len(sets), 2)

    def test_two_calls_with_distinct_state_stay_two_states(self):
        """Callers whose jump-register state differs are not merged by the summary (observable component)."""
        code = {0: ("set", 30, 5), 1: ("call", 10, 62, 1), 2: ("jmp", 3), 3: ("set", 30, 6), 4: ("call", 10, 62, 4),
                5: ("halt",), 10: ("jmp", 11), 11: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        rs = RS.of(lf)
        for call, cont in ((1, 2), (4, 5)):
            for k in at(order, call):
                self.assertIn(cont, succ_pcs(order, k) + ([cont] if not rs.sum_apps.get(k) else []))
                if rs.sum_apps.get(k):
                    self.assertEqual(succ_pcs(order, k), [cont])
        self.assertTrue({2, 3, 4, 5} <= set(pcs(order)))


def lfa_edges(order):
    for k, n in order:
        yield k, [ns.key(None) for ns in E._node_successors(n)]


class TestSummaryRejection(unittest.TestCase):
    def helper(self, body):
        code = {0: ("call", 10, 62, 1), 1: ("jmp", 2), 2: ("call", 10, 62, 3), 3: ("jmp", 4), 4: ("halt",)}
        for i, ins in enumerate(body):
            code[10 + i] = ins
        code[10 + len(body)] = ("ret", 62, 1)
        return code

    def test_helper_with_a_register_effect_is_not_summarised(self):
        order, restart, lf, _ = walk(self.helper([("set", 7, 1), ("use", 7)]))
        rs = RS.of(lf)
        self.assertNotIn((0, 10), rs.summaries)
        self.assertIn((0, 10), rs.rejected)
        self.assertIn("IR statement", rs.rejected[(0, 10)])
        self.assertFalse(restart)
        self.assertEqual(E._closure_missing(order, dict(order), None), [])

    def test_helper_with_a_data_dependent_branch_is_not_summarised(self):
        order, restart, lf, _ = walk(self.helper([("brd", 7, 12), ("jmp", 12)]))
        rs = RS.of(lf)
        self.assertNotIn((0, 10), rs.summaries)
        self.assertIn("branch", rs.rejected.get((0, 10), ""))

    def test_rejected_helper_keeps_the_bounded_token_representation(self):
        order, restart, lf, _ = walk(self.helper([("set", 7, 1), ("use", 7)]), bound=0)
        rs = RS.of(lf)
        self.assertTrue(rs.tables, "the fallback is the phase-6 return table")
        self.assertEqual(rs.sum_hits, 0)

    def test_non_constant_link_is_never_summarised(self):
        code = {0: ("mov", 62, 5), 1: ("jmp", 10), 10: ("jmp", 11), 11: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code)
        self.assertEqual(RS.of(lf).sum_hits, 0)

    def test_summary_disabled_by_switch(self):
        order, restart, lf, _ = walk(trampoline(4, ret_off=1), summary=False)
        self.assertEqual(RS.of(lf).summaries, {})


class TestNestedAndCyclic(unittest.TestCase):
    def test_nested_helpers_with_different_link_registers(self):
        code = {0: ("call", 10, 62, 0), 1: ("call", 10, 62, 1), 2: ("halt",),
                10: ("call", 20, 61, 10), 11: ("ret", 62, 1),
                20: ("jmp", 21), 21: ("ret", 61, 1)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(E._closure_missing(order, dict(order), None), [])
        self.assertIn(2, pcs(order))

    def test_helper_called_in_a_loop_terminates(self):
        code = {0: ("call", 10, 62, 1), 1: ("br", 5, 0), 2: ("halt",), 10: ("jmp", 11), 11: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code, limit=2000)
        self.assertFalse(restart)
        self.assertLess(len(order), 200)

    def test_recursion_through_the_helper_terminates_and_is_reported_honestly(self):
        code = {0: ("call", 10, 62, 1), 1: ("halt",), 10: ("call", 10, 62, 11), 11: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code, limit=500)
        # recursion overwrites the link: either way the walk ends and never reports a summary for an impure chain
        self.assertLessEqual(len(order), 500)


class TestConformanceWithSummaries(unittest.TestCase):
    def test_real_steps_of_a_summarised_helper_are_swallowed_and_the_continuation_is_checked(self):
        # a one-frame trace over a toy lift: call(105) -> helper(75,75,108) -> continuation(12)
        class O:                       # minimal oracle
            mode_of_tag = {0: 239}

            def __init__(self, steps):
                self.trace = steps

            def aids_of(self, key):
                return {1}

            def __bool__(self):
                return True

        def v(pc, op):
            return 1 * CF.AID + 0 * CF.TAG + pc * CF.PC + op

        s_call, s_cont, s_h = (239, 5, 105), (239, 6, 12), (239, 50, 75)
        rec = {"proto": "p", "closure": None, "states": {s_call, s_cont, (239, 4, 65)},
               "edges": {((239, 4, 65), s_call), (s_call, s_cont)}, "stepped": 3, "errors": 0,
               "summaries": {s_call: {(239, 50, 52)}}}
        trace = [v(4, 65), v(5, 105), v(50, 75), v(51, 75), v(52, 108), v(6, 12)]
        rep = CF.check(O(trace), [rec], return_kinds=set())
        self.assertEqual(rep["failures"], [])
        self.assertEqual(rep["summarised_steps"], 3)
        self.assertEqual(rep["total"]["fail"], 0)
        # negative control: a real continuation the summary does not produce is a failure, not a pass
        bad = [v(4, 65), v(5, 105), v(50, 75), v(51, 75), v(52, 108), v(7, 12)]
        rec2 = dict(rec)
        rep2 = CF.check(O(bad), [rec2], return_kinds=set())
        self.assertGreater(rep2["total"]["fail"] + rep2["total"]["nosrc"], 0)


class TestScrubEquivalence(unittest.TestCase):
    """Instrumentation artefact (flow-insensitive shared overlay): a decryptor shows as its scrub no-op."""

    class O:
        mode_of_tag = {0: 239}

        def __init__(self, steps):
            self.trace = steps

        def aids_of(self, key):
            return {1}

        def __bool__(self):
            return True

    @staticmethod
    def v(pc, op):
        return 1 * CF.AID + pc * CF.PC + op

    def rec(self, ops):
        states = {(239, pc, op) for pc, op in ops}
        edges = {((239, a[0], a[1]), (239, b[0], b[1])) for a, b in zip(ops, ops[1:])}
        return {"proto": "p", "closure": None, "states": states, "edges": edges, "stepped": len(ops), "errors": 0,
                "summaries": {}}

    def test_decryptor_vs_scrub_is_reported_apart_from_ok(self):
        rec = self.rec([(1, 65), (2, 75), (3, 12)])                  # the lift decoded pc 2 as the scrub no-op
        trace = [self.v(1, 65), self.v(2, 19), self.v(3, 12)]         # the real run executed the decryptor there
        strict = CF.check(self.O(trace), [rec], set())
        self.assertGreater(strict["total"]["nosrc"] + strict["total"]["fail"], 0)
        relaxed = CF.check(self.O(trace), [rec], set(), scrub={(239, 19): 75})
        self.assertEqual(relaxed["total"]["fail"] + relaxed["total"]["nosrc"], 0)
        self.assertEqual(relaxed["total"]["ok_scrub_equivalent"], 1)
        self.assertEqual(relaxed["total"]["ok"], 1, "the equivalence is never folded into the strict count")
        self.assertEqual(relaxed["ratio"], 0.5)
        self.assertEqual(relaxed["ratio_scrub_equivalent"], 1.0)

    def test_negative_control_a_different_opcode_is_not_equivalent(self):
        rec = self.rec([(1, 65), (2, 75), (3, 12)])
        trace = [self.v(1, 65), self.v(2, 33), self.v(3, 12)]         # 33 is not a decryptor of this mode
        r = CF.check(self.O(trace), [rec], set(), scrub={(239, 19): 75})
        self.assertGreater(r["total"]["fail"] + r["total"]["nosrc"], 0)
        self.assertEqual(r["total"]["ok_scrub_equivalent"], 0)

    def test_later_activation_sees_the_decoded_cell_and_is_equivalent_to_the_lifted_decryptor(self):
        """Path-sensitive overlay: the lift shows the FIRST activation (the decryptor executes), a later real activation of
        the same proto runs on the already decoded cell (the scrub no-op).  Equivalent, reported apart from `ok`."""
        rec = self.rec([(1, 65), (2, 19), (3, 12)])
        trace = [self.v(1, 65), self.v(2, 75), self.v(3, 12)]
        strict = CF.check(self.O(trace), [rec], set())
        self.assertGreater(strict["total"]["nosrc"] + strict["total"]["fail"], 0)
        relaxed = CF.check(self.O(trace), [rec], set(), scrub={(239, 19): 75})
        self.assertEqual(relaxed["total"]["fail"] + relaxed["total"]["nosrc"], 0)
        self.assertEqual(relaxed["total"]["ok_scrub_equivalent"], 1)

    def test_negative_control_scrub_op_without_a_matching_decryptor_state_fails(self):
        rec = self.rec([(1, 65), (2, 33), (3, 12)])                   # the lift has op 33 there, not the decryptor
        trace = [self.v(1, 65), self.v(2, 75), self.v(3, 12)]
        r = CF.check(self.O(trace), [rec], set(), scrub={(239, 19): 75})
        self.assertGreater(r["total"]["fail"] + r["total"]["nosrc"], 0)


if __name__ == "__main__":
    unittest.main()

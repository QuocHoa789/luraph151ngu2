"""Tests of the Luraph v15.1 backend (core/obfuscators/luraph_v15_1).

    python3 tests/test_v151.py            (or: python3 -m unittest discover tests)

Environment:
    DEOB_V151_DUMP   path of a harness dump (`*.protos.json`) for the dump-based tests (skipped if unset/missing)
    DEOB_E2E=1       also run the real pipeline end to end (about 5 minutes) and report PASS / PARTIAL / FAIL
The end-to-end test never turns PARTIAL into PASS: it only passes when the
validator accepted the devirtualized output.
"""
import os
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CORE = os.path.join(ROOT, "core")
sys.path.insert(0, CORE)

SAMPLE = os.path.join(ROOT, "sample", "v15.1", "sa-obfuscated.lua.txt")
LUAU = os.path.join(ROOT, "bin", "luau")
DUMP = os.environ.get("DEOB_V151_DUMP")

from obfuscators.luraph_v15_1 import vmmap as VM                    # noqa: E402
from obfuscators.luraph_v15_1 import opcode_maps as OM              # noqa: E402
from obfuscators.luraph_v15_1 import bootstrap as BS                # noqa: E402
from obfuscators.luraph_v15_1 import stream_decoder as SD           # noqa: E402
from obfuscators.luraph_v15_1 import instruction_expander as IE     # noqa: E402
from obfuscators.luraph_v15_1 import closure as CL                  # noqa: E402
from obfuscators.luraph_v15_1 import ir_bridge as IR                # noqa: E402

_cache = {}


def ast():
    if "ast" not in _cache:
        _cache["ast"] = VM.load_ast(SAMPLE)
        with open(SAMPLE, encoding="latin-1") as f:
            _cache["src"] = f.read()
    return _cache["ast"], _cache["src"]


def mappers():
    if "mp" not in _cache:
        root, src = ast()
        _cache["mp"] = OM.build_mappers(root, src.split("\n"))
    return _cache["mp"]


@unittest.skipUnless(os.path.exists(SAMPLE) and os.path.exists(os.path.join(ROOT, "bin", "luau-ast")), "sample / luau-ast missing")
class StaticFacts(unittest.TestCase):
    def test_detector(self):
        from obfuscators.luraph_v15_1 import LuraphV151
        _, src = ast()
        self.assertEqual(LuraphV151().detect(src), 1.0)

    def test_dispatchers_and_modes(self):
        root, _ = ast()
        ds = VM.find_dispatchers(root)
        self.assertEqual(len(ds), 8)
        self.assertEqual(sum(d["form"] == "direct" for d in ds), 4)
        self.assertEqual(sum(d["form"] == "predicate" for d in ds), 4)
        modes = sorted(b.mode for b in VM.detect_v151_backend(root))
        self.assertEqual(modes, [40, 56, 73, 97, 118, 142, 217, 239])

    def test_makers(self):
        root, _ = ast()
        ms = VM.maker_info(root)
        self.assertEqual(sorted(len(m["maker"]["args"]) for m in ms), [14, 16])

    def test_handler_counts(self):
        got = {m: len(x.handlers()) for m, x in mappers().items()}
        self.assertEqual(got, {40: 56, 56: 41, 73: 86, 97: 121, 118: 84, 142: 55, 217: 75, 239: 125})

    def test_known_opcodes(self):
        mp = mappers()
        self.assertEqual(mp[97].get(71).kind, "BLOB_DECRYPT")
        self.assertEqual(mp[239].get(41).kind, "CLOSURE")
        # shared leaf `if S<75 .. elseif S~=76 .. else ..` is specialised per opcode
        self.assertEqual(mp[73].get(75).kind, "COMPARE")
        self.assertEqual(mp[73].get(75).pc_effect, "NEXT")
        self.assertEqual(mp[73].get(76).kind, "MODE_SWITCH")
        self.assertEqual(mp[73].get(74).kind, "ARITH")

    def test_mapper_api(self):
        mp = mappers()
        self.assertIs(OM.get_opcode_mapper(73, mp), mp[73])
        self.assertIsNone(OM.get_opcode_mapper(999, mp))
        for m in mp.values():
            for s in m.handlers():
                self.assertIn(s.pc_effect, IR.PC_EFFECTS)
                self.assertTrue(0.0 <= s.confidence <= 1.0)

    def test_expanders_found(self):
        ex = IE.find_expanders(mappers())
        self.assertEqual(len(ex), 13)
        self.assertIn((73, 1), [(m, o) for m, o, _ in ex])

    def test_bootstrap(self):
        root, _ = ast()
        info = BS.analyze(root)
        self.assertTrue(info["found"])
        self.assertEqual(info["entry"], "ZV")
        self.assertEqual(info["blob"]["length"], 977820)
        self.assertTrue(info["blob"]["looks_like_luraph"])
        self.assertGreaterEqual(info["confidence"], 0.9)

    def test_bootstrap_not_v151(self):
        info = BS.analyze({"body": [], "type": "AstStatBlock"})
        self.assertFalse(info["found"])


class Primitives(unittest.TestCase):
    def test_varint(self):
        self.assertEqual(SD.read_varint(bytes([5]), 0), (5, 1))
        self.assertEqual(SD.read_varint(bytes([129, 3]), 0), (131, 2))
        with self.assertRaises(SD.StreamError):
            SD.read_varint(bytes([200]), 0)

    def test_decrypt_errors(self):
        with self.assertRaises(SD.StreamError):
            SD.decrypt_blob(bytearray(10), [123456789], 1, 3)       # offset outside the buffer

    def test_expander_bounds(self):
        self.assertTrue(IE.self_check())
        e = IE.Expander(max_per_pc=100, max_total=2)
        e.begin_step(1, 1)
        e.record(1, 1, 1, "a")
        e.record(1, 1, 1, "b")
        with self.assertRaises(IE.ExpansionLimit):
            e.record(1, 1, 1, "c")
        e = IE.Expander()
        e.begin_step(1, 1)
        e.record(1, 1, 1, "a")
        with self.assertRaises(IE.ExpansionLimit):                  # same pc decoded to the same thing twice = cycle
            e.record(1, 1, 1, "a")

    def test_closure_graph(self):
        g = CL.ClosureGraph()
        g.edge("a", "b")
        g.edge("b", "c")
        g.edge("c", "b")
        self.assertEqual(g.roots(), ["a"])
        self.assertEqual(sorted(g.recursive()), ["b", "c"])
        self.assertEqual(g.depth(), 3)
        small = CL.ClosureGraph()
        CL.MAX_NODES, old = 2, CL.MAX_NODES
        try:
            small.edge("x", "y")
            self.assertFalse(small.edge("x", "z"))
            self.assertTrue(small.overflow)
        finally:
            CL.MAX_NODES = old

    def test_ir_bridge(self):
        mp = mappers() if (os.path.exists(SAMPLE) and os.path.exists(os.path.join(ROOT, "bin", "luau-ast"))) else {}
        n = IR.normalize(None, 5, 1, 9)
        self.assertEqual((n.kind, n.pc_effect), ("UNKNOWN", "NEXT"))
        u = IR.V151Unknown(73, 12, [1, 2], "why").text()
        self.assertEqual(u, "V151_UNKNOWN(mode=73, opcode=12, operands=[1, 2]): why")
        if mp:
            t = IR.unknown_text(mp[73], 73, 75, "boom")
            self.assertIn("kind=COMPARE", t)
            self.assertTrue(t.startswith("V151_UNKNOWN(mode=73, opcode=75"))


@unittest.skipUnless(os.path.exists(LUAU) and os.path.exists(SAMPLE), "bin/luau or sample missing")
class DecryptMatchesHandler(unittest.TestCase):
    """decrypt_blob() against the *real* BLOB_DECRYPT handler text (mode 97 op 71) run by Luau."""

    def handler_text(self):
        root, src = ast()
        d = VM.find_dispatchers(root)[1]                            # mode 97
        blk = VM.resolve_op(d, 71)
        return VM.text_of(src.split("\n"), blk)

    def run_case(self, seed, n, key, z0):
        rnd = random.Random(seed)
        buf = bytearray(rnd.randrange(256) for _ in range(z0 + 1 + 4 + n + 8))
        # varint of n at z0+1 (1..2 bytes)
        if n < 128:
            buf[z0 + 1] = n
        else:
            buf[z0 + 1], buf[z0 + 2] = 128 + n // 128, n % 128
        off = z0 ^ SD.OFFSET_KEY
        lua = """
local X,T,d,j,y=bit32.bxor,buffer.readu8,buffer.readu32,buffer.writeu32,buffer.writeu8
local hex=%r
local b=buffer.create(#hex//2)
for k=1,#hex//2 do buffer.writeu8(b,k-1,tonumber(hex:sub(2*k-1,2*k),16)) end
local s,H,R,A={[1]=1},{[1]=%d},{[1]=0},{[1]=0}
local _={[7]={[1]=%d},[6]=b}
local i=1
s[1]=1
%s
local out={}
for k=0,buffer.len(b)-1 do out[#out+1]=string.format("%%02x",buffer.readu8(b,k)) end
print(table.concat(out))
print(_[7][1])
"""
        h = self.handler_text()
        lua = lua % (bytes(buf).hex(), key, off, h.replace("s[i]=218;H[i]=169;R[i]=51;A[i]=24;", ""))
        with tempfile.NamedTemporaryFile("w", suffix=".luau", delete=False) as f:
            f.write(lua)
            path = f.name
        try:
            r = subprocess.run([LUAU, path], capture_output=True, text=True, timeout=60)
        finally:
            os.unlink(path)
        self.assertEqual(r.returncode, 0, r.stderr)
        got_hex, got_off = r.stdout.split("\n")[:2]
        ref = bytearray(buf)
        offsets = [off]
        SD.decrypt_blob(ref, offsets, 1, key)
        self.assertEqual(got_hex, bytes(ref).hex())
        self.assertEqual(int(got_off), offsets[0])

    def test_equivalence(self):
        # NB: handler variable names (s, H, _, X, T, d, j, y) are SAMPLE-SPECIFIC
        for seed, n, key, z0 in [(1, 5, 7, 3), (2, 64, 200, 10), (3, 131, 1, 0), (4, 3, 255, 17), (5, 100, 77, 1)]:
            with self.subTest(n=n, key=key):
                self.run_case(seed, n, key, z0)


@unittest.skipUnless(DUMP and os.path.exists(DUMP), "set DEOB_V151_DUMP to a harness dump")
class DumpBased(unittest.TestCase):
    def test_streams(self):
        ds = SD.DumpStreams(DUMP)
        self.assertEqual(len(ds), 34)
        self.assertGreater(ds.total_instructions(), 20000)
        self.assertTrue(all(p.length > 0 for p in ds.protos))

    def test_closure_graph(self):
        g = CL.from_dump(DUMP).summary()
        self.assertEqual(g["protos"], 34)
        self.assertEqual(g["roots"], 1)
        self.assertEqual(g["recursive"], 0)

    def test_debug_report(self):
        from obfuscators.luraph_v15_1 import debug_report
        lines = debug_report.report_lines(SAMPLE, DUMP)
        text = "\n".join(lines)
        for key in ("detected: yes", "backend mode", "dispatcher: 8", "opcode count", "stream decoded: 34",
                    "closures recovered"):
            self.assertIn(key, text)


class V15Untouched(unittest.TestCase):
    def test_private_engine_copy(self):
        from obfuscators.luraph_v15 import devirt as v15
        from obfuscators.luraph_v15_1 import devirt as v151
        self.assertIsNot(v15, v151)
        self.assertFalse(hasattr(v15, "V151VMModel"))
        self.assertTrue(hasattr(v151._E, "V151VMModel") or hasattr(v151._E, "make_stepper"))
        self.assertIsNot(v15.Program, v151._E.Program)

    def test_v15_files_unchanged(self):
        ref = os.environ.get("DEOB_V15_REFERENCE")      # directory with the original luraph_v15 + src/vmmap.js
        if not ref:
            self.skipTest("set DEOB_V15_REFERENCE to the original tree")
        for rel in ("core/obfuscators/luraph_v15/devirt.py", "core/obfuscators/luraph_v15/vmmap.py" if
                    os.path.exists(os.path.join(ref, "core/obfuscators/luraph_v15/vmmap.py")) else "src/vmmap.js"):
            with open(os.path.join(ROOT, rel), "rb") as a, open(os.path.join(ref, rel), "rb") as b:
                self.assertEqual(a.read(), b.read(), rel)


@unittest.skipUnless(os.environ.get("DEOB_V15_BASELINE") and os.path.exists(os.path.join(ROOT, "sample", "RideAPet.lua")),
                     "set DEOB_V15_BASELINE to a baseline RideAPet.lua output (about 1 minute)")
class V15Regression(unittest.TestCase):
    """V15 must keep producing byte-identical output."""

    def test_rideapet_byte_identical(self):
        with tempfile.TemporaryDirectory() as td:
            out = os.path.join(td, "RideAPet.lua")
            r = subprocess.run(["node", os.path.join(ROOT, "deob.js"), os.path.join(ROOT, "sample", "RideAPet.lua"), "-o", out],
                               capture_output=True, text=True, timeout=1800)
            self.assertEqual(r.returncode, 0, r.stderr[-1500:])
            with open(out, "rb") as a, open(os.environ["DEOB_V15_BASELINE"], "rb") as b:
                self.assertEqual(a.read(), b.read())


@unittest.skipUnless(os.environ.get("DEOB_E2E") == "1" and os.path.exists(SAMPLE), "set DEOB_E2E=1 (about 5 minutes)")
class EndToEnd(unittest.TestCase):
    """Runs the real pipeline.  The test checks that the verdict is HONEST (it does not require a PASS):
    PASS only with zero unlifted blocks / nil calls and a conformant trace, and a devirtualized file
    only for a PASS.  PARTIAL is never accepted as PASS."""

    def test_sample(self):
        import glob
        import json
        with tempfile.TemporaryDirectory() as td:
            out = os.path.join(td, "out.lua")
            r = subprocess.run(["node", os.path.join(ROOT, "deob.js"), SAMPLE, "-o", out, "--debug", "--debug-v151"],
                               capture_output=True, text=True, timeout=7200)
            log = r.stderr
            self.assertIn("[V15.1] detected: yes", log)
            diags = glob.glob(os.path.join(td, "**", "*.v151diag.json"), recursive=True) + \
                glob.glob(os.path.join(os.path.dirname(out), "**", "*.v151diag.json"), recursive=True)
            if "verdict: BLOCKED" in log:                     # no native runtime on this machine: nothing to check further
                self.skipTest("BLOCKED: " + log[-300:])
            self.assertTrue(diags, "no .v151diag.json was written\n" + log[-2000:])
            doc = json.load(open(diags[0], encoding="utf-8"))
            verdict = doc["verdict"]
            print("\nEND-TO-END VERDICT: %s  %s" % (verdict, json.dumps(doc["metrics"])))
            self.assertIn(verdict, ("PASS", "PARTIAL", "BLOCKED", "FAIL"))
            m = doc["metrics"]
            if (m.get("unlifted_blocks") or 0) > 0 or (m.get("nil_calls") or 0) > 0:
                self.assertNotEqual(verdict, "PASS", "PARTIAL must never be reported as PASS")
            devirt = glob.glob(os.path.join(td, "**", "*.devirt.luau"), recursive=True)
            if verdict != "PASS":
                self.assertFalse(devirt, "devirtualized source was emitted without a PASS verdict")
            else:
                self.assertEqual(m.get("unlifted_blocks"), 0)
                self.assertEqual(m.get("nil_calls"), 0)
                self.assertTrue(doc["validated_against_trace"])


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Phase 8 (part 3): helper-summary boundary conditions, resource limits, protected files, validator.

EVIDENCE CLASS: SYNTHETIC (fake lifters / stand-in steppers on the real patched walk), except
`TestProtectedFiles` (a check of the files in this source tree).  None of these tests is evidence that the
sample is devirtualised.
"""
import hashlib
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from obfuscators.luraph_v15_1 import devirt as D                     # noqa: E402
from obfuscators.luraph_v15_1 import engine_patch as EP              # noqa: E402
from obfuscators.luraph_v15_1 import retsite as RS                   # noqa: E402
from obfuscators.luraph_v15_1 import helpersum as HS                 # noqa: E402
from obfuscators.luraph_v15_1 import validator as V                  # noqa: E402
import test_v151_retsite as T                                        # noqa: E402
import test_v151_phase8 as P8                                        # noqa: E402

E = D._E


class _Lf(T.FakeLifter):
    def __init__(self):
        T.FakeLifter.__init__(self)
        self.mutated = False
        self.last_op = (0, "x")
        self.link_regs = {62}
        self.proto_arrays = set()
        self.ov = None


def _note(rs, lf, state, ns, keys=(), kvals=(), nstmts=0, ndec=0):
    lf.jvals = dict(state.jregs)
    HS.note_step(lf, rs, state, ns, keys, kvals, nstmts, ndec, None)


def _state(pc, jr=(), keys=(), kv=()):
    return E.State151(0, pc, None, tuple(jr), None, (), (), keys, kv)


class TestHelperBoundaryEffects(unittest.TestCase):
    """What a helper step must NOT do for it to be summarised (the summary has no way to carry it)."""

    def setUp(self):
        self.lf = _Lf()
        self.rs = RS.of(self.lf)

    def test_decode_key_update_inside_a_helper_makes_it_impure(self):
        st = _state(10, keys=(("Z", 1),))
        ns = _state(11, keys=(("Z", 2),))                      # the helper rewrites a decode key
        _note(self.rs, self.lf, st, ns, keys=ns.keys)
        f = self.rs.facts[(0, 10)]
        self.assertFalse(f["pure"])
        self.assertIn("decode keys", f["why"])

    def test_negative_control_unchanged_decode_keys_are_pass_through(self):
        st = _state(10, keys=(("Z", 1),))
        ns = _state(11, keys=(("Z", 1),))
        _note(self.rs, self.lf, st, ns, keys=ns.keys)
        f = self.rs.facts[(0, 10)]
        self.assertTrue(f["pure"], f["why"])

    def test_dynamic_instruction_materialisation_is_never_summarised(self):
        st = _state(10)
        ns = _state(10)                                         # in-place re-decode: the same pc again
        self.lf.mutated = True
        _note(self.rs, self.lf, st, ns)
        f = self.rs.facts[(0, 10)]
        self.assertFalse(f["pure"])
        self.assertIn("expansion", f["why"])

    def test_register_side_effect_is_not_summarised(self):
        st = _state(10)
        ns = _state(11)
        _note(self.rs, self.lf, st, ns, nstmts=2)
        self.assertFalse(self.rs.facts[(0, 10)]["pure"])

    def test_tracked_register_constant_change_is_not_summarised(self):
        st = _state(10, kv=(("r1", 5),))
        ns = _state(11, kv=(("r1", 6),))
        _note(self.rs, self.lf, st, ns, kvals=ns.kvals)
        self.assertIn("tracked register", self.rs.facts[(0, 10)]["why"])


class TestUnknownSemanticsAreNotGuessed(unittest.TestCase):
    def test_unsupported_step_is_an_error_node_without_successors(self):
        class Bad(T.FakeStepper):
            def step(self, state, prefix):
                if state.pc == 1:
                    raise E.Unsupported("V151_UNKNOWN(mode=0, opcode=77): kind=UNKNOWN; no semantics")
                return T.FakeStepper.step(self, state, prefix)
        lf = T.FakeLifter()
        st = Bad({0: ("jmp", 1), 1: ("jmp", 2), 2: ("halt",)}, lf)
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, 1000)
        nodes = dict((k[1], n) for k, n in order)
        self.assertIn("V151_UNKNOWN", nodes[1].error)
        self.assertEqual(E._node_successors(nodes[1]), [])        # no invented continuation
        self.assertNotIn(2, nodes)                                 # the code behind it is not reached through a guess


class TestResourceLimits(unittest.TestCase):
    def test_a_state_ceiling_is_a_partial_result_not_a_closed_cfg(self):
        code = {i: ("jmp", i + 1) for i in range(60)}
        code[60] = ("halt",)
        old = (E.WALK_MAX_STATES, E.WALK_RECOVERY_LIMIT)
        E.WALK_MAX_STATES, E.WALK_RECOVERY_LIMIT = 8, 4
        try:
            lf = T.FakeLifter()
            st = T.FakeStepper(code, lf)
            prog = E.Program.__new__(E.Program)
            s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, 8)
        finally:
            E.WALK_MAX_STATES, E.WALK_RECOVERY_LIMIT = old
        info = order.info
        self.assertFalse(info["closed"])
        self.assertGreater(info["pending"], 0)
        self.assertLess(len(order), 61)
        self.assertNotEqual(info["final_stop"], "done")

    def test_positive_control_with_enough_budget_the_same_program_closes(self):
        code = {i: ("jmp", i + 1) for i in range(60)}
        code[60] = ("halt",)
        lf = T.FakeLifter()
        st = T.FakeStepper(code, lf)
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, 5000)
        self.assertTrue(order.info["closed"])
        self.assertEqual(len(order), 61)

    def test_loop_stack_depth_growth_is_quarantined_and_reported_not_dropped(self):
        EPm = EP
        self.assertTrue(hasattr(EPm, "DEPTH_CAP"))
        self.assertGreater(EPm.DEPTH_CAP, 0)
        # the quarantine raises Unsupported (an error node that the diagnostics report), never returns silently
        import inspect
        src = inspect.getsource(EPm.install)
        self.assertIn("states above depth cap", src)
        self.assertIn("note_depth_growth", src)


class TestWorklistOrder(unittest.TestCase):
    def test_orders_visit_the_same_fixed_point_on_a_closed_program(self):
        code = {0: ("br", 5, 4), 1: ("jmp", 2), 2: ("jmp", 3), 3: ("halt",), 4: ("jmp", 5), 5: ("halt",)}
        res = {}
        old = EP.ORDER
        try:
            for o in ("lifo", "fifo", "novel"):
                EP.ORDER = o
                lf = T.FakeLifter()
                st = T.FakeStepper(code, lf)
                prog = E.Program.__new__(E.Program)
                s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, 1000)
                res[o] = (sorted(k for k, _ in order), order.info["closed"])
        finally:
            EP.ORDER = old
        # NOTE: the fake walk calls the original pick (the needle patch lives in the private engine copy), so this only
        # checks that the knob does not change what a closed program contains
        self.assertEqual(res["lifo"], res["fifo"])
        self.assertEqual(res["lifo"], res["novel"])
        self.assertTrue(res["lifo"][1])

    def test_pick_policies(self):
        class St:
            pass
        st = St()
        old = EP.ORDER
        try:
            EP.ORDER = "lifo"
            w = [(0, 1), (0, 2), (0, 3)]
            self.assertEqual(E._v151_pick(w, st), (0, 3))
            EP.ORDER = "fifo"
            w = [(0, 1), (0, 2), (0, 3)]
            self.assertEqual(E._v151_pick(w, st), (0, 1))
            EP.ORDER = "novel"
            st = St()
            st._v151_seen = {(0, 3)}
            w = [(0, 1), (0, 3), (0, 3)]
            self.assertEqual(E._v151_pick(w, st), (0, 1))          # the never-visited instruction first
            self.assertEqual(E._v151_pick(w, st), (0, 3))          # then newest first
        finally:
            EP.ORDER = old


class TestProtectedFiles(unittest.TestCase):
    FILES = ("__init__", "devirt", "driver", "vmmap")

    def test_v15_files_match_the_recorded_hashes(self):
        rec = os.path.join(ROOT, "research", "phase8", "v15_protected_hashes_before.txt")
        if not os.path.exists(rec):
            self.skipTest("hash record not shipped in this tree")
        want = {}
        with open(rec) as fh:
            for line in fh:
                if line.strip():
                    h, p = line.split()
                    want[p] = h
        self.assertEqual(len(want), 4)
        for p, h in want.items():
            with open(os.path.join(ROOT, p), "rb") as fh:
                self.assertEqual(hashlib.sha256(fh.read()).hexdigest(), h, p)


class TestVerdictNeverPassesOnAPartialLift(unittest.TestCase):
    CLEAN = {"decode": {"protos": 3, "instructions": 10}, "lift": {"ran": True}, "unlifted_blocks": 0, "nil_calls": 0,
             "unknown_opcode_steps": 0, "closure": {"entered_not_lifted": [], "dangling_edges": 0},
             "conformance": {"verdict": "CONFORMANT", "conformant": True, "total": {}}}

    def test_positive_control_everything_clean_passes(self):
        self.assertEqual(V.evaluate(dict(self.CLEAN))["verdict"], V.PASS)

    def test_pending_work_is_a_budget_verdict_never_pass(self):
        r = V.evaluate(dict(self.CLEAN, lift={"ran": True, "budget": {"blocks": 15000, "walk": {"closed": False, "pending": 391}}}))
        self.assertEqual(r["verdict"], V.PARTIAL)
        self.assertFalse(r["emit_source"])

    def test_non_conformant_trace_is_partial(self):
        cf = {"verdict": "NOT_CONFORMANT", "conformant": False, "total": {"fail": 3, "nosrc": 0, "entry_fail": 0}}
        r = V.evaluate(dict(self.CLEAN, conformance=cf))
        self.assertEqual(r["verdict"], V.PARTIAL)

    def test_missing_runtime_is_blocked_not_partial(self):
        r = V.evaluate(dict(self.CLEAN, runtime={"available": False, "reason": "no luau"}))
        self.assertEqual(r["verdict"], V.BLOCKED)


if __name__ == "__main__":
    unittest.main()

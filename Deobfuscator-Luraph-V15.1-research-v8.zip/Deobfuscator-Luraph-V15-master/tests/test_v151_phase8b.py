"""Phase 8 (part 2): path-sensitive instruction overlay, structural overlay identity, helper summaries over
self-modifying first executions, and the state-difference diagnostic.

EVIDENCE CLASS: SYNTHETIC.  Miniature register VM on the real patched walk (see test_v151_phase8.py / test_v151_retsite.py);
nothing here is evidence that the sample is devirtualised.  Every state-merge test has a positive control (states that
must merge do) and a negative control (states that must stay apart do).
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from obfuscators.luraph_v15_1 import devirt as D                     # noqa: E402
from obfuscators.luraph_v15_1 import engine_patch as EP              # noqa: E402
from obfuscators.luraph_v15_1 import retsite as RS                   # noqa: E402
from obfuscators.luraph_v15_1 import helpersum as HS                 # noqa: E402
from obfuscators.luraph_v15_1 import state_diff as SD                # noqa: E402
import test_v151_retsite as T                                        # noqa: E402

E = D._E
AID = 777                                                            # id() of the fake instruction array


# --------------------------------------------------------------------------------------------- overlay identity
class TestOverlayIdentity(unittest.TestCase):
    def _ov(self, writes, parent=None):
        o = E.Overlay(parent)
        for key, v, base in writes:
            o.set(key, v, base)
        return o

    def test_same_content_in_another_order_has_the_same_hash(self):
        a = self._ov([((AID, 1), 5, 0), ((AID, 2), 6, 0)])
        b = self._ov([((AID, 2), 6, 0), ((AID, 1), 5, 0)])
        self.assertEqual(a.h, b.h)

    def test_layers_applied_in_two_steps_equal_one_step(self):
        a = self._ov([((AID, 1), 5, 0)])
        a = self._ov([((AID, 1), 9, 0)], a)
        b = self._ov([((AID, 1), 9, 0)])
        self.assertEqual(a.h, b.h)

    def test_negative_control_different_cell_value_differs(self):
        self.assertNotEqual(self._ov([((AID, 1), 5, 0)]).h, self._ov([((AID, 1), 6, 0)]).h)
        self.assertNotEqual(self._ov([((AID, 1), 5, 0)]).h, self._ov([((AID, 2), 5, 0)]).h)

    def test_a_symbolic_value_is_identified_by_structure_not_by_object(self):
        """Measured on the sample: a loop that re-stored a register expression into one cell made a new state per
        iteration, because the content hash used id() of the carrier object."""
        a = self._ov([((AID, 1), E.Reg(5), 0)])
        b = self._ov([((AID, 1), E.Reg(5), 0)])          # a different object, the same expression
        self.assertEqual(a.h, b.h)
        self.assertNotEqual(a.h, self._ov([((AID, 1), E.Reg(6), 0)]).h)      # negative control


# --------------------------------------------------------------------------------------------- path-sensitive overlay
class _FakeStepper:
    def __init__(self):
        self._ov_empty = E.Overlay()
        self.cur_ov = self._ov_empty


class TestPathSensitiveProxy(unittest.TestCase):
    def test_reads_follow_the_overlay_of_the_state_being_stepped(self):
        st = _FakeStepper()
        gov = E._make_gov(st)
        a = E.Overlay()
        a.set((AID, 1), 5, 0)
        b = E.Overlay()
        b.set((AID, 1), 6, 0)
        st.cur_ov = a
        self.assertEqual(gov.get((AID, 1), 0), 5)
        st.cur_ov = b                                    # another path: it does not see the first path's write
        self.assertEqual(gov.get((AID, 1), 0), 6)
        st.cur_ov = st._ov_empty
        self.assertEqual(gov.get((AID, 1), 0), 0)

    def test_the_global_merge_of_a_steps_writes_is_a_no_op(self):
        st = _FakeStepper()
        gov = E._make_gov(st)
        gov.d.update({(AID, 1): 5})
        self.assertEqual(gov.get((AID, 1), 0), 0)

    def test_writes_of_a_step_chain_onto_the_current_path_overlay(self):
        st = _FakeStepper()
        gov = E._make_gov(st)
        a = E.Overlay()
        a.set((AID, 1), 5, 0)
        st.cur_ov = a
        w = E.Overlay(gov)                               # what ProtoLifter.write_ov does
        w.set((AID, 2), 7, 0)
        self.assertEqual(w.get((AID, 1), 0), 5)          # earlier layer on this path is visible
        self.assertEqual(w.get((AID, 2), 0), 7)
        self.assertNotEqual(w.h, a.h)

    def test_two_paths_with_the_same_layers_in_a_different_order_merge_positive_control(self):
        st = _FakeStepper()
        gov = E._make_gov(st)

        def apply(order):
            cur = st._ov_empty
            for cell, v in order:
                st.cur_ov = cur
                w = E.Overlay(gov)
                w.set((AID, cell), v, 0)
                eff = E.Overlay(cur)
                eff.d, eff.h = w.d, w.h
                cur = eff
            return cur
        self.assertEqual(apply([(1, 5), (2, 6)]).h, apply([(2, 6), (1, 5)]).h)
        self.assertNotEqual(apply([(1, 5), (2, 6)]).h, apply([(1, 5)]).h)             # negative control


# --------------------------------------------------------------------------------------------- self-modifying helper
class OvStepper(T.FakeStepper):
    """Like P8Stepper, plus the instruction `("wr", cell, value)`: the first execution on a path writes `value` into an
    instruction cell (a one-shot decode, recorded in the state's own overlay); later executions on that path do not."""

    def initial(self):
        return E.State(0, 0, None, (), None, (), ())

    def step(self, state, prefix):
        lf = self.lf
        lf.jvals = dict(state.jregs)
        lf.jread = set()
        lf.link_new = {}
        lf.mutated = False
        lf.ov = None
        lf.proto_arrays = {AID}
        ins = self.code[state.pc]
        out = []
        op = ins[0]
        nxt = state.pc + 1
        cond = None
        pc_expr = None
        ret = False
        newov = state.ov
        if op == "set":
            self._emit_assign(lf, ins[1], E.Const(ins[2]), out)
        elif op == "call":
            self._emit_assign(lf, ins[2], E.Const(ins[3]), out)
            nxt = ins[1]
        elif op == "jmp":
            nxt = ins[1]
        elif op == "ret":
            v = self._read(lf, ins[1])
            pc_expr = v if ins[2] == 0 else (v + ins[2] if isinstance(v, int) else E.Bin("Add", v, E.Const(ins[2])))
        elif op == "br":
            cond = E.Reg(ins[1])
        elif op == "halt":
            ret = True
        elif op == "wr":
            key = (AID, ins[1])
            if state.ov is None or state.ov.get(key, HS._MISSING) is HS._MISSING:
                w = E.Overlay(state.ov)
                w.set(key, ins[2], 0)
                lf.ov = w
                newov = w
        lf.last_op = (0, op)

        def state_to(pc):
            jr = tuple(sorted(((k, v) for k, v in lf.jvals.items() if k not in lf.jread), key=lambda kv: kv[0]))
            ns = E.State(0, pc, None, jr, newov, state.packs, state.locs)
            rs = RS.of(lf)
            HS.note_step(lf, rs, state, ns, (), (), len(out), 1 if cond is not None else 0, None)
            return RS.finish_state(lf, state, ns)

        if ret:
            return E.Node(out, outcome=E.Ret(E.Multi([])))
        if cond is not None:
            lf.jvals = dict(state.jregs)
            t = E.Node([], outcome=E.Next(state_to(ins[2])))
            e = E.Node([], outcome=E.Next(state_to(nxt)))
            return E.Node(out, cond=cond, then=t, els=e)
        if pc_expr is not None:
            return E.Node(out, outcome=E.Next(state_to(pc_expr)))
        return E.Node(out, outcome=E.Next(state_to(nxt)))


def walk(code, bound=12, limit=50000):
    old = (EP.RETSITE_ON, RS.MIN_SITES, HS.ON)
    EP.RETSITE_ON, RS.MIN_SITES, HS.ON = True, bound, True
    try:
        lf = T.FakeLifter()
        st = OvStepper(code, lf)
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(T._Vm(), lf, st, limit)
        return order, restart, lf, prog
    finally:
        EP.RETSITE_ON, RS.MIN_SITES, HS.ON = old


def decrypting_helper(ncallers, link=62, entry=100):
    code, pc = {}, 0
    for i in range(ncallers):
        code[pc] = ("call", entry, link, pc + 1)
        code[pc + 1] = ("set", 20, i)
        pc += 2
    code[pc] = ("halt",)
    code[entry] = ("wr", entry, 1)          # first execution on a path decodes its own cell
    code[entry + 1] = ("jmp", entry + 2)
    code[entry + 2] = ("ret", link, 0)
    return code


def helper_states(order, entry=100):
    return [k for k, _ in order if entry <= k[1] <= entry + 2]


class TestSelfModifyingHelperSummary(unittest.TestCase):
    def test_a_one_shot_decode_does_not_poison_the_summary(self):
        order, restart, lf, prog = walk(decrypting_helper(5))
        rs = RS.of(lf)
        f = rs.facts[(0, 100)]
        self.assertTrue(f["pure"], f["why"])
        self.assertGreaterEqual(f["wrote"], 1)                       # the self-modifying pass was seen and kept apart
        self.assertIn((0, 100), rs.summaries)

    def test_callers_after_the_decode_use_the_summary(self):
        order, restart, lf, prog = walk(decrypting_helper(6))
        rs = RS.of(lf)
        self.assertGreater(rs.sum_hits, 0)
        # without the summary every caller would step the three helper instructions
        self.assertLess(len(helper_states(order)), 3 * 6)

    def test_negative_control_a_path_that_did_not_decode_is_not_summarised(self):
        """Branch: path A calls the helper three times, path B calls it once.  On path B the helper cell is still undecoded when
        the call happens, so the summary (observed on decoded cells) must NOT be applied to it: the helper is stepped."""
        entry, link = 100, 62
        code = {
            0: ("br", 5, 20),
            1: ("call", entry, link, 2), 2: ("jmp", 3),
            3: ("call", entry, link, 4), 4: ("jmp", 5),
            5: ("call", entry, link, 6), 6: ("halt",),
            20: ("call", entry, link, 21), 21: ("halt",),
            entry: ("wr", entry, 1), entry + 1: ("jmp", entry + 2), entry + 2: ("ret", link, 0),
        }
        order, restart, lf, prog = walk(code)
        rs = RS.of(lf)
        self.assertIn((0, entry), rs.summaries)
        undecoded = [k for k, _ in order if k[1] == entry and k[4] == 0]       # entry states whose overlay holds no decode
        decoded = [k for k, _ in order if k[1] == entry and k[4] != 0]
        self.assertGreaterEqual(len(undecoded), 1)                    # stepped (the decode really happens on that path)
        self.assertGreaterEqual(rs.sum_hits, 1)                       # positive control: the decoded call used the summary
        self.assertEqual([k[3] for k in decoded], [((link, 4),)])     # only the pass the summary was learned from was stepped;
        #                                                               the third call (return to 6) went straight to its continuation

    def test_summary_vs_direct_interpretation_same_continuations(self):
        code = decrypting_helper(4)
        on = walk(code)
        old = HS.ON
        HS.ON = False
        try:
            off = walk(code)
        finally:
            HS.ON = old
        conts_on = sorted({k[1] for k, _ in on[0] if k[1] < 100})
        conts_off = sorted({k[1] for k, _ in off[0] if k[1] < 100})
        self.assertEqual(conts_on, conts_off)


# --------------------------------------------------------------------------------------------- state diff diagnostic
class TestStateDiff(unittest.TestCase):
    def key(self, **kw):
        base = dict(mode=0, pc=5, depth=0, jregs=((62, 7),), ov=0, packs=(), locs=(), keys=(("Z", 1), ("J", 2)), kvals=())
        base.update(kw)
        return tuple(base[c] for c in SD.COMPONENTS)

    def test_reports_exactly_the_differing_components(self):
        d = SD.diff_keys(self.key(), self.key(jregs=((62, 9),), keys=(("Z", 1), ("J", 3))))
        self.assertEqual(sorted(d), ["jregs", "keys"])
        self.assertEqual(d["jregs"], {"62": ("7", "9")})
        self.assertEqual(d["keys"], {"J": ("2", "3")})

    def test_equal_keys_have_no_difference(self):
        self.assertEqual(SD.diff_keys(self.key(), self.key()), {})

    def test_overlay_difference_names_the_cells(self):
        a, b = E.Overlay(), E.Overlay()
        a.set((AID, 3), 5, 0)
        b.set((AID, 3), 6, 0)
        b.set((AID, 9), 1, 0)
        d = SD.ov_diff(a, b)
        self.assertEqual(d["entries"], 2)
        self.assertEqual((d["first_cell"], d["last_cell"]), (3, 9))

    def test_explain_marks_dead_decode_keys_as_concrete_and_live_ones_as_genuine(self):
        d = SD.diff_keys(self.key(), self.key(keys=(("Z", 1), ("J", 3))))
        dead = SD.explain(d, live=set())[0]
        live = SD.explain(d, live={"J"})[0]
        self.assertIn("concrete", dead["verdict"])
        self.assertIn("genuine", live["verdict"])                    # negative control: the same difference, but read later

    def test_explain_without_evidence_says_unknown(self):
        d = SD.diff_keys(self.key(), self.key(locs=(("x", 1),)))
        self.assertEqual(SD.explain(d)[0]["verdict"], "unknown")

    def test_link_register_difference_of_a_pure_helper_is_the_continuation_input(self):
        d = SD.diff_keys(self.key(), self.key(jregs=((62, 9),)))
        row = SD.explain(d, facts={(0, 5): {"pure": True}}, mode_pc=(0, 5))[0]
        self.assertIn("genuine", row["verdict"])

    def test_representatives_differ_in_different_components(self):
        ks = [self.key(), self.key(jregs=((62, 9),)), self.key(jregs=((62, 11),)), self.key(keys=(("Z", 5), ("J", 2)))]
        reps = SD.representatives(ks, 3)
        self.assertEqual(reps[0], ks[0])
        self.assertEqual(len(reps), 3)
        self.assertNotEqual(sorted(SD.diff_keys(reps[0], reps[1])), sorted(SD.diff_keys(reps[0], reps[2])))


if __name__ == "__main__":
    unittest.main()

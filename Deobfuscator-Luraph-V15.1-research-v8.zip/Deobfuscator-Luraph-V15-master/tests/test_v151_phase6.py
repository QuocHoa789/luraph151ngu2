"""Phase-6 tests: root-cause classes, the machine-readable unlifted-block / nil-call reports,
unknown-opcode preservation, dynamic-materialisation and proto/closure classification, and the
verdict/artifact contract.  All inputs are SYNTHETIC records shaped like diag_hooks' output
(labelled as such); the real-sample numbers come from the pipeline run, not from this file.

    python3 tests/test_v151_phase6.py
"""
import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1 import diag_report as DR          # noqa: E402
from obfuscators.luraph_v15_1 import diagnostics as DG          # noqa: E402
from obfuscators.luraph_v15_1 import validator as V             # noqa: E402

CLEAN = {"decode": {"protos": 3, "instructions": 10}, "lift": {"ran": True}, "unlifted_blocks": 0,
         "nil_calls": 0, "unknown_opcode_steps": 0, "closure": {"entered_not_lifted": [], "dangling_edges": 0},
         "conformance": {"verdict": "CONFORMANT", "total": {}, "failures": []}}


def blk(**kw):
    r = {"proto": "7", "closure": "root/7", "mode": 3, "pc": 100, "opcode": 12, "handler": {"kind": "JUMP"},
         "reason": "BAD_SUCCESSOR", "message": "symbolic next pc/mode: (r62 Add 1) / 3", "block_class": "OTHER",
         "predecessors": [[3, 90]], "successors": [], "registers": {"62": "unknown"}, "operands": {"a": 1},
         "upvalues": {}, "real_trace": {"verdict": "SAME_OP"}}
    r.update(kw)
    return r


def nil(**kw):
    r = {"proto": "7", "closure": "root/7", "mode": 3, "pc": 50, "index": 4, "opcode": 9,
         "handler": {"kind": "CALL", "semantic": "call r[a]"}, "callee": "r5", "callee_register": 5,
         "kind": "NIL_CALL_REGISTER", "root_cause": "r5 never written", "real_trace": {"verdict": "SAME_OP"}}
    r.update(kw)
    return r


class RootCauseClasses(unittest.TestCase):
    def test_return_continuation(self):
        c, ev = DG.class_of("BAD_SUCCESSOR", "symbolic next pc/mode: (r62 Add 1) / 3", 10, 1000, [])
        self.assertEqual(c, "UNKNOWN_RETURN_CONTINUATION")
        c, _ = DG.class_of("BAD_SUCCESSOR", "symbolic next pc/mode: r62 / 3", 10, 1000, [])
        self.assertEqual(c, "UNKNOWN_RETURN_CONTINUATION")

    def test_recursive_or_context_sensitive(self):
        c, _ = DG.class_of("BAD_SUCCESSOR", "stack depth 64 exceeded", 10, 1000, [])
        self.assertEqual(c, "RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW")

    def test_other_symbolic_successor_stays_missing_successor(self):
        c, _ = DG.class_of("BAD_SUCCESSOR", "symbolic next pc/mode: (r3 Mul 2) / 3", 10, 1000, [])
        self.assertEqual(c, "MISSING_CFG_SUCCESSOR")

    def test_unknown_opcode_is_never_reclassified(self):
        c, _ = DG.class_of("UNKNOWN_OPCODE", "no handler", 10, 1000, [])
        self.assertEqual(c, "UNKNOWN_OPCODE_SEMANTIC")

    def test_dynamic_materialisation(self):
        self.assertEqual(DG.class_of("DYNAMIC_EXPANSION", "expansion cycle", 1, 10, [])[0], "DYNAMIC_MATERIALIZATION")
        c, ev = DG.class_of("TYPE_MISMATCH", "arith on nil", 1, 10, [("exp", 3)])
        self.assertEqual(c, "DYNAMIC_MATERIALIZATION")
        self.assertIn("in-place decode", ev)

    def test_proto_closure_edges(self):
        self.assertEqual(DG.class_of("MISSING_CLOSURE", "closure of non-proto", 1, 10, [])[0], "MISSING_PROTO_EDGE")

    def test_far_pc_is_wrong_branch_target(self):
        self.assertEqual(DG.class_of("BAD_SUCCESSOR", "x", 5000, 100, [])[0], "WRONG_BRANCH_TARGET")

    def test_every_class_has_a_proposed_fix(self):
        for c in DG.CLASSES:
            self.assertIn(c, DR.PROPOSED, c)


class BlockReport(unittest.TestCase):
    def test_entry_has_all_required_fields(self):
        e = DR.block_entry(blk(block_class="UNKNOWN_RETURN_CONTINUATION"))
        for k in ("function", "block_start", "mode", "opcode", "predecessors", "successors", "exit_classification",
                  "register_state", "constants_and_operands", "upvalues", "closure_proto_refs", "unknown_operations",
                  "reject_reason", "runtime_reachable", "real_trace", "proposed_fix"):
            self.assertIn(k, e)
        self.assertEqual(e["exit_classification"], "JUMP")
        self.assertTrue(e["runtime_reachable"])
        self.assertEqual(e["proposed_fix"]["status"], "LEAD_NOT_VERIFIED")

    def test_reachability_from_real_trace(self):
        self.assertFalse(DR.block_entry(blk(real_trace={"verdict": "NOT_REACHED", "proto_ran_in_real_run": True}))["runtime_reachable"])
        self.assertFalse(DR.block_entry(blk(real_trace={"verdict": "PROTO_NOT_RUN"}))["runtime_reachable"])
        self.assertIsNone(DR.block_entry(blk(real_trace=None))["runtime_reachable"])

    def test_unknown_opcode_is_preserved_not_dropped(self):
        e = DR.block_entry(blk(handler={"kind": "UNKNOWN"}, opcode=77, block_class="UNKNOWN_OPCODE_SEMANTIC",
                               reason="UNKNOWN_OPCODE", message="V151_UNKNOWN(mode=3, opcode=77)"))
        self.assertEqual(e["exit_classification"], "UNKNOWN")
        self.assertEqual(e["unknown_operations"][0]["opcode"], 77)

    def test_materialisation_exit_class(self):
        self.assertEqual(DR._exit_class({"handler": {"kind": "EXPAND"}}), "MATERIALIZATION")
        self.assertEqual(DR._exit_class({"affects": {"return": True}}), "RETURN")
        self.assertEqual(DR._exit_class({"handler": {"kind": "COND_JUMP"}}), "COND_JUMP")


class NilReport(unittest.TestCase):
    def test_validity_follows_the_real_trace(self):
        self.assertEqual(DR.nil_entry(nil())["runtime_evidence"]["validity"], "RECONSTRUCTION_DEFECT")
        self.assertEqual(DR.nil_entry(nil(real_trace={"verdict": "DIFFERENT_OP"}))["runtime_evidence"]["validity"], "DECODE_DIVERGENCE")
        self.assertEqual(DR.nil_entry(nil(real_trace={"verdict": "NOT_REACHED"}))["runtime_evidence"]["validity"], "UNREACHED_IN_RUNTIME")
        self.assertEqual(DR.nil_entry(nil(real_trace=None))["runtime_evidence"]["validity"], "UNKNOWN")

    def test_runtime_value_is_never_invented(self):
        self.assertEqual(DR.nil_entry(nil())["observed_runtime_value"]["status"], "NOT_CAPTURED")

    def test_unreached_nil_is_not_called_a_defect(self):
        d = DR.nil_entry(nil(real_trace={"verdict": "NOT_REACHED"}))["distinction"]
        self.assertFalse(d["reconstruction_defect"])
        self.assertIsNone(d["nil_valid_in_vm"])                  # undecided, not asserted
        self.assertFalse(d["decompiler_placeholder"])

    def test_grouping_by_root_cause_pattern(self):
        doc = DR.build({"nil_calls": [nil(root_cause="r5 never written"), nil(root_cause="r9 never written", pc=60),
                                      nil(root_cause="callee is nil constant", pc=70)]})[1]
        self.assertEqual(doc["total"], 3)
        self.assertEqual(doc["by_root_cause"][0]["count"], 2)
        self.assertEqual(doc["by_root_cause"][0]["root_cause_pattern"], "rN never written")


class Artifacts(unittest.TestCase):
    def test_files_are_written_and_parse(self):
        with tempfile.TemporaryDirectory() as d:
            jp = lambda suf: os.path.join(d, "out" + suf)       # noqa: E731
            pu, pn = DR.write(jp, {"unlifted_blocks": [blk(), blk(pc=101, real_trace={"verdict": "NOT_REACHED"})],
                                   "nil_calls": [nil()]})
            with open(pu) as fu, open(pn) as fn:
                ub, nc = json.load(fu), json.load(fn)
        self.assertEqual(ub["total"], 2)
        self.assertEqual(ub["by_runtime_reachability"], {"reachable": 1, "not_reachable": 1, "unknown": 0})
        self.assertEqual(nc["total"], 1)
        self.assertIn("counting_method", ub)
        self.assertIn("counting_method", nc)

    def test_empty_diag_gives_empty_reports(self):
        ub, nc = DR.build({})
        self.assertEqual((ub["total"], nc["total"]), (0, 0))


class VerdictContract(unittest.TestCase):
    def test_clean_is_pass(self):
        self.assertEqual(V.evaluate(dict(CLEAN))["verdict"], V.PASS)

    def test_any_unlifted_block_is_partial_and_emits_nothing(self):
        r = V.evaluate(dict(CLEAN, unlifted_blocks=1))
        self.assertEqual(r["verdict"], V.PARTIAL)
        self.assertFalse(r["emit_source"])

    def test_entered_but_unlifted_proto_is_not_pass(self):
        r = V.evaluate(dict(CLEAN, closure={"entered_not_lifted": ["12"], "dangling_edges": 0}))
        self.assertEqual(r["verdict"], V.PARTIAL)
        self.assertIn("INVALID_CLOSURE_GRAPH", [x["code"] for x in r["reasons"]])

    def test_dangling_closure_edge_is_not_pass(self):
        self.assertNotEqual(V.evaluate(dict(CLEAN, closure={"entered_not_lifted": [], "dangling_edges": 2}))["verdict"], V.PASS)

    def test_unknown_opcode_step_is_not_pass(self):
        self.assertNotEqual(V.evaluate(dict(CLEAN, unknown_opcode_steps=1))["verdict"], V.PASS)

    def test_budget_exhaustion_is_partial(self):
        r = V.evaluate(dict(CLEAN, lift={"ran": True, "budget": {"blocks": 26505}}))
        self.assertEqual(r["verdict"], V.PARTIAL)
        self.assertFalse(r["emit_source"])

    def test_verdicts_are_distinct(self):
        self.assertEqual(len(set(V.VERDICTS)), 4)



class DepthWidening(unittest.TestCase):
    """SYNTHETIC: State151.key saturates the loop-stack depth only when DEVIRT_V151_DEPTH_WIDEN is set."""

    def setUp(self):
        from obfuscators.luraph_v15_1 import devirt as D
        from obfuscators.luraph_v15_1 import engine_patch as EP
        from luasym import LTable
        self.D, self.EP, self.LTable = D, EP, LTable
        self.old = EP.DEPTH_WIDEN

    def tearDown(self):
        self.EP.DEPTH_WIDEN = self.old

    def chain(self, n):
        k = None
        for _ in range(n):
            t = self.LTable()
            t.set("l", k)
            k = t
        return k

    def key(self, n):
        E = self.D._E
        if not hasattr(E, "State151"):
            self.skipTest("engine not specialised in this process")
        return E.State151(1, 5, self.chain(n), (), None, (), ()).key("l")

    def test_off_by_default_keeps_every_depth_distinct(self):
        self.EP.DEPTH_WIDEN = 0
        self.assertNotEqual(self.key(10), self.key(11))

    def test_widening_merges_only_depths_above_the_bound(self):
        self.EP.DEPTH_WIDEN = 4
        self.assertEqual(self.key(9), self.key(500))
        self.assertEqual(self.key(5), self.key(6))
        self.assertNotEqual(self.key(3), self.key(4))
        self.assertNotEqual(self.key(2), self.key(3))
        self.assertEqual(self.key(9)[:2], (1, 5))


if __name__ == "__main__":
    unittest.main(verbosity=1)

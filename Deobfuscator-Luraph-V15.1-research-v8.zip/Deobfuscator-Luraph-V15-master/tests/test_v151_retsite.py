"""Return-site abstraction (core/obfuscators/luraph_v15_1/retsite.py).

EVIDENCE CLASS: SYNTHETIC.  A miniature register VM is walked by the real, patched v15.1 walk
(`Program._walk` with the `_v151_successors` hook); only the stepper is a stand-in.  It performs the
same sequence the real `V151Stepper.run_once` does -- jump-register tracking, `note_assign`,
`finish_state` -- so the walk, the hook, the dispatch rebuilding and the closure check are real.
The real sample is covered by DumpBased tests in test_v151_round2.py / the E2E test.

Instruction set (mode 0):
    ("set", reg, int)               reg = int
    ("mov", reg, reg2)              reg = reg2           (non-constant)
    ("call", helper_pc, link, ret)  link = ret; goto helper_pc          (a call-like transfer)
    ("ret", link, off)              pc = link + off                     (return through a register)
    ("jmp", pc)                     goto pc
    ("br", reg, pc_true)            if reg then goto pc_true else fall through (opaque predicate)
    ("mul_ret", link)               pc = link * 2                       (NOT affine: must stay unlifted)
    ("halt",)                       return
"""
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "core"))

from obfuscators.luraph_v15_1 import devirt as D                     # noqa: E402
from obfuscators.luraph_v15_1 import engine_patch as EP              # noqa: E402
from obfuscators.luraph_v15_1 import retsite as RS                   # noqa: E402

E = D._E


class _Vm:
    kstack_link = None
    v151 = False            # the engine_patch._walk wrapper (diagnostics, dump snapshots) is for real protos only


class _LfVm:
    v151 = True             # ... but the retsite hook is on


class _Dump:
    buf_patch = {}
    tab_patch = {}
    misses = {}


class FakeLifter:
    walk_only = False

    def __init__(self):
        self.vm = _LfVm()
        self.jump_regs = set()
        self.jvals = {}
        self.jread = set()
        self.stack_base = None
        self.requests = set()
        self.children = []
        self.captured_regs = set()
        self.frame_uses = set()
        self.reg_arrays = set()
        self.dump = _Dump()
        self.pack_killed = set()
        self.pack_unstable = set()
        self.link_regs = set()
        self.link_new = {}


class FakeStepper:
    """Steps the instruction list like V151Stepper.run_once does for the pieces retsite touches."""
    new_carry = False

    def __init__(self, code, lf):
        self.code, self.lf = code, lf

    def initial(self):
        return E.State(0, 0, None, (), None, (), ())

    def _emit_assign(self, lf, reg, value, out):
        st = E.Assign(E.Reg(reg), value)
        out.append(st)
        # the engine's emit(): track constants of jump registers; assignments to them are not output
        if reg in lf.jump_regs:
            if isinstance(value, E.Const) and isinstance(value.v, int):
                lf.jvals[reg] = value.v
            else:
                lf.jvals.pop(reg, None)
            st.jump = True
        RS.note_assign(lf, st, E.Assign)

    def _read(self, lf, reg):
        if reg in lf.jvals:
            lf.jread.add(reg)
            return RS.read_value(lf, reg, lf.jvals[reg])
        return E.Reg(reg)

    def step(self, state, prefix):
        lf = self.lf
        lf.jvals = dict(state.jregs)
        lf.jread = set()
        lf.link_new = {}
        ins = self.code[state.pc]
        out = []
        op = ins[0]
        nxt = state.pc + 1
        cond = None
        pc_expr = None
        ret = False
        if op == "set":
            self._emit_assign(lf, ins[1], E.Const(ins[2]), out)
        elif op == "mov":
            self._emit_assign(lf, ins[1], self._read(lf, ins[2]), out)
        elif op == "call":
            self._emit_assign(lf, ins[2], E.Const(ins[3]), out)
            nxt = ins[1]
        elif op == "jmp":
            nxt = ins[1]
        elif op == "ret":
            v = self._read(lf, ins[1])
            pc_expr = v if ins[2] == 0 else (v + ins[2] if isinstance(v, int) else E.Bin("Add", v, E.Const(ins[2])))
        elif op == "mul_ret":
            v = self._read(lf, ins[1])
            pc_expr = v * 2 if isinstance(v, int) else E.Bin("Mul", v, E.Const(2))
        elif op == "br":
            cond = E.Reg(ins[1])
        elif op == "halt":
            ret = True

        def state_to(pc):
            jr = tuple(sorted(((k, v) for k, v in lf.jvals.items() if k not in lf.jread), key=lambda kv: kv[0]))
            ns = E.State(0, pc, None, jr, None, state.packs, state.locs)
            ns = RS.finish_state(lf, state, ns)
            return ns

        if ret:
            return E.Node(out, outcome=E.Ret(E.Multi([])))
        if cond is not None:
            lf.jvals = dict(state.jregs)
            t = E.Node([], outcome=E.Next(state_to(ins[2])))
            e = E.Node([], outcome=E.Next(state_to(nxt)))
            return E.Node(out, cond=cond, then=t, els=e)
        if pc_expr is not None:
            return E.Node(out, outcome=E.Next(state_to(pc_expr)))
        return E.Node(out, outcome=E.Next(state_to(nxt)))


def walk(code, links_on=True, limit=50000, bound=0):
    """-> (order, info, lf, prog).  Runs the walk to its fixpoint (restarts included).
    `bound` = retsite.MIN_SITES (0: abstract from the first return site, which is what most tests exercise)."""
    old, old_b = EP.RETSITE_ON, RS.MIN_SITES
    EP.RETSITE_ON = links_on
    RS.MIN_SITES = bound
    try:
        lf = FakeLifter()
        st = FakeStepper(code, lf)
        prog = E.Program.__new__(E.Program)
        s0, order, restart = prog.walk_fixpoint(_Vm(), lf, st, limit)
        return order, restart, lf, prog
    finally:
        EP.RETSITE_ON = old
        RS.MIN_SITES = old_b


def states_at(order, pc):
    return [k for k, _ in order if k[1] == pc]


def successors_of(order, k):
    nodes = dict(order)
    return [ns.pc for ns in D._E._node_successors(nodes[k])]


class TestAbstraction(unittest.TestCase):
    # a helper at pc 10..12 ending in a return; callers store their continuation in r62
    HELPER = [(1000, ("set", 7, 1)), (1001, ("mov", 8, 7)), (1002, ("ret", 62, 0))]

    def program(self, n_callers, extra=()):
        code = {}
        pc = 0
        sites = []
        for i in range(n_callers):
            code[pc] = ("call", 1000, 62, pc + 1)
            sites.append(pc + 1)
            code[pc + 1] = ("set", 20, i)           # continuation of call i
            pc += 2
        code[pc] = ("halt",)
        for p, ins in self.HELPER:
            code[p] = ins
        return code, sites

    def test_two_return_destinations_stay_distinct(self):
        code = {0: ("call", 10, 62, 1), 1: ("set", 20, 111), 2: ("call", 10, 62, 3), 3: ("set", 20, 222),
                4: ("halt",), 10: ("set", 7, 1), 11: ("mov", 8, 7), 12: ("ret", 62, 0)}
        code[1] = ("set", 20, 111)
        code[1] = ("set", 20, 111)
        # continuation of call 0 must lead to the second call; of call 1 to halt
        code[1] = ("jmp", 2)
        code[3] = ("jmp", 4)
        order, restart, lf, prog = walk(code)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 10)), 1, "the helper body must be stepped once")
        self.assertEqual(len(states_at(order, 12)), 1)
        k = states_at(order, 12)[0]
        self.assertEqual(sorted(successors_of(order, k)), [1, 3], "both continuations are successors of the return")
        tab = RS.of(lf).tables
        self.assertEqual(sorted(next(iter(tab.values()))), [1, 3])
        self.assertEqual(D._E._closure_missing(order, dict(order), None), [])

    def test_dispatch_tests_the_real_register(self):
        code = {0: ("call", 10, 62, 1), 1: ("jmp", 2), 2: ("call", 10, 62, 3), 3: ("halt",),
                10: ("ret", 62, 0)}
        order, restart, lf, prog = walk(code)
        node = dict(order)[states_at(order, 10)[0]]
        self.assertIsNotNone(node.cond, "a two-site return must branch")
        self.assertEqual(node.cond.op, "CompareEq")
        self.assertEqual(node.cond.a.n, 62)
        self.assertIn(node.cond.b.v, (1, 3))
        # the register assignments that feed the dispatch are in the output (not dropped as jump setup)
        assigns = [s for k, n in order for s in n.stmts if isinstance(s, E.Assign) and s.target.n == 62]
        self.assertEqual(len(assigns), 2)
        self.assertTrue(all(not getattr(s, "jump", False) for s in assigns))

    def test_baseline_clones_per_return_address(self):
        """Control: without the abstraction the helper is cloned per call site (the verified failure)."""
        code, sites = self.program(12)
        a, _, _, _ = walk(code, links_on=False)
        b, _, _, _ = walk(code, links_on=True)
        self.assertEqual(len(states_at(a, 1002)), 12)
        self.assertEqual(len(states_at(b, 1002)), 1)
        self.assertLess(len(b), len(a))

    def test_pathological_many_call_sites_is_bounded(self):
        n = 600
        code = {}
        pc = 20
        for i in range(n):
            code[pc] = ("call", 10, 62, pc + 1)
            code[pc + 1] = ("jmp", pc + 2)
            pc += 2
        code[pc] = ("halt",)
        code[0] = ("jmp", 20)
        code[10] = ("set", 7, 1)
        code[11] = ("mov", 8, 7)
        code[12] = ("ret", 62, 0)
        a, _, _, _ = walk(code, links_on=False)
        b, restart, lf, _ = walk(code, links_on=True)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(a, 12)), n)
        self.assertEqual(len(states_at(b, 12)), 1)
        self.assertLessEqual(len(b), 3 * n + 10)          # linear in the number of sites, helper once
        self.assertLess(len(b) * 2, len(a))
        self.assertEqual(len(next(iter(RS.of(lf).tables.values()))), n)
        self.assertEqual(D._E._closure_missing(b, dict(b), None), [])

    def test_return_with_offset(self):
        """pc = link + 1 (the real VM adds one): the continuation is K+1."""
        code = {0: ("call", 10, 62, 4), 1: ("halt",), 5: ("halt",), 10: ("ret", 62, 1)}
        order, restart, lf, _ = walk(code)
        self.assertEqual(sorted(successors_of(order, states_at(order, 10)[0])), [5])

    def test_nested_helpers_with_different_link_registers(self):
        # main -> A (link r62) -> B (link r61) -> back to A -> back to main, from two main sites
        code = {0: ("call", 10, 62, 1), 1: ("call", 10, 62, 2), 2: ("halt",),
                10: ("call", 20, 61, 11), 11: ("ret", 62, 0),
                20: ("set", 5, 1), 21: ("ret", 61, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 20)), 1)
        self.assertEqual(len(states_at(order, 21)), 1)
        self.assertEqual(sorted(successors_of(order, states_at(order, 21)[0])), [11])
        self.assertEqual(sorted(successors_of(order, states_at(order, 11)[0])), [1, 2])
        self.assertEqual(D._E._closure_missing(order, dict(order), None), [])

    def test_nested_helper_sharing_one_link_register_is_not_wrongly_merged(self):
        # A saves its own return address in r5 (non-link), calls B through the SAME r62, restores it
        code = {0: ("call", 10, 62, 1), 1: ("halt",),
                10: ("mov", 5, 62), 11: ("call", 20, 62, 12), 12: ("mov", 62, 5), 13: ("ret", 62, 0),
                20: ("set", 6, 1), 21: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        # B returns to 12 only; A's final return goes through r62 restored from a non-constant register:
        # its target is not derivable -> must stay an honest unlifted block, never a guessed edge
        b_ret = dict(order)[states_at(order, 21)[0]]
        self.assertEqual(sorted(successors_of(order, states_at(order, 21)[0])), [12])
        a_ret = dict(order)[states_at(order, 13)[0]]
        self.assertTrue(getattr(a_ret, "error", None), "restored link of unknown value must stay an error")

    def test_recursion_terminates_and_keeps_both_sites(self):
        # helper at 10: if r1 then call itself (link r62, ret to 12) ; ret
        code = {0: ("mov", 1, 50), 1: ("call", 10, 62, 2), 2: ("halt",),
                10: ("br", 1, 13), 11: ("jmp", 14),
                13: ("call", 10, 62, 14), 14: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        tokd = [k for k in states_at(order, 14) if any(isinstance(v, RS.LinkTok) for _, v in k[3])]
        self.assertEqual(len(tokd), 1, "the return is stepped once per helper, not once per recursion level")
        succ = sorted(successors_of(order, tokd[0]))
        self.assertEqual(succ, [2, 14], "outer return and the recursive return are both sites of the table")
        # the link is dead after its consumption: the continuation (pc 14 again) carries no token, and a
        # second return through the same register is reported, not guessed
        cont = [k for k in states_at(order, 14) if k not in tokd]
        self.assertEqual(len(cont), 1)
        self.assertTrue(getattr(dict(order)[cont[0]], "error", None))

    def test_cycle_calling_helper_in_a_loop(self):
        code = {0: ("set", 1, 1), 1: ("call", 10, 62, 2), 2: ("br", 1, 1), 3: ("halt",), 10: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 10)), 1)
        self.assertEqual(successors_of(order, states_at(order, 10)[0]), [2])

    def test_non_affine_consumer_is_not_dispatched(self):
        # r62 * 2 is not a return: the register is only tracked as a constant (old behaviour), never tokenised
        code = {0: ("call", 10, 62, 1), 2: ("halt",), 10: ("mul_ret", 62)}
        order, restart, lf, _ = walk(code)
        self.assertNotIn(62, lf.link_regs)
        self.assertEqual(RS.of(lf).tables, {})
        self.assertEqual(successors_of(order, states_at(order, 10)[0]), [2])

    def test_non_constant_link_is_not_guessed(self):
        code = {0: ("mov", 62, 3), 1: ("call", 10, 61, 2), 2: ("halt",), 10: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        node = dict(order)[states_at(order, 10)[0]]
        self.assertTrue(getattr(node, "error", None))

    def test_table_complete_for_late_sites(self):
        """A call site reached after the first return node was built updates the dispatch."""
        code = {0: ("call", 10, 62, 1), 1: ("jmp", 5), 5: ("call", 10, 62, 6), 6: ("halt",), 10: ("ret", 62, 0)}
        order, restart, lf, _ = walk(code)
        self.assertEqual(sorted(successors_of(order, states_at(order, 10)[0])), [1, 6])
        self.assertGreaterEqual(RS.of(lf).rebuilds, 1)

    def test_walk_fixpoint_result_has_no_unexplored_successor(self):
        code, _ = self.program(30)
        order, restart, lf, _ = walk(code)
        self.assertEqual(D._E._closure_missing(order, dict(order), None), [])
        self.assertTrue(order.info["closed"])


class TestSiteBound(unittest.TestCase):
    """The abstraction applies only to helpers that exceed the context-sensitivity bound (SYNTHETIC)."""

    def calls(self, n):
        code, pc = {}, 0
        for i in range(n):
            code[pc] = ("call", 1000, 62, pc + 1)
            code[pc + 1] = ("set", 20, i)
            pc += 2
        code[pc] = ("halt",)
        code[1000], code[1001], code[1002] = ("set", 7, 1), ("mov", 8, 7), ("ret", 62, 0)
        return code

    def test_below_the_bound_the_helper_is_cloned_exactly(self):
        order, restart, lf, prog = walk(self.calls(5), bound=8)
        self.assertFalse(restart)
        self.assertEqual(len(states_at(order, 1000)), 5)           # one body state per return address: engine behaviour
        self.assertEqual(RS.report(lf)["call_transfers"], 0)
        self.assertEqual(RS.report(lf)["helpers_below_bound"], 1)

    def test_above_the_bound_the_helper_is_abstracted(self):
        order, restart, lf, prog = walk(self.calls(30), bound=8)
        self.assertFalse(restart)
        n = len(states_at(order, 1000))
        self.assertLess(n, 30)                                      # the clones before the bound plus ONE token state
        self.assertLessEqual(n, 8 + 1)
        rep = RS.report(lf)
        self.assertGreater(rep["call_transfers"], 0)
        self.assertEqual(len(rep["helpers"]), 1)
        self.assertEqual(len(rep["helpers"][0]["return_sites"]), 30)  # earlier sites joined the table

    def test_every_continuation_stays_reachable_across_the_bound(self):
        order, restart, lf, prog = walk(self.calls(30), bound=8)
        reached = {k[1] for k, _ in order}
        for i in range(30):
            self.assertIn(2 * i + 1, reached, "continuation of call %d lost" % i)
        self.assertIn(60, reached)                                  # halt

    def test_bound_zero_equals_unbounded_abstraction(self):
        a = walk(self.calls(10), bound=0)[0]
        self.assertEqual(len(states_at(a, 1000)), 1)

    def nested(self, n, m):
        """n callers of an OUTER helper (link r3); the outer helper calls an INNER helper (link r62) from m sites
        while r3 stays live.  Contexts at the inner entry = n x m (product), though each register has few values."""
        code, pc = {}, 0
        for i in range(n):
            code[pc] = ("call", 100, 3, pc + 1)
            code[pc + 1] = ("set", 20, i)
            pc += 2
        code[pc] = ("halt",)
        for j in range(m):                                  # outer helper: m call sites of the inner helper
            code[100 + 2 * j] = ("call", 200, 62, 101 + 2 * j)
            code[101 + 2 * j] = ("set", 21, j)
        code[100 + 2 * m] = ("ret", 3, 0)
        code[200], code[201], code[202] = ("set", 7, 1), ("mov", 8, 7), ("ret", 62, 0)
        return code

    def test_product_of_live_link_registers_is_bounded_per_entry(self):
        n, m = 5, 4                                         # 5 + 4 constants but 20 contexts at the inner entry
        order, restart, lf, prog = walk(self.nested(n, m), bound=6)
        self.assertFalse(restart)
        inner = len(states_at(order, 200))
        self.assertLessEqual(inner, 6 + 1)                  # <= bound exact contexts + the one abstract context
        control = len(states_at(walk(self.nested(n, m), links_on=False)[0], 200))
        self.assertEqual(control, n * m)                    # the engine clones the PRODUCT (growth pattern, measured)
        reached = {k[1] for k, _ in order}
        for i in range(n):
            self.assertIn(2 * i + 1, reached, "continuation of outer call %d lost" % i)
        for j in range(m):
            self.assertIn(101 + 2 * j, reached, "inner continuation %d lost" % j)

    def test_product_growth_is_linear_in_the_larger_register_after_the_bound(self):
        sizes = []
        for n in (4, 8, 16):
            order = walk(self.nested(n, 4), bound=6)[0]
            sizes.append(len(states_at(order, 200)))
        self.assertTrue(all(x <= 7 for x in sizes), sizes)  # does not grow with n


class TestDeferredDiscovery(unittest.TestCase):
    """k INDEPENDENT helpers, each with its own link register, behind opaque branches: the engine restarts the walk
    once per register; with deferral the registers found in one pass are learned together (SYNTHETIC)."""

    def program(self, k):
        code = {}
        for i in range(k):                                   # 0..k-1: fan-out of opaque branches
            code[i] = ("br", 50 + i, 100 + 10 * i)           # taken: caller i; else the next branch
        code[k] = ("halt",)
        for i in range(k):
            base = 100 + 10 * i
            code[base] = ("call", 1000 + 10 * i, 10 + i, base + 1)       # r(10+i) = return, goto helper i
            code[base + 1] = ("set", 20, i)
            code[base + 2] = ("halt",)
            code[1000 + 10 * i] = ("set", 7, i)
            code[1000 + 10 * i + 1] = ("ret", 10 + i, 0)
        return code

    def walk_counting(self, k, defer):
        calls = [0]
        orig = E.Program._walk

        def counting(self_, vm, lf, st, limit):
            calls[0] += 1
            return orig(self_, vm, lf, st, limit)

        E.Program._walk = counting
        old = RS.DEFER_ON
        RS.DEFER_ON = defer
        try:
            order, restart, lf, prog = walk(self.program(k), bound=0)
        finally:
            E.Program._walk = orig
            RS.DEFER_ON = old
        return order, restart, lf, calls[0]

    def test_deferral_reduces_restarts_and_keeps_the_same_cfg(self):
        k = 6
        o_off, r_off, lf_off, n_off = self.walk_counting(k, False)
        o_on, r_on, lf_on, n_on = self.walk_counting(k, True)
        self.assertFalse(r_off)
        self.assertFalse(r_on)
        self.assertLess(n_on, n_off, "restarts: deferred %d, immediate %d" % (n_on, n_off))
        self.assertEqual({(k_[0], k_[1]) for k_, _ in o_on}, {(k_[0], k_[1]) for k_, _ in o_off})
        self.assertEqual(sorted(lf_on.link_regs), sorted(lf_off.link_regs))
        self.assertEqual(sorted(lf_on.link_regs), [10 + i for i in range(k)])
        for i in range(k):                                    # every continuation of every helper was reached
            self.assertIn(100 + 10 * i + 1, {k_[1] for k_, _ in o_on})

    def test_deferred_node_is_not_silently_dropped(self):
        # the walk that deferred a register ends with an error node, never as an accepted closed walk
        order, restart, lf, n = self.walk_counting(3, True)
        self.assertFalse(restart)
        self.assertTrue(all(not getattr(nd, "error", None) for _k, nd in order),
                        "the accepted walk must have no unresolved symbolic return")


class TestHelpers(unittest.TestCase):
    def test_affine(self):
        self.assertEqual(RS.affine(E.Reg(3)), (3, 0))
        self.assertEqual(RS.affine(E.Bin("Add", E.Reg(3), E.Const(1))), (3, 1))
        self.assertEqual(RS.affine(E.Bin("Add", 5, E.Reg(3))), (3, 5))
        self.assertEqual(RS.affine(E.Bin("Sub", E.Reg(3), 2)), (3, -2))
        self.assertIsNone(RS.affine(E.Bin("Mul", E.Reg(3), 2)))
        self.assertIsNone(RS.affine(E.Bin("Add", E.Reg(3), E.Reg(4))))
        self.assertIsNone(RS.affine(E.Const(4)))

    def test_token_identity_and_hash(self):
        a, b = RS.LinkTok(62, 0, 10), RS.LinkTok(62, 0, 10)
        self.assertEqual(a, b)
        self.assertEqual(hash(a), hash(b))
        self.assertNotEqual(a, RS.LinkTok(62, 0, 11))
        self.assertNotEqual(a, 62)
        self.assertEqual(len({a, b, RS.LinkTok(61, 0, 10)}), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)

'use strict';
// node tests/test_platform.js
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const P = require('../src/platform.js');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'plat-'));
function make(name, bytes) { const f = path.join(dir, name); fs.writeFileSync(f, Buffer.from(bytes)); return f; }
function elf(machine, bits = 2) {
  const b = Buffer.alloc(64); b[0] = 0x7f; b[1] = 0x45; b[2] = 0x4c; b[3] = 0x46; b[4] = bits; b[5] = 1;
  b.writeUInt16LE(machine, 18); return [...b];
}
let n = 0;
function t(name, fn) { fn(); n++; console.log('ok -', name); }

const pe = make('luau.exe', [0x4d, 0x5a, 0x90, 0, 3, 0, 0, 0]);
const arm = make('luau-arm', elf(183));
const x64 = make('luau-x64', elf(62));
const scr = make('wrapper', [0x23, 0x21, 0x2f, 0x62]);
const junk = make('junk', [1, 2, 3, 4]);

t('PE is detected by content, not by name', () => {
  const copy = make('luau', [0x4d, 0x5a, 0, 0]);
  assert.strictEqual(P.inspectBinary(copy).kind, 'PE');
});
t('ELF machine is read', () => {
  assert.strictEqual(P.inspectBinary(arm).machine, 183);
  assert.strictEqual(P.inspectBinary(x64).machine, 62);
});
t('PE is rejected on Termux / Linux', () => {
  const r = P.runnableOn(P.inspectBinary(pe), 'linux', 'arm64');
  assert.strictEqual(r.ok, false);
  assert.ok(/Windows executable/.test(r.reason));
});
t('x86-64 ELF is rejected on an ARM phone, ARM ELF accepted', () => {
  assert.strictEqual(P.runnableOn(P.inspectBinary(x64), 'linux', 'arm64').ok, false);
  assert.strictEqual(P.runnableOn(P.inspectBinary(arm), 'linux', 'arm64').ok, true);
});
t('PE is the right thing on Windows', () => {
  assert.strictEqual(P.runnableOn(P.inspectBinary(pe), 'win32', 'x64').ok, true);
  assert.strictEqual(P.runnableOn(P.inspectBinary(arm), 'win32', 'x64').ok, false);
});
t('missing and unknown files are not runtimes', () => {
  assert.strictEqual(P.runnableOn(P.inspectBinary(path.join(dir, 'nope')), 'linux', 'x64').ok, false);
  assert.strictEqual(P.runnableOn(P.inspectBinary(junk), 'linux', 'x64').ok, false);
});
t('checkRuntime reports BLOCKED-shaped status when a tool is unusable', () => {
  const r = P.checkRuntime({ luau: pe, 'luau-ast': arm }, 'linux', 'arm64');
  assert.strictEqual(r.available, false);
  assert.ok(/luau:/.test(r.reason) && /install-termux/.test(r.reason));
  assert.strictEqual(r.tools['luau-ast'].ok, true);
});
t('checkRuntime is available when every tool is native', () => {
  const r = P.checkRuntime({ luau: arm, 'luau-ast': arm }, 'linux', 'arm64');
  assert.strictEqual(r.available, true);
  assert.strictEqual(r.reason, null);
});
t('a wrapper script is accepted (its target is checked when it runs)', () => {
  assert.strictEqual(P.runnableOn(P.inspectBinary(scr), 'linux', 'arm64').ok, true);
});

// ---- launch / parse probes (distinguish: absent / wrong format / cannot launch / launches / parse fails) ----
function script(name, body, mode = 0o755) { const f = path.join(dir, name); fs.writeFileSync(f, '#!/bin/sh\n' + body + '\n'); fs.chmodSync(f, mode); return f; }
t('launchCheck: absent tool', () => {
  assert.strictEqual(P.launchCheck(path.join(dir, 'does-not-exist')).state, 'ABSENT');
});
t('launchCheck: a PE image on a non-Windows host is WRONG_FORMAT, never launched', () => {
  const r = P.launchCheck(pe);
  if (process.platform !== 'win32') assert.strictEqual(r.state, 'WRONG_FORMAT');
});
t('launchCheck: a non-executable script cannot launch', () => {
  if (process.getuid && process.getuid() === 0) return;           // root can run anything with a shebang
  assert.strictEqual(P.launchCheck(script('noexec.sh', 'exit 0', 0o644)).state, 'CANNOT_LAUNCH');
});
t('launchCheck: a tool that starts and exits non-zero still LAUNCHES', () => {
  const r = P.launchCheck(script('fail.sh', 'echo oops >&2; exit 3'));
  assert.strictEqual(r.state, 'LAUNCHES'); assert.strictEqual(r.exitCode, 3);
});
t('launchCheck: a tool killed by a signal is CANNOT_LAUNCH', () => {
  assert.strictEqual(P.launchCheck(script('kill.sh', 'kill -9 $$')).state, 'CANNOT_LAUNCH');
});
t('parseCheck: launches but prints no AST -> PARSE_FAILS', () => {
  assert.strictEqual(P.parseCheck(script('ast-bad.sh', 'echo not-json')).state, 'PARSE_FAILS');
});
t('parseCheck: AST output with a return statement -> OK', () => {
  assert.strictEqual(P.parseCheck(script('ast-good.sh', 'echo \'{"root":{"body":[{"type":"AstStatReturn"}]}}\'')).state, 'OK');
});
t('parseCheck: absent tool keeps the launch state', () => {
  assert.strictEqual(P.parseCheck(path.join(dir, 'nope-ast')).state, 'ABSENT');
});
t('parseCheck: the real bin/luau-ast, when present on this host, parses (else skipped)', () => {
  const real = path.join(__dirname, '..', 'bin', 'luau-ast');
  if (!fs.existsSync(real)) return;
  const l = P.launchCheck(real, ['--help']);
  if (l.state === 'LAUNCHES') assert.ok(['OK', 'PARSE_FAILS'].includes(P.parseCheck(real).state));
});
console.log(n + ' tests passed');

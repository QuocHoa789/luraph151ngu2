# Changelog — V15.1 round 2 (on top of ZIP v4, SHA256 e381c6f4…931a)

V15 engine (`core/obfuscators/luraph_v15/*`, `core/backend.py`, `core/codegen.py`, `core/structure.py`,
`src/vmmap.js`) is **byte-identical** to v4 (checked with `diff -r` against the v4 ZIP).

## Behaviour changes (all V15.1-only)
* **Validator gate** — `validator.py`, `gate.py`: PASS / PARTIAL / BLOCKED / FAIL. `driver.py` writes the final
  `.devirt.luau` only on PASS, removes a stale one otherwise; evidence in `<out>.v151diag.json` + `.v151-report.txt`.
* **Root cause of unlifted blocks**: decode-key locals (`J = L[R[i]]`) were lost between lifter steps. `engine_patch.py`:
  `State151.keys`, `_Acc151`, `V151Stepper` key tracking, `KEY_CARRY`. `dataflow.py`: `Pending`/`SymKey`/virtual key
  registers, pure-builtin folding (exact types, never coerced).
* **Conformance oracle** — `conformance.py`: replays the real run's step trace through the lifted CFG (call-frame stack,
  union of closure instances); NOT_CONFORMANT blocks PASS.
* **Diagnostics** — `diagnostics.py`, `diag_hooks.py`: UNLIFTED BLOCK layout, reason enums, class summary
  (DYNAMIC_MATERIALIZATION, JUNK_UNREACHABLE, MISSING_CFG_SUCCESSOR, OTHER, …), nil-call root-cause groups, expansion log,
  walk records, budget hits.
* **Semantics** — `semantics.py`: opcode semantics only from sampled evidence (≥3 samples, ≥90 % dominant), report with
  confidence; unknown stays unknown.
* **Resource safety** — lowering budget/blocks ceiling/`MemoryError` guard → PARTIAL(LIFT_BUDGET_EXHAUSTED); address-space
  cap from MemAvailable; Node-side BLOCKED report if the process is killed; `devirt_bridge.py` no longer prints
  `success` when no source was written.
* **Termux/platform** — `src/platform.js`, `src/harness.js findLuau`: ELF/PE/arch check, BLOCKED if no native runtime.
* **Audit** — `core/obfuscators/luraph_v15_1/AUDIT-V15-ASSUMPTIONS.md`.
* `engine.py`: `DEVIRT_PLATEAU` env (default 25000 = unchanged). `DEVIRT_V151_KVALS` default off.

## Added files
`dataflow.py conformance.py semantics.py validator.py gate.py AUDIT-V15-ASSUMPTIONS.md` (luraph_v15_1),
`src/platform.js`, `tests/test_platform.js`, `tests/test_v151_round2.py`, `V15.1-STATUS.md` (rewritten),
`CHANGELOG-V15.1-round2.md`, `TEST-RESULTS-V15.1-round2.md`.
## Modified files
`engine_patch.py diagnostics.py diag_hooks.py driver.py engine.py` (luraph_v15_1), `src/driver.js`, `src/harness.js`,
`src/devirt_bridge.py`, `deob.js`, `tests/test_v151.py`, `README.md`, `LURAPH-V15.1.md`.

## Before / after (sample/v15.1/sa-obfuscated.lua.txt)
| | before (v4) | after |
|---|---|---|
| unlifted blocks | 37 | 46 by gate measure (lifter counter 42; v4 counter was 37) — still > 0 |
| nil calls | 195 | 119 |
| verdict | PARTIAL by comment only | PARTIAL by validator (6 reasons), conformance 72 %, no source emitted |
| proto 11 (key-carry case) | unlifted | 154 states, 0 unlifted, 13 172/13 172 steps conformant |

## Not done / remaining blocker
Return-site abstraction for outlined helpers called through a jump register (see V15.1-STATUS.md). Without it the main
proto cannot be lifted, so the result stays PARTIAL. No claim of completion is made.

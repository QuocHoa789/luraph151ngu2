# Test results — V15.1 phase 7 (actual runs, logs in research/phase7/logs/)

| Suite | Command | Result | Log |
|---|---|---|---|
| retsite + phase6 + phase7 (synthetic) | `python3 -m unittest tests.test_v151_retsite tests.test_v151_phase7 tests.test_v151_phase6` | **71 OK** (23 + 21 + 27) | test_unit_synthetic.log |
| round 2 with the real dump (proto 11 conformance etc.) | `DEOB_V151_DUMP=…/out.lua.protos.json python3 -m unittest tests.test_v151_round2` | **25 OK** (13.8 s) | test_v151_round2.log |
| devirt recovery | `python3 -m unittest tests.test_devirt_recovery` | OK | test_devirt_recovery.log |
| core V15.1 + V15 regression | `DEOB_V151_DUMP=… DEOB_V15_BASELINE=… DEOB_V15_REFERENCE=… python3 -m unittest tests.test_v151` | **22 OK, 1 skipped** (end-to-end needs `DEOB_E2E`) | test_v151_core_with_v15_regression.log |
| Node platform | `node tests/test_platform.js` | **18 passed** | test_platform.log |
| native tools | `bin/luau`, `bin/luau-ast` executed | ELF x86-64: `luau` runs, `luau-ast` emits JSON AST; `.exe` are PE and were **not** run | native_tools_probe.txt |
| full pipeline, final tree | see V15.1-PHASE7.md §8 | exit 0, 12 m 34 s, verdict **PARTIAL** (`LIFT_BUDGET_EXHAUSTED`) | full_pipeline_v7_final_limits15k.log |

Negative control (not a suite): with `ctx` forced to 0 in `retsite.finish_state`,
`TestCallerStateIsNotMixed.test_undecided_dispatch_does_not_cross_caller_contexts` fails (`bound=0`); restored, it passes.

Not run: Android/Termux (no device); the ablation `RETCTX=0` and the V6 baseline probes did not finish (see metrics json).
Tests marked synthetic prove properties of the abstraction on a miniature VM; they do not prove that the real sample lifts.

## Run from the extracted ZIP (`Deobfuscator-Luraph-V15.1-research-v7.zip`)
* V15 protected files: SHA-256 identical to the pre-edit record.
* `retsite + phase7 + phase6 + devirt_recovery`: 80 OK. `node tests/test_platform.js`: 18 passed.
* `tests.test_v151_round2` (needs the real dump AND `bin/luau-ast`, which the ZIP deliberately does not ship): without the native
  tool, `DumpBased.setUpClass` errors with `FileNotFoundError …/bin/luau-ast` (1 error); with the sandbox's Linux x86-64 ELF
  copied into `bin/`: **25 OK**. On a device the installer provides the tools (`install-termux.sh`; `.exe` files are rejected as WRONG_FORMAT).

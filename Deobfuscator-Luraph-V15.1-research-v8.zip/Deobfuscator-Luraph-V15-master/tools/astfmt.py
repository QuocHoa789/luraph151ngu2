"""Pretty-print a region of a one-line Luau file using the luau-ast JSON (analysis helper)."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))
from obfuscators.luraph_v15 import vmmap

class Fmt:
    def __init__(self, path):
        self.root = vmmap.load_ast(path)
        with open(path, encoding='latin-1') as f:
            self.lines = f.read().split('\n')
        self.out = []

    def T(self, n):
        return vmmap.text_of(self.lines, n)

    def emit(self, ind, s):
        self.out.append('  ' * ind + s)

    def block(self, blk, ind, maxdepth=99):
        for st in blk['body']:
            self.stmt(st, ind, maxdepth)

    def expr_inline(self, e, ind):
        # expressions containing functions get expanded
        t = e['type']
        return self.T(e)

    def stmt(self, st, ind, maxdepth):
        t = st['type']
        if ind > maxdepth:
            self.emit(ind, '-- ... (%s %s)' % (t, st['location']))
            return
        if t == 'AstStatIf':
            self.emit(ind, 'if %s then' % self.T(st['condition']))
            self.block(st['thenbody'], ind + 1, maxdepth)
            eb = st.get('elsebody')
            while eb is not None and eb['type'] == 'AstStatIf':
                self.emit(ind, 'elseif %s then' % self.T(eb['condition']))
                self.block(eb['thenbody'], ind + 1, maxdepth)
                eb = eb.get('elsebody')
            if eb is not None:
                self.emit(ind, 'else')
                self.block(eb, ind + 1, maxdepth) if eb['type'] == 'AstStatBlock' else self.stmt(eb, ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t == 'AstStatWhile':
            self.emit(ind, 'while %s do' % self.T(st['condition']))
            self.block(st['body'], ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t == 'AstStatRepeat':
            self.emit(ind, 'repeat')
            self.block(st['body'], ind + 1, maxdepth)
            self.emit(ind, 'until %s' % self.T(st['condition']))
        elif t == 'AstStatFor':
            self.emit(ind, 'for %s = %s, %s%s do' % (st['var']['name'], self.T(st['from']), self.T(st['to']),
                      (', ' + self.T(st['step'])) if st.get('step') else ''))
            self.block(st['body'], ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t == 'AstStatForIn':
            self.emit(ind, 'for %s in %s do' % (','.join(v['name'] for v in st['vars']), ','.join(self.T(v) for v in st['values'])))
            self.block(st['body'], ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t == 'AstStatBlock':
            self.emit(ind, 'do')
            self.block(st, ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t == 'AstStatLocalFunction':
            fn = st['func']
            self.emit(ind, 'local function %s(%s%s)' % (st['name']['name'], ','.join(a['name'] for a in fn['args']), ',...' if fn.get('vararg') else ''))
            self.block(fn['body'], ind + 1, maxdepth)
            self.emit(ind, 'end')
        elif t in ('AstStatLocal', 'AstStatAssign', 'AstStatReturn', 'AstStatExpr', 'AstStatCompoundAssign'):
            # expand one level of function expressions if present
            fns = []
            def find(n):
                if isinstance(n, dict):
                    if n.get('type') == 'AstExprFunction':
                        fns.append(n); return
                    for v in n.values(): find(v)
                elif isinstance(n, list):
                    for v in n: find(v)
            find(st)
            txt = self.T(st)
            if fns and len(txt) > 200:
                # print statement with functions elided, then functions
                s = txt
                for f in sorted(fns, key=lambda f: -vmmap.loc(f)[1]):
                    l1, c1, l2, c2 = vmmap.loc(f)
                    pass
                self.emit(ind, '%s  -- stmt with %d function(s) @%s' % (txt[:160].replace('\n', ' '), len(fns), st['location']))
                for f in fns:
                    self.emit(ind, '-- function(%s%s) @%s' % (','.join(a['name'] for a in f['args']), ',...' if f.get('vararg') else '', f['location']))
                    self.block(f['body'], ind + 1, maxdepth)
                    self.emit(ind, '-- end function')
            else:
                self.emit(ind, txt if len(txt) < 3000 else txt[:3000] + ' ...')
        else:
            self.emit(ind, '%s %s' % (t, self.T(st)[:300]))

def find_fn(root, col, line=2):
    found = []
    def v(n):
        if n.get('type') == 'AstExprFunction':
            l1, c1, l2, c2 = vmmap.loc(n)
            if l1 == line and c1 == col: found.append(n)
    vmmap.walk(root, v)
    return found[0] if found else None

if __name__ == '__main__':
    path, col = sys.argv[1], int(sys.argv[2])
    maxd = int(sys.argv[3]) if len(sys.argv) > 3 else 99
    f = Fmt(path)
    fn = find_fn(f.root, col)
    f.emit(0, 'function(%s%s) @%s' % (','.join(a['name'] for a in fn['args']), ',...' if fn.get('vararg') else '', fn['location']))
    f.block(fn['body'], 1, maxd)
    print('\n'.join(f.out))

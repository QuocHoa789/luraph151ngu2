# Test results — V15.1 phase 6 (all commands were run in this session; logs in `research/phase6/logs/`)

Environment variables used for the dump-based / regression tests:
`DEOB_V151_DUMP=<traced harness dump of the sample> DEOB_V15_BASELINE=<RideAPet.lua from v4/v5> DEOB_V15_REFERENCE=<extracted v5 tree>`

| Suite | Command | Result | Log |
|---|---|---|---|
| Return-site abstraction (SYNTHETIC) | `python3 -m unittest tests.test_v151_retsite` | **19 OK** | `test_v151_retsite.log` |
| Phase 6: classes, diag reports, verdict contract, depth widening (SYNTHETIC records) | `python3 -m unittest tests.test_v151_phase6` | **27 OK** | `test_v151_phase6.log` |
| Round 2 (+ real-dump replay of proto 11/21) | `python3 -m unittest tests.test_v151_round2` | **25 OK** | `test_v151_round2.log` |
| Recovery | `python3 -m unittest tests.test_devirt_recovery` | **9 OK** | `test_devirt_recovery.log` |
| Round 1 + V15 untouched + V15 regression | `python3 -m unittest tests.test_v151` | **22 OK, 1 skipped** (end-to-end, needs `DEOB_E2E=1`) | `test_v151_round1_with_v15_regression.log` |
| Node platform / launch / parse | `node tests/test_platform.js` | **18 passed** | `test_platform.log` |
| V15 RideAPet vs baseline | inside `tests.test_v151.V15Regression` | **byte-identical** | same |
| V15 protected files | `cmp` + sha256 vs the v5 tree | **identical** (`research/phase6/v15_protected_hashes.txt`) | |

Evidence labels: the `test_v151_retsite` and `test_v151_phase6` suites are synthetic (a miniature register VM driven through the
real patched walk / hand-built records). `DumpBased` in round 2 and `tests.test_v151` use the real sample's dump.

Required-test coverage: multiple return destinations, different call sites, nested helpers, return-value/register
preservation (the register assignment is emitted and compared), jump-register control flow, pathological expansion (600
call sites), cycles/recursion, nil-call root-cause classification, unknown-opcode preservation, dynamic-materialisation
class, proto/closure edge class, V15.1 verdict contract (PARTIAL != PASS, entered-but-unlifted proto, dangling edge,
budget), artifact files written and parseable, platform ABSENT / WRONG_FORMAT / CANNOT_LAUNCH / LAUNCHES / PARSE_FAILS / OK.

A test found a real defect during this phase: the dump replay of proto 11 failed with the first version of the abstraction
(`research/phase6/logs/dump_test_regression.txt`), which led to the site bound.

## Native runtime availability (this sandbox)
`bin/luau` and `bin/luau-ast` are Linux x86-64 ELF files built in this sandbox: they launch (exit 0) and `luau-ast` parses a probe chunk
(`native_runtime_probe.txt`). They are **not shipped** in the ZIP. `bin/*.exe` are PE files: on Android/Termux they are
reported WRONG_FORMAT and never executed; on Termux (arm64) the user must install a native build (`install-termux.sh`).

## Full real pipeline
No completed run for the final code (see `metrics-baseline-vs-final.json`, `not_completed_runs`). The end-to-end test was not
run for the final code.

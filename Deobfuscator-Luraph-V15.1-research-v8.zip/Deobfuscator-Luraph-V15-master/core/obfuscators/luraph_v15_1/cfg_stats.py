"""Bounded, deterministic convergence diagnostics of one CFG walk (phase 7).

For a finished (or stopped) walk `order` = [(state key, node)] this answers, with numbers instead of logs:
  * how many states, how many distinct instructions, how many states per instruction (duplication);
  * for the most duplicated instructions, WHICH component of the state key makes the copies different
    (depth / jump registers / overlay / packs / carried locals / decode keys), and how many values each has;
  * the transitions that lead into the most duplicated instruction (predecessor instruction histogram).
State key layout (see luraph_v15 State.key + State151.key): (mode, pc, depth, jregs, ov, packs, locs[, keys, kvals]).
Nothing here changes the walk.
"""
import collections

COMPONENTS = ("depth", "jregs", "overlay", "packs", "locs", "keys", "kvals")


def _hashable(x):
    try:
        hash(x)
        return x
    except TypeError:
        return repr(x)


def duplication(order, top=5):
    by_pc = collections.defaultdict(list)
    for k, _n in order:
        by_pc[(k[0], k[1])].append(k)
    dup = sorted(by_pc.items(), key=lambda kv: (-len(kv[1]), kv[0]))[:top]
    rows = []
    for (mode, pc), keys in dup:
        comp = {}
        for i, name in enumerate(COMPONENTS):
            vals = {_hashable(k[2 + i]) for k in keys if len(k) > 2 + i}
            comp[name] = len(vals)
        # the explaining component(s): those whose distinct count is > 1 (sorted by count)
        varying = sorted((n, c) for c, n in comp.items() if n > 1)
        rows.append({"pc": "%s:%s" % (mode, pc), "states": len(keys), "distinct_per_component": comp,
                     "varying": [c for _n, c in reversed(varying)]})
    return rows


def summary(order, top=5):
    states = len(order)
    pcs = {(k[0], k[1]) for k, _n in order}
    errors = sum(1 for _k, n in order if getattr(n, "error", None))
    dup = duplication(order, top)
    return {"states": states, "distinct_instructions": len(pcs),
            "mean_states_per_instruction": round(states / max(1, len(pcs)), 3),
            "error_nodes": errors, "most_duplicated": dup}


def predecessors_of(prog, order, target, top=5):
    """Histogram of the predecessor instructions of the states at `target` ((mode, pc))."""
    pred = getattr(prog, "pred", None) or {}
    h = collections.Counter()
    for k, _n in order:
        if (k[0], k[1]) == target:
            p = pred.get(k)
            if p is not None:
                h[(p[0], p[1])] += 1
    return [{"from": "%s:%s" % pc, "states": n} for pc, n in sorted(h.items(), key=lambda kv: (-kv[1], kv[0]))[:top]]

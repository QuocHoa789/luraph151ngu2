"""Deep lift diagnostics for Luraph v15.1 (round 2, phases 1-5).

Everything the engine could not lift, or lifted into something suspicious, is
recorded as a structured record and written as JSON (``<dpath>.v151diag.json``,
or ``$DEOB_V151_DIAG``).  Nothing here changes what the engine lifts: it only
observes.

Records
-------
UNLIFTED BLOCK   (one per (proto, mode, pc) the walk could not step/propagate)
    proto, closure, mode, pc, opcode, handler{loc, kind, semantic}, reason (enum),
    block_class (enum, phase 4), message, predecessors[], successors[],
    registers{r: fact}, operands{array: {raw, current, writer}},
    upvalues, closure_ref, materialization{...}, reachable_from_entry,
    affects{call, return, closure, jump}
NIL CALL         (one per call statement whose callee is the constant nil)
    proto, closure, mode, pc, opcode, callee, args[], kind (enum), operands,
    register_candidates[{reg, last_writer | "never written on the path"}],
    predecessor, constant_source
EXPANSION        (decode-in-place + re-execute events; phase 5)
    proto, mode, pc, trigger handler, array writes (name -> old/new), reexecute count

``reason`` is derived from the engine message by ``reason_of`` and
``block_class`` from reason + evidence by ``class_of``; both are rule based and
carry the evidence they used.  Unmatched messages stay ``UNKNOWN`` / ``OTHER``.
"""
import json
import os
import re

MAX_RECORDS = int(os.environ.get("DEVIRT_DIAG_MAX", "20000"))
MAX_WRITES = int(os.environ.get("DEVIRT_DIAG_MAX_WRITES", "400000"))   # distinct (proto, index) keys

REASONS = ("UNKNOWN_OPCODE", "BAD_SUCCESSOR", "INVALID_REGISTER", "MISSING_CONSTANT", "MISSING_CLOSURE",
           "DYNAMIC_EXPANSION", "UNSUPPORTED_CALL", "TYPE_MISMATCH", "BUFFER_RANGE", "BOUND_EXCEEDED", "UNKNOWN")
CLASSES = ("MISSING_CFG_SUCCESSOR", "WRONG_BRANCH_TARGET", "DYNAMIC_MATERIALIZATION", "UNKNOWN_OPCODE_SEMANTIC",
           "MISSING_CLOSURE_EDGE", "MISSING_PROTO_EDGE", "BAD_REGISTER_STATE", "BAD_CONSTANT", "UNSUPPORTED_CALL",
           "UNKNOWN_RETURN_CONTINUATION", "RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW",
           "JUNK_UNREACHABLE", "OTHER")
NIL_KINDS = ("NIL_CALL_REGISTER", "NIL_CALL_CLOSURE", "NIL_CALL_PROTO", "NIL_CALL_ENV", "NIL_CALL_CONSTANT",
             "NIL_CALL_DYNAMIC", "NIL_CALL_UNKNOWN")
VALUE_TYPES = ("REGISTER", "INTEGER", "NUMBER", "STRING", "BOOLEAN", "NIL", "FUNCTION", "CLOSURE", "PROTO",
               "TABLE", "ENVIRONMENT VALUE", "UNKNOWN")


def type_of(v):
    """Phase 3 value type names (exact; never coerced)."""
    if v is None:
        return "NIL"
    if isinstance(v, bool):
        return "BOOLEAN"
    if isinstance(v, int):
        return "INTEGER"
    if isinstance(v, float):
        return "NUMBER"
    if isinstance(v, (bytes, str)):
        return "STRING"
    n = type(v).__name__
    if n == "Reg":
        return "REGISTER"
    if n in ("LTable",):
        return "TABLE"
    if n == "ClosureExpr":
        return "CLOSURE"
    if n in ("OpaqueFn", "LuaFunc", "Builtin"):
        return "FUNCTION"
    if n in ("Global", "Opaque"):
        return "ENVIRONMENT VALUE"
    return "UNKNOWN"


def show(v, limit=60):
    n = type(v).__name__
    if v is None:
        s = "nil"
    elif isinstance(v, bytes):
        s = "b%r" % v.decode("latin-1")
    elif n == "Reg":
        s = "r%s" % getattr(v, "n", "?")
    elif n == "Const":
        s = "const(%s)" % show(v.v)
    elif isinstance(v, (bool, int, float)):
        s = repr(v)
    elif n == "LTable":
        s = "table#%s" % getattr(v, "tid", None)
    else:
        s = "<%s>" % n
    return s if len(s) <= limit else s[:limit - 1] + "…"


# ---------------------------------------------------------------------------
# classification (rule based; every rule names its evidence)
# ---------------------------------------------------------------------------

def reason_of(msg):
    m = msg or ""
    rules = (
        (r"opcode=None|unknown opcode|no handler", "UNKNOWN_OPCODE"),
        (r"needs a constant that is not decoded yet", "MISSING_CONSTANT"),
        (r"closure of non-proto|closure needs", "MISSING_CLOSURE"),
        (r"call of unknown VM function|unsupported call|call of", "UNSUPPORTED_CALL"),
        (r"instruction expansion|expansion cycle|re-decoded", "DYNAMIC_EXPANSION"),
        (r"out of range \(offset", "BUFFER_RANGE"),
        (r"table\.move of \d+ elements|string\.rep|bound \d+\)", "BOUND_EXCEEDED"),
        (r"symbolic next pc|stack depth|restart|inconsistent", "BAD_SUCCESSOR"),
        (r"arith on|compare |concat|bit32\.\w+ failed|index nil|newindex|storing a non-empty VM table|attempt to", "TYPE_MISMATCH"),
        (r"register|reg ", "INVALID_REGISTER"),
    )
    for pat, r in rules:
        if re.search(pat, m):
            return r
    return "UNKNOWN"


def _is_string_operand(msg):
    return bool(re.search(r"b'[^']*'", msg or ""))


def class_of(reason, msg, pc, code_len, writers):
    """(class, evidence) for one unlifted block."""
    if isinstance(pc, int) and code_len and pc > code_len + 64:
        return "WRONG_BRANCH_TARGET", "pc %d is far outside the instruction array (length %d)" % (pc, code_len)
    if reason == "BAD_SUCCESSOR":
        if re.search(r"stack depth", msg or ""):
            return ("RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW",
                    "more distinct loop-stack depths at one instruction than the walk allows")
        if re.search(r"symbolic next pc/mode: \(?r\d+( (Add|Sub) -?\d+)?\)? /", msg or ""):
            return ("UNKNOWN_RETURN_CONTINUATION",
                    "the next pc is a register (+ offset) whose constant assignments the walk did not record "
                    "(a return / computed jump with no known continuation set)")
        return "MISSING_CFG_SUCCESSOR", "the walk could not resolve the next pc/mode"
    if reason == "DYNAMIC_EXPANSION":
        return "DYNAMIC_MATERIALIZATION", "expansion bound/cycle reached"
    if reason == "UNKNOWN_OPCODE":
        return "UNKNOWN_OPCODE_SEMANTIC", "no handler for the decoded opcode"
    if reason == "MISSING_CLOSURE":
        return "MISSING_PROTO_EDGE", "closure creation without a resolvable proto"
    if reason == "UNSUPPORTED_CALL":
        return "UNSUPPORTED_CALL", msg or ""
    if reason == "MISSING_CONSTANT":
        return "BAD_CONSTANT", "lazy constant not decoded (a further harness round may supply it)"
    if reason in ("BUFFER_RANGE", "BOUND_EXCEEDED"):
        return "BAD_REGISTER_STATE", "operand/offset value out of any legitimate range: %s" % msg
    if reason == "TYPE_MISMATCH":
        if writers:
            return "DYNAMIC_MATERIALIZATION", "operand arrays at this pc were written by in-place decode (%s)" % writers
        if _is_string_operand(msg):
            return "BAD_CONSTANT", "a decoded string reached a numeric/bit operation (the real VM would raise here)"
        return "BAD_REGISTER_STATE", "operation on operands of the wrong type"
    return "OTHER", msg or ""


def nil_kind(callee_src, regs):
    """NIL_CALL_* for one nil call, from where the nil came from."""
    if callee_src == "closure":
        return "NIL_CALL_CLOSURE"
    if callee_src == "proto":
        return "NIL_CALL_PROTO"
    if callee_src == "env":
        return "NIL_CALL_ENV"
    if callee_src == "constant":
        return "NIL_CALL_CONSTANT"
    if callee_src == "dynamic":
        return "NIL_CALL_DYNAMIC"
    if callee_src == "register":
        return "NIL_CALL_REGISTER"
    return "NIL_CALL_UNKNOWN"


# ---------------------------------------------------------------------------
# collector
# ---------------------------------------------------------------------------

class Diag:
    def __init__(self):
        self.reset()

    def reset(self):
        self.cur = None                 # (proto_key, mode, pc, closure)
        self.writes = {}                # (proto_key, index) -> {array: [ {writer, new, old}, ... ]} (last 4)
        self.nwrites = 0
        self.unlifted = {}              # (proto_key, mode, pc) -> record
        self.nil_calls = {}             # (proto_key, mode, pc, n) -> record
        self.expansions = {}            # (proto_key, mode, pc) -> {"count", ...}
        self.exp_log = []
        self.walks = 0
        self.budget_hits = []           # lowering budget stops (engine_patch._BackendProxy)
        self.ret_sites = {}             # proto key -> return-site abstraction report (retsite.report)
        self.depth_growth = {}          # (mode, pc) -> {"states_refused", "cap_depths", "max_depth"} (phase 8 quarantine)
        self.unpack_overflows = []      # bounded: infeasible register-range unpacks refused (phase 7)
        self.walk_notes = []            # bounded notes about walk restarts / deferrals (phase 7)
        self.walk_records = []          # conformance.record_walk of every finished walk (keyed by closure instance)
        self.facts = {}                 # (proto_key, mode, pc) -> register facts snapshot (error / nil-call nodes only)
        self.overflow = False
        self.last_error = None

    def note_depth_growth(self, proto, mode, pc, ndepths, depth):
        d = self.depth_growth.setdefault((proto, mode, pc), {"states_refused": 0, "distinct_depths_at_cap": ndepths, "max_depth": depth})
        d["states_refused"] += 1
        d["max_depth"] = max(d["max_depth"], depth)

    def note_unpack_overflow(self, i, j, bound):
        if len(self.unpack_overflows) < 50:
            self.unpack_overflows.append({"cur": list(self.cur[:3]) if self.cur else None, "from": i, "to": j, "bound": bound})

    def begin_proto(self, proto_key):
        """A (re)walk of `proto_key` starts: only its latest walk is reported."""
        for store in (self.unlifted, self.nil_calls, self.expansions):
            for k in [k for k in store if k[0] == proto_key]:
                del store[k]
        for k in [k for k in self.depth_growth if k[0] == proto_key]:
            del self.depth_growth[k]
        for k in [k for k in self.facts if k[0] == proto_key]:
            del self.facts[k]
        for k in [k for k in self.writes if k[0] == proto_key]:
            del self.writes[k]
        self.walks += 1

    def add_walk(self, rec, closure):
        """Keep the finished walk of one closure instance (a re-walk of the same instance replaces it)."""
        self.walk_records = [r for r in self.walk_records if not (r["proto"] == rec["proto"] and r["closure"] == closure)]
        self.walk_records.append(rec)

    # -- context ------------------------------------------------------------
    def set_cur(self, proto_key, mode, pc, closure=None):
        self.cur = (proto_key, mode, pc, closure)

    # -- provenance of instruction-array writes -----------------------------
    def note_write(self, proto_key, array, index, new, old, op):
        slot = self.writes.get((proto_key, index))
        if slot is None:
            if len(self.writes) >= MAX_WRITES:
                self.overflow = True
                return
            slot = self.writes[(proto_key, index)] = {}
        self.nwrites += 1
        c = self.cur or (None, None, None, None)
        lst = slot.setdefault(array, [])
        lst.append({"writer": {"mode": c[1], "pc": c[2], "opcode": op}, "new": show(new), "old": show(old),
                    "new_type": type_of(new), "old_type": type_of(old)})
        if len(lst) > 4:
            del lst[0]

    def writers_at(self, proto_key, index):
        """{array: last writer} for the arrays written at `index`."""
        slot = self.writes.get((proto_key, index))
        return {a: l[-1] for a, l in slot.items() if l} if slot else {}

    # -- records ------------------------------------------------------------
    def add_unlifted(self, rec):
        k = (rec["proto"], rec["mode"], rec["pc"])
        if k in self.unlifted or len(self.unlifted) < MAX_RECORDS:
            old = self.unlifted.get(k)
            if old:
                rec["seen"] = old.get("seen", 1) + 1
            self.unlifted[k] = rec
        else:
            self.overflow = True

    def add_nil_call(self, rec):
        k = (rec["proto"], rec["mode"], rec["pc"], rec.get("index", 0))
        if k in self.nil_calls or len(self.nil_calls) < MAX_RECORDS:
            self.nil_calls[k] = rec
        else:
            self.overflow = True

    def add_expansion(self, proto_key, mode, pc, trigger, opcode, fields):
        k = (proto_key, mode, pc)
        e = self.expansions.get(k)
        if e is None:
            e = self.expansions[k] = {"proto": proto_key, "mode": mode, "pc": pc, "trigger": trigger,
                                      "opcode": opcode, "reexecute_count": 0, "fields": {}, "history": []}
        e["reexecute_count"] += 1
        e["fields"] = fields
        if len(e["history"]) < 8:
            e["history"].append({"opcode": opcode, "fields": fields})

    # -- summaries ------------------------------------------------------------
    def summary(self):
        by_reason, by_class, by_nil = {}, {}, {}
        for r in self.unlifted.values():
            by_reason[r["reason"]] = by_reason.get(r["reason"], 0) + 1
            by_class[r["block_class"]] = by_class.get(r["block_class"], 0) + 1
        for r in self.nil_calls.values():
            by_nil[r["kind"]] = by_nil.get(r["kind"], 0) + 1
        causes = {}
        for r in self.nil_calls.values():
            causes[r.get("root_cause", "?")] = causes.get(r.get("root_cause", "?"), 0) + 1
        return {"unlifted_blocks": len(self.unlifted), "by_reason": by_reason, "by_class": by_class,
                "nil_calls": len(self.nil_calls), "nil_by_kind": by_nil, "nil_by_root_cause": causes,
                "expansion_sites": len(self.expansions), "budget_hits": len(self.budget_hits), "overflow": self.overflow}

    def as_dict(self):
        return {"summary": self.summary(),
                "unlifted_blocks": sorted(self.unlifted.values(), key=lambda r: (str(r["proto"]), r["mode"], r["pc"])),
                "nil_calls": sorted(self.nil_calls.values(), key=lambda r: (str(r["proto"]), r["mode"], r["pc"])),
                "expansions": sorted(self.expansions.values(), key=lambda r: (str(r["proto"]), r["mode"], r["pc"])),
                "budget_hits": list(self.budget_hits), "return_sites": dict(self.ret_sites), "walk_notes": list(self.walk_notes[:200]), "unpack_overflows": list(self.unpack_overflows),
                "depth_growth": [dict(proto=k0, mode=m, pc=p, **v) for (k0, m, p), v in sorted(self.depth_growth.items(), key=lambda kv: str(kv[0]))]}

    def write(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.as_dict(), f, indent=1, default=str)
        return path


def format_block(r):
    """Human form of one unlifted block (the spec's `UNLIFTED BLOCK` layout)."""
    lines = ["UNLIFTED BLOCK", "",
             "proto=%s" % r["proto"], "closure=%s" % r.get("closure"), "mode=%s" % r["mode"], "pc=%s" % r["pc"],
             "opcode=%s" % r.get("opcode"), "handler=%s" % (r.get("handler") or {}).get("loc"), "",
             "reason:", "  %s  (%s)" % (r["reason"], r["block_class"]), "  %s" % r["message"]]
    return "\n".join(lines)

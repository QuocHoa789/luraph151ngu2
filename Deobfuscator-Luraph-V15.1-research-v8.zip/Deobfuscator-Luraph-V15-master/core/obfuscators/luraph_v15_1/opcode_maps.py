"""Per-mode opcode mapping for Luraph v15.1 (Phase 3).

Nothing here is a hand-written opcode table.  Every handler of every
dispatcher is located in the AST (``vmmap``), its structural *features* are
extracted, and an :class:`OpcodeSpec` is produced:

    OpcodeSpec(mode, opcode, name, kind, pc_effect, operands, features,
               confidence, source)

``name``/``kind`` are only assigned when the structural features identify the
operation (SAMPLE-SPECIFIC HEURISTIC rules below, all listed in ``RULES``);
otherwise ``kind == "UNKNOWN"`` with ``confidence == 0.0`` and the features are
kept so that the shared IR can emit ``V151_UNKNOWN(mode, opcode, operands)``.

Opcode numbers are *per mode* (and per sample): the same number means a
different operation in a different mode, so the lookup key is always
``(mode, opcode)``.

PC effects (shared with the IR, see ``ir_bridge.py``)::

    NEXT                 falls through to pc+1
    ADVANCE(n)           pc += n
    JUMP                 pc is assigned unconditionally
    COND_JUMP            pc is assigned under a condition
    RETURN               leaves the VM function
    MODE_SWITCH          leaves the dispatch loop (``break``): another mode takes over
    EXPAND_AND_REEXECUTE the handler rewrites the instruction stream and
                         decrements pc so that the rewritten instruction runs next
"""
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

from obfuscators.luraph_v15_1 import vmmap as VM          # noqa: E402

NEXT, JUMP, COND_JUMP, RETURN = "NEXT", "JUMP", "COND_JUMP", "RETURN"
MODE_SWITCH, EXPAND = "MODE_SWITCH", "EXPAND_AND_REEXECUTE"
UNKNOWN = "UNKNOWN"

# (rule name, kind, minimum confidence, description) -- documentation of the
# heuristics, kept next to the code that applies them.
RULES = [
    ("return", "RETURN", 0.9, "handler contains `return` (ends the VM function)"),
    ("mode_switch", "MODE_SWITCH", 0.9, "handler `break`s out of the dispatch loop after assigning the mode variable"),
    ("blob_decrypt", "BLOB_DECRYPT", 0.8,
     "reads+writes a buffer with a 4-byte loop and rewrites its own instruction (in-place string/blob decryption)"),
    ("self_rewrite", "SELF_REWRITE", 0.7, "writes instruction arrays at the current pc only"),
    ("expand", "EXPAND", 0.8, "writes instruction arrays and decrements pc (EXPAND_AND_REEXECUTE)"),
    ("make_closure", "CLOSURE", 0.8, "calls a child factory with an upvalue list and stores the result"),
    ("call", "CALL", 0.7, "calls a register value with the result stored back through table.move/unpack helpers"),
    ("cond_jump", "COND_JUMP", 0.6, "assigns pc under a comparison"),
    ("jump", "JUMP", 0.6, "assigns pc unconditionally"),
    ("compare", "COMPARE", 0.4, "comparison without pc effect"),
    ("table_new", "NEWTABLE", 0.5, "builds a table (`table.create`/`{}`) and stores it"),
    ("arith", "ARITH", 0.4, "arithmetic/bitwise result stored in a register"),
    ("move", "MOVE", 0.4, "plain register/constant store"),
]


class OpcodeSpec:
    __slots__ = ("mode", "opcode", "name", "kind", "pc_effect", "advance", "operands", "features",
                 "confidence", "source", "block")

    def __init__(self, mode, opcode, kind, pc_effect, advance, operands, features, confidence, source, block=None):
        self.mode, self.opcode = mode, opcode
        self.kind = kind
        self.name = "%s_%s_%s" % (kind, mode, opcode) if kind != UNKNOWN else "UNKNOWN_%s_%s" % (mode, opcode)
        self.pc_effect, self.advance = pc_effect, advance
        self.operands, self.features = operands, features
        self.confidence, self.source, self.block = confidence, source, block

    @property
    def known(self):
        return self.kind != UNKNOWN

    def as_dict(self):
        return {"mode": self.mode, "opcode": self.opcode, "name": self.name, "kind": self.kind,
                "pc_effect": self.pc_effect, "advance": self.advance, "operands": list(self.operands),
                "features": dict(self.features), "confidence": self.confidence, "source": self.source}

    def __repr__(self):
        return "OpcodeSpec(%s/%s %s %s conf=%.2f)" % (self.mode, self.opcode, self.kind, self.pc_effect, self.confidence)


# ---------------------------------------------------------------------------
# feature extraction
# ---------------------------------------------------------------------------

def _is_local(n, name=None, loc=None):
    if n.get("type") != "AstExprLocal":
        return False
    if loc is not None:
        return n["local"]["location"] == loc
    return name is None or n["local"]["name"] == name


def _const_num(n):
    while n.get("type") == "AstExprGroup":
        n = n["expr"]
    if n.get("type") == "AstExprConstantNumber":
        return n["value"]
    return None


def _pc_delta(expr, pc_loc):
    """+k / -k when expr is `pc +/- k`, else None."""
    while expr.get("type") == "AstExprGroup":
        expr = expr["expr"]
    if expr.get("type") != "AstExprBinary" or expr["op"] not in ("Add", "Sub"):
        return None
    l, r = expr["left"], expr["right"]
    if _is_local(l, loc=pc_loc) and _const_num(r) is not None:
        k = _const_num(r)
        return k if expr["op"] == "Add" else -k
    if expr["op"] == "Add" and _is_local(r, loc=pc_loc) and _const_num(l) is not None:
        return _const_num(l)
    return None


def _walk(node, depth=0, under_if=False, out=None):
    """Yield (node, in_branch) for every statement/expression below node."""
    if isinstance(node, dict):
        t = node.get("type")
        yield node, under_if
        if t == "AstStatIf":
            yield from _walk(node["condition"], depth, under_if)
            yield from _walk(node["thenbody"], depth + 1, True)
            if node.get("elsebody"):
                yield from _walk(node["elsebody"], depth + 1, True)
            return
        if t == "AstExprFunction":
            return                      # nested function: not part of the handler's own effect
        for k, v in node.items():
            if k in ("type", "location"):
                continue
            if isinstance(v, (dict, list)):
                yield from _walk(v, depth, under_if)
    elif isinstance(node, list):
        for x in node:
            yield from _walk(x, depth, under_if)


def features_of(block, disp, mode_decl=None):
    """Structural facts about one handler block (a dict, no interpretation)."""
    pc_loc = disp["pc_decl"]
    arr_loc = disp["arr_decl"]
    f = {
        "pc_assign": [],            # (delta|None, in_branch)
        "returns": 0, "breaks": 0,
        "calls": 0, "loops": 0, "ifs": 0,
        "indexed_by_pc": set(),     # names of arrays read at [pc]
        "written_by_pc": set(),     # names of arrays written at [pc]
        "written_other": set(),     # names of arrays written at a non-pc index of an *instruction* array
        "buffer_helpers": 0,
        "compares": 0, "arith": 0, "newtable": 0, "closures": 0,
        "mode_assign": False,
        "stores": 0,
    }
    for n, br in _walk(block):
        t = n.get("type")
        if t == "AstStatReturn":
            f["returns"] += 1
        elif t == "AstStatBreak":
            f["breaks"] += 1
        elif t in ("AstStatWhile", "AstStatRepeat", "AstStatFor", "AstStatForIn"):
            f["loops"] += 1
        elif t == "AstStatIf":
            f["ifs"] += 1
        elif t == "AstExprCall":
            f["calls"] += 1
        elif t == "AstExprTable":
            f["newtable"] += 1
        elif t == "AstExprFunction":
            f["closures"] += 1
        elif t == "AstExprBinary":
            if n["op"].startswith("Compare"):
                f["compares"] += 1
            elif n["op"] in ("Add", "Sub", "Mul", "Div", "Mod", "Pow", "FloorDiv", "Concat"):
                f["arith"] += 1
        elif t == "AstExprIndexExpr":
            if _is_local(n["index"], loc=pc_loc) and n["expr"].get("type") == "AstExprLocal":
                f["indexed_by_pc"].add(n["expr"]["local"]["name"])
        elif t == "AstStatAssign":
            for v, e in zip(n["vars"], n["values"]):
                f["stores"] += 1
                if _is_local(v, loc=pc_loc):
                    f["pc_assign"].append((_pc_delta(e, pc_loc), br))
                elif v.get("type") == "AstExprIndexExpr" and _is_local(v["index"], loc=pc_loc) \
                        and v["expr"].get("type") == "AstExprLocal":
                    f["written_by_pc"].add(v["expr"]["local"]["name"])
                elif v.get("type") == "AstExprIndexExpr" and v["expr"].get("type") == "AstExprLocal" \
                        and v["expr"]["local"]["name"] in f["indexed_by_pc"]:
                    f["written_other"].add(v["expr"]["local"]["name"])
                if mode_decl is not None and any(_is_local(v, loc=m) for m in
                                                 (mode_decl if isinstance(mode_decl, (set, frozenset, tuple, list)) else (mode_decl,))):
                    f["mode_assign"] = True
            # multiple assignment `i,E=U,c` also writes the pc
        elif t == "AstStatCompoundAssign":
            v = n["var"]
            if _is_local(v, loc=pc_loc):
                k = _const_num(n["value"])
                d = None if k is None else (k if n["op"] == "Add" else -k if n["op"] == "Sub" else None)
                f["pc_assign"].append((d, br))
    f["indexed_by_pc"] = sorted(f["indexed_by_pc"])
    f["written_by_pc"] = sorted(f["written_by_pc"])
    f["written_other"] = sorted(f["written_other"])
    return f


def _pc_effect(f):
    if f["returns"]:
        return RETURN, 1
    if f["breaks"] and (not f["pc_assign"] or f["mode_assign"]):
        return MODE_SWITCH, 1
    eff, adv = NEXT, 1
    for d, br in f["pc_assign"]:
        if d == -1 and (f["written_by_pc"] or f["written_other"]):
            return EXPAND, 0
        if d is not None and d > 0 and not br:
            eff, adv = ("NEXT" if d == 1 else "ADVANCE"), d + 0
            continue
        eff, adv = (COND_JUMP if br else JUMP), 1
    return eff, adv


def classify(f):
    """(kind, confidence, rule) from features; UNKNOWN when no rule applies."""
    eff, _ = _pc_effect(f)
    if f["returns"]:
        return "RETURN", 0.9, "return"
    if f["breaks"] and (not f["pc_assign"] or f["mode_assign"]):
        return "MODE_SWITCH", 0.9, "mode_switch"
    if eff == EXPAND:
        return "EXPAND", 0.8, "expand"
    if f["written_by_pc"] and f["loops"] and f["calls"] >= 2:
        return "BLOB_DECRYPT", 0.8, "blob_decrypt"
    if f["written_by_pc"] and not f["calls"]:
        return "SELF_REWRITE", 0.7, "self_rewrite"
    if eff == COND_JUMP:
        return "COND_JUMP", 0.6, "cond_jump"
    if eff == JUMP:
        return "JUMP", 0.6, "jump"
    if f["calls"] and f["loops"] and f["ifs"] >= 3 and f["closures"] == 0 and len(f["indexed_by_pc"]) >= 1:
        # upvalue-list builder + factory call (`for m=1,g do ... end; B=w[i](W,nil,nil)`)
        return "CLOSURE", 0.8, "make_closure"
    if f["calls"]:
        return "CALL", 0.5, "call"
    if f["compares"] and not f["arith"]:
        return "COMPARE", 0.4, "compare"
    if f["newtable"]:
        return "NEWTABLE", 0.5, "table_new"
    if f["arith"]:
        return "ARITH", 0.4, "arith"
    if f["stores"] and not f["calls"]:
        return "MOVE", 0.4, "move"
    return UNKNOWN, 0.0, None


# ---------------------------------------------------------------------------
# mapper
# ---------------------------------------------------------------------------

class OpcodeMapper:
    """Opcode map of one backend (mode)."""

    def __init__(self, mode, family, specs, unresolved):
        self.mode, self.family = mode, family
        self.specs = specs                  # {opcode: OpcodeSpec}
        self.unresolved = unresolved        # opcodes with no handler (falls to default branch)

    def __len__(self):
        return len(self.specs)

    def get(self, opcode):
        s = self.specs.get(opcode)
        if s is None:
            return OpcodeSpec(self.mode, opcode, UNKNOWN, NEXT, 1, [], {}, 0.0, "no-handler")
        return s

    def name(self, opcode):
        return self.get(opcode).name

    @property
    def unknown(self):
        return sorted(o for o, s in self.specs.items() if not s.known)

    def handlers(self):
        """One spec per distinct handler leaf (the first opcode value that reaches it)."""
        seen, out = set(), []
        for op in sorted(self.specs):
            s = self.specs[op]
            k = s.block["location"] if s.block else op
            if k not in seen:
                seen.add(k)
                out.append(s)
        return out

    def summary(self):
        kinds = {}
        hs = self.handlers()
        for s in hs:
            kinds[s.kind] = kinds.get(s.kind, 0) + 1
        return {"mode": self.mode, "family": self.family, "handlers": len(hs),
                "opcode_values": len(self.specs), "unknown": sum(1 for s in hs if not s.known),
                "default_leaves": sum(1 for s in hs if s.features.get("default_leaf")), "kinds": kinds}


_SPEC_CACHE = {}


def _spec_stmts(stmts, opkey, value):
    out, changed = [], False
    for st in stmts:
        if st.get("type") == "AstStatIf":
            r = VM.eval_pred(st["condition"], opkey, value, {})
            if r is not None:
                changed = True
                br = st["thenbody"] if r else st.get("elsebody")
                if br is None:
                    continue
                if br.get("type") == "AstStatBlock":
                    sub, _ = _spec_stmts(br["body"], opkey, value)
                    out.extend(sub)
                else:                                   # `elseif`: a nested AstStatIf
                    sub, _ = _spec_stmts([br], opkey, value)
                    out.extend(sub)
                continue
        out.append(st)
    return out, changed


def specialize(block, opkey, value):
    """The handler body as it behaves for the concrete opcode `value`: `if`
    statements whose condition is a pure function of the opcode variable are
    folded away (shared leaves such as ``if S<75 ... elseif S~=76 ... else ...``).
    Returns `block` itself when nothing could be folded.  Statements the fold
    does not understand are kept untouched, so this never invents behaviour."""
    stmts, changed = _spec_stmts(block["body"], opkey, value) if block.get("type") == "AstStatBlock" else (None, False)
    if not changed:
        return block
    nb = dict(block)
    nb["body"] = stmts
    nb["specialized_for"] = value
    return nb


def build_mappers(root, lines=None, max_op=256):
    """{mode: OpcodeMapper} for every backend found in `root`."""
    out = {}
    backs = VM.detect_v151_backend(root)
    for b in backs:
        if b.mode is None:
            continue
        d = b.dispatcher
        # every mode variable of the backends (legacy-shaped makers: the mode a
        # dispatcher runs under is `c`, the one its handlers switch is `E`)
        mode_decl = frozenset(x.mode_info.get("decl") for x in backs if x.mode_info and x.mode_info.get("decl"))
        if b.mode_info and b.mode_info.get("decl"):
            mode_decl = mode_decl | {b.mode_info["decl"]}
        specs = {}
        hmap = VM.handler_map(d, lines, max_op=max_op)
        opkey = VM.opkey_of(d)
        for key, h in hmap.items():
            # A leaf shared by several opcodes may still branch on the opcode
            # variable itself (`if S<75 then .. elseif S~=76 then .. else ..`);
            # each opcode is then classified on its own specialised body.
            groups = {}
            for op in h["ops"]:
                blk = specialize(h["node"], opkey, op)
                groups.setdefault(id(blk), (blk, []))[1].append(op)
            for blk, ops in groups.values():
                f = features_of(blk, d, mode_decl)
                f["aliases"] = len(ops)             # opcode values that reach this body
                f["default_leaf"] = len(ops) > 4    # out-of-range values fall into the extreme leaf
                f["specialized"] = blk is not h["node"]
                kind, conf, rule = classify(f)
                eff, adv = _pc_effect(f)
                if kind == "RETURN":
                    eff = RETURN
                operands = f["indexed_by_pc"]
                for op in ops:
                    specs[op] = OpcodeSpec(b.mode, op, kind, eff, adv, operands, f, conf,
                                           "rule:%s" % rule if rule else "no-rule", blk)
        out[b.mode] = OpcodeMapper(b.mode, b.family, specs, [o for o in range(max_op) if o not in specs])
    return out


_CACHE = {}


def load(path_or_root):
    """Mappers for a source file path (cached) or an already parsed AST root."""
    if isinstance(path_or_root, str):
        if path_or_root not in _CACHE:
            root = VM.load_ast(path_or_root)
            with open(path_or_root, encoding="latin-1") as fh:
                lines = fh.read().split("\n")
            _CACHE[path_or_root] = build_mappers(root, lines)
        return _CACHE[path_or_root]
    return build_mappers(path_or_root)


def get_opcode_mapper(mode, mappers):
    """`get_opcode_mapper(mode)` of the spec: the mapper of one backend mode,
    or None when the sample has no such mode (never a guess)."""
    return mappers.get(mode)


def opcode_name(mode, opcode, mappers):
    m = mappers.get(mode)
    return m.name(opcode) if m else "UNKNOWN_%s_%s" % (mode, opcode)


def main(argv):
    if len(argv) < 2:
        print("usage: opcode_maps.py FILE [--json | --mode M --op N]")
        return 2
    maps = load(argv[1])
    if "--json" in argv:
        import json
        print(json.dumps({str(m): [s.as_dict() for _, s in sorted(mp.specs.items())] for m, mp in maps.items()}))
        return 0
    if "--mode" in argv and "--op" in argv:
        m = int(argv[argv.index("--mode") + 1])
        o = int(argv[argv.index("--op") + 1])
        print(maps[m].get(o).as_dict())
        return 0
    for m, mp in sorted(maps.items()):
        print(mp.summary())
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

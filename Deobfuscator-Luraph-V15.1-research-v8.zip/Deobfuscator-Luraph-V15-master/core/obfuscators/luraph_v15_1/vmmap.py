"""Luraph v15.1 VM mapper.

Static, AST-driven discovery of everything the later stages need:

* dispatch loops of BOTH families that a v15.1 file contains
    - "direct" loops (v15 shape):      while true do local op=ARR[pc]; if op<K then ... end ... end
    - "predicate" loops (new in 15.1): while true do local op=ARR[pc]; local p=op<K; if p then
                                         local p=op>=J; if p then ... end ... end; pc+=1 end
* the per-loop mode selector (`if F==40 then while ...`, `M=F==142; if M then while ...`)
* the VM "makers" (the functions that receive a proto and return a closure factory)
  including the 15.1 layouts where the proto is *not* one table but a list of
  separate arrays passed as maker parameters and the closure is produced by
  `local function g(...)` / `return function(...)` instead of `S,h = n,function...`
* hook edits (proto capture / entry hooks) for the dynamic harness.

Nothing here changes the v15 mapper: `luraph_v15.vmmap` is imported, never
modified.  The v15 helpers that behave identically are re-exported.

Names that mention "SAMPLE-SPECIFIC" are heuristics validated on a single
sample; everything else is derived from AST structure only.
"""
import json
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

from obfuscators.luraph_v15.vmmap import (  # noqa: F401  (re-exported for the shared engine)
    load_ast, loc, text_of, walk, local_name, unwrap_group, decl_key, _decls_in, OPS, FLIP,
)

MAX_OP = 256                     # opcode values probed per dispatcher
MAX_PRED_DEPTH = 4096            # safety bound on tree descent

CMP = ("CompareLt", "CompareLe", "CompareGt", "CompareGe", "CompareEq", "CompareNe")


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------

def iter_dicts(root):
    """All AST nodes (dicts), iteratively (the sample AST is deep)."""
    stack = [root]
    while stack:
        n = stack.pop()
        if isinstance(n, dict):
            yield n
            for v in n.values():
                if isinstance(v, (dict, list)):
                    stack.append(v)
        elif isinstance(n, list):
            stack.extend(x for x in n if isinstance(x, (dict, list)))


_PARENT_CACHE = {}


def parent_map(root):
    """id(node) -> parent node (dict -> dict; lists are transparent)."""
    hit = _PARENT_CACHE.get(id(root))
    if hit is not None and hit[0] is root:
        return hit[1]
    pm = {}
    stack = [root]
    while stack:
        n = stack.pop()
        for v in n.values():
            if isinstance(v, dict):
                pm[id(v)] = n
                stack.append(v)
            elif isinstance(v, list):
                for x in v:
                    if isinstance(x, dict):
                        pm[id(x)] = n
                        stack.append(x)
    _PARENT_CACHE.clear()
    _PARENT_CACHE[id(root)] = (root, pm)
    return pm


def ancestors(node, pm):
    n = pm.get(id(node))
    while n is not None:
        yield n
        n = pm.get(id(n))


def is_fn(n):
    return n.get("type") == "AstExprFunction"


def cmp_const(expr, opkey):
    """(op, constant) when `expr` is `opvar <cmp> number` (either order), else None."""
    if expr.get("type") != "AstExprBinary" or expr.get("op") not in CMP:
        return None
    l, r = expr["left"], expr["right"]
    lk, rk = _opmatch(l, opkey), _opmatch(r, opkey)
    if lk and r.get("type") == "AstExprConstantNumber":
        return expr["op"], r["value"]
    if rk and l.get("type") == "AstExprConstantNumber":
        return FLIP[expr["op"]], l["value"]
    return None


def _opmatch(e, opkey):
    if e.get("type") != "AstExprLocal":
        return False
    lc = e["local"]
    return lc["name"] == opkey or lc["location"] == opkey


# ---------------------------------------------------------------------------
# predicate evaluation / tree resolution (v15 direct trees AND 15.1 predicate trees)
# ---------------------------------------------------------------------------

def eval_pred(expr, opkey, value, env):
    """Three-valued evaluation of a dispatch condition for a concrete opcode.
    True/False, or None when `expr` is not a pure function of the opcode
    (then the block is a handler, not a dispatch node).  `env` maps the
    declaration location of predicate locals to their (known) boolean."""
    t = expr.get("type")
    if t == "AstExprGroup":
        return eval_pred(expr["expr"], opkey, value, env)
    if t == "AstExprConstantBool":
        return bool(expr["value"])
    if t == "AstExprLocal":
        return env.get(expr["local"]["location"])
    if t == "AstExprUnary" and expr.get("op") == "Not":
        r = eval_pred(expr["expr"], opkey, value, env)
        return None if r is None else (not r)
    if t == "AstExprBinary":
        op = expr.get("op")
        if op in CMP:
            cc = cmp_const(expr, opkey)
            if cc is None:
                return None
            return OPS[cc[0]](value, cc[1])
        if op in ("And", "Or"):
            a = eval_pred(expr["left"], opkey, value, env)
            b = eval_pred(expr["right"], opkey, value, env)
            if op == "And":
                if a is False or b is False:
                    return False
                return None if a is None or b is None else True
            if a is True or b is True:
                return True
            return None if a is None or b is None else False
    return None


def _is_pred_expr(expr, opkey, preds):
    """Syntactic version of eval_pred: is `expr` built only from opcode
    comparisons, known predicate locals, not/and/or?"""
    t = expr.get("type")
    if t == "AstExprGroup":
        return _is_pred_expr(expr["expr"], opkey, preds)
    if t == "AstExprConstantBool":
        return True
    if t == "AstExprLocal":
        return expr["local"]["location"] in preds
    if t == "AstExprUnary" and expr.get("op") == "Not":
        return _is_pred_expr(expr["expr"], opkey, preds)
    if t == "AstExprBinary":
        if expr["op"] in CMP:
            return cmp_const(expr, opkey) is not None
        if expr["op"] in ("And", "Or"):
            return _is_pred_expr(expr["left"], opkey, preds) and _is_pred_expr(expr["right"], opkey, preds)
    return False


def _split_tree(stmts, opkey):
    """stmts = [pred locals..., AstStatIf, trailing...] -> (preds, if_index) or None.
    preds: {decl location: value expr} of leading `local p = <pure opcode predicate>`."""
    preds = {}
    for i, st in enumerate(stmts):
        if st["type"] == "AstStatLocal" and len(st["vars"]) == 1 and len(st["values"]) == 1 \
                and _is_pred_expr(st["values"][0], opkey, preds):
            preds[st["vars"][0]["location"]] = st["values"][0]
            continue
        if st["type"] == "AstStatIf" and _is_pred_expr(st["condition"], opkey, preds):
            return preds, i
        return None
    return None


def _descend(stmts, opkey, value, env):
    """One level: follow a dispatch node inside `stmts`.  Returns
    ('leaf', None) | ('node', stmts_of_branch | None-for-missing-else)."""
    sp = _split_tree(stmts, opkey)
    if sp is None:
        return "leaf", None
    preds, i = sp
    if i != len(stmts) - 1:                 # statements after the if: it is a handler
        return "leaf", None
    env = dict(env)
    for st in stmts[:i]:
        env[st["vars"][0]["location"]] = eval_pred(st["values"][0], opkey, value, env)
    ifs = stmts[i]
    r = eval_pred(ifs["condition"], opkey, value, env)
    if r is None:
        return "leaf", None
    if r:
        return "node", ifs["thenbody"]
    e = ifs.get("elsebody")
    return "node", e


def resolve(tree, var, value):
    """v15-compatible: follow the dispatch tree for one opcode, return the
    handler block (AstStatBlock) or None if the opcode is absent.
    `tree` is the dispatcher's tree (AstStatIf for direct trees, or the
    synthetic block of predicate locals + if); `var` the opcode variable's
    name (or declaration location)."""
    node = tree
    env = {}
    for _ in range(MAX_PRED_DEPTH):
        if node is None:
            return None
        if node["type"] == "AstStatIf":
            stmts = [node]
        elif node["type"] == "AstStatBlock":
            stmts = node["body"]
        else:
            return node
        kind, nxt = _descend(stmts, var, value, env)
        if kind == "leaf":
            return node if node["type"] == "AstStatBlock" else None
        if nxt is None:
            return None
        # predicate locals declared in this block stay visible below
        sp = _split_tree(stmts, var)
        for st in stmts[:sp[1]]:
            env[st["vars"][0]["location"]] = eval_pred(st["values"][0], var, value, env)
        node = nxt
        if node["type"] == "AstStatIf":      # `elseif`
            continue
    raise RuntimeError("dispatch tree too deep")


# ---------------------------------------------------------------------------
# dispatcher discovery
# ---------------------------------------------------------------------------

def _first_stmt_fetch(st):
    """`local op = ARR[pc]` / `op = ARR[pc]` -> (opname, opdecl, arr, pc, arr_decl, pc_decl) or None."""
    if st["type"] not in ("AstStatLocal", "AstStatAssign") or len(st["values"]) != 1:
        return None
    if st["type"] == "AstStatLocal":
        opname, opdecl = st["vars"][0]["name"], st["vars"][0]["location"]
    else:
        v0 = st["vars"][0]
        if v0.get("type") != "AstExprLocal":
            return None
        opname, opdecl = v0["local"]["name"], v0["local"]["location"]
    v = st["values"][0]
    if v["type"] != "AstExprIndexExpr":
        return None
    if v["expr"]["type"] != "AstExprLocal" or v["index"]["type"] != "AstExprLocal":
        return None
    return (opname, opdecl, v["expr"]["local"]["name"], v["index"]["local"]["name"],
            v["expr"]["local"]["location"], v["index"]["local"]["location"])


def _make_tree(body, k_if):
    """Synthetic block for predicate-form trees (statements 1..k_if)."""
    first, last = body[1], body[k_if]
    l1, c1, _, _ = loc(first)
    _, _, l2, c2 = loc(last)
    return {"type": "AstStatBlock", "synthetic": True, "location": "%d,%d - %d,%d" % (l1, c1, l2, c2),
            "hasEnd": True, "body": body[1:k_if + 1]}


def find_dispatchers(root):
    """All dispatch loops, both families.  Entries keep the v15 keys
    (node, op, arr, pc, tree, rest) and add: opdecl, arr_decl, pc_decl,
    form ('direct'|'predicate'), preds (number of predicate locals)."""
    found = []
    for n in iter_dicts(root):
        if n.get("type") != "AstStatWhile":
            continue
        cond = n["condition"]
        if cond.get("type") != "AstExprConstantBool" or not cond.get("value"):
            continue
        body = n["body"]["body"]
        if len(body) < 2:
            continue
        fetch = _first_stmt_fetch(body[0])
        if fetch is None:
            continue
        opname, opdecl, arr, pc, arr_decl, pc_decl = fetch
        if body[1]["type"] == "AstStatIf":
            found.append({"node": n, "op": opname, "arr": arr, "pc": pc, "tree": body[1], "rest": body[2:],
                          "opdecl": opdecl, "arr_decl": arr_decl, "pc_decl": pc_decl,
                          "form": "direct", "preds": 0})
            continue
        sp = _split_tree(body[1:], opdecl)
        if sp is None:
            continue
        preds, i = sp
        k_if = i + 1
        if preds:
            found.append({"node": n, "op": opname, "arr": arr, "pc": pc, "tree": _make_tree(body, k_if),
                          "rest": body[k_if + 1:], "opdecl": opdecl, "arr_decl": arr_decl,
                          "pc_decl": pc_decl, "form": "predicate", "preds": len(preds)})
    found.sort(key=lambda d: loc(d["node"])[:2])
    return found


def opkey_of(disp):
    return disp.get("opdecl") or disp["op"]


def resolve_op(disp, value):
    return resolve(disp["tree"], opkey_of(disp), value)


def handler_map(disp, lines=None, max_op=MAX_OP):
    """{block location: {"ops": [...], "node": block}} for opcodes 0..max_op-1."""
    handlers = {}
    for op in range(max_op):
        blk = resolve_op(disp, op)
        if blk is None:
            continue
        key = blk["location"]
        handlers.setdefault(key, {"ops": [], "node": blk})["ops"].append(op)
    return handlers


def tree_leaf_count(disp):
    """Number of distinct leaf blocks reachable in the dispatch tree
    (structural; independent of the 0..255 probing).  Used by tests to prove
    that handler_map() sees every leaf."""
    leaves = set()
    opkey = opkey_of(disp)
    stack = [disp["tree"]]
    while stack:
        node = stack.pop()
        stmts = [node] if node["type"] == "AstStatIf" else node["body"]
        sp = _split_tree(stmts, opkey)
        if sp is None or sp[1] != len(stmts) - 1:
            if node["type"] == "AstStatBlock":
                leaves.add(node["location"])
            continue
        ifs = stmts[sp[1]]
        stack.append(ifs["thenbody"])
        if ifs.get("elsebody") is not None:
            stack.append(ifs["elsebody"])
    return len(leaves)


# ---------------------------------------------------------------------------
# mode selection + maker/proto structure
# ---------------------------------------------------------------------------

class Origin:
    """Resolves a local's declaration back to a parameter of a function by
    following positional aliases `local a,b = x,y`."""

    def __init__(self, fn):
        self.fn = fn
        self.params = {a["location"]: i for i, a in enumerate(fn["args"])}
        self.alias = {}
        for n in iter_dicts(fn["body"]):
            if n.get("type") == "AstStatLocal":
                for i, v in enumerate(n["vars"]):
                    if i < len(n["values"]):
                        self.alias[v["location"]] = n["values"][i]

    def param_of(self, decl_loc, depth=0):
        if decl_loc in self.params:
            return self.params[decl_loc]
        e = self.alias.get(decl_loc)
        if e is None or depth > 32:
            return None
        e = unwrap_group(e)
        if e.get("type") == "AstExprLocal":
            return self.param_of(e["local"]["location"], depth + 1)
        return None


def _mode_test(cond, pm_block_stmts, if_index):
    """Decode `F==K`, `M` (where `M=F==K` is the latest assignment of M in the
    enclosing block) -> (mode var local, K) or None."""
    cond = unwrap_group(cond)
    if cond["type"] == "AstExprBinary" and cond["op"] == "CompareEq":
        l, r = cond["left"], cond["right"]
        if l["type"] == "AstExprLocal" and r["type"] == "AstExprConstantNumber":
            return l["local"], r["value"]
        if r["type"] == "AstExprLocal" and l["type"] == "AstExprConstantNumber":
            return r["local"], l["value"]
        return None
    if cond["type"] == "AstExprLocal" and pm_block_stmts is not None:
        want = cond["local"]["location"]
        for st in reversed(pm_block_stmts[:if_index]):
            if st["type"] == "AstStatAssign":
                for v, e in zip(st["vars"], st["values"]):
                    if v["type"] == "AstExprLocal" and v["local"]["location"] == want:
                        return _mode_test(e, None, 0)
            elif st["type"] == "AstStatLocal":
                for v, e in zip(st["vars"], st["values"]):
                    if v["location"] == want:
                        return _mode_test(e, None, 0)
    return None


def loop_mode(disp, pm):
    """Mode selector of one dispatch loop: {'var': name, 'decl': loc, 'value': K,
    'if': node} or None (loop runs unconditionally)."""
    w = disp["node"]
    blk = pm.get(id(w))                      # AstStatBlock holding the while
    if blk is None or blk.get("type") != "AstStatBlock":
        return None
    ifs = pm.get(id(blk))
    if ifs is None or ifs.get("type") != "AstStatIf" or ifs["thenbody"] is not blk:
        return None
    outer = pm.get(id(ifs))
    stmts = outer["body"] if outer is not None and outer.get("type") == "AstStatBlock" else None
    idx = next((i for i, s in enumerate(stmts) if s is ifs), 0) if stmts else 0
    mt = _mode_test(ifs["condition"], stmts, idx)
    if mt is None:
        return None
    var, k = mt
    return {"var": var["name"], "decl": var["location"], "value": k, "if": ifs}


def _enclosing_functions(node, pm):
    return [a for a in ancestors(node, pm) if is_fn(a)]


def _vararg_noarg(f):
    return bool(f.get("vararg")) and not f["args"]


def vm_layout(disp, pm):
    """(maker, vm, inner) of one dispatch loop or None.
    inner  innermost vararg/no-arg function around the loop (the pcall'd body)
    vm     the VM closure: the nearest vararg/no-arg function around `inner`
           when inner is a pcall'd callback, else `inner` itself
    maker  outermost function with >= 2 parameters"""
    fns = _enclosing_functions(disp["node"], pm)
    inner = next((f for f in fns if _vararg_noarg(f)), None)
    if inner is None:
        return None
    beyond = fns[fns.index(inner) + 1:]
    vm = next((f for f in beyond if _vararg_noarg(f)), None)
    # the callback is the first argument of a call inside vm; otherwise inner is the VM closure
    if vm is not None:
        p = pm.get(id(inner))
        if not (p is not None and p.get("type") == "AstExprCall"):
            vm = None
    if vm is None:
        vm = inner
    big = [f for f in fns if len(f["args"]) >= 2]
    if not big:
        return None
    return big[-1], vm, inner


def _closure_site(vm, pm):
    """How the VM closure is produced: ('local_function', stmt, var) |
    ('return_function', stmt, None) | ('assign', stmt, var) | (None, ...)"""
    p = pm.get(id(vm))
    while p is not None and p.get("type") == "AstExprGroup":
        vm, p = p, pm.get(id(p))
    if p is None:
        return None, None, None
    t = p.get("type")
    if t == "AstStatLocalFunction":
        return "local_function", p, p["name"]["name"]
    if t == "AstStatReturn":
        return "return_function", p, None
    if t == "AstStatAssign":
        for v, e in zip(p["vars"], p["values"]):
            if unwrap_group(e) is vm and v.get("type") == "AstExprLocal":
                return "assign", p, v["local"]["name"]
    if t == "AstStatLocal":
        for v, e in zip(p["vars"], p["values"]):
            if unwrap_group(e) is vm:
                return "local", p, v["name"]
    return None, p, None


def _refs_to(fn_node, locs):
    """Declaration locations (subset of `locs`) referenced anywhere in fn_node."""
    used = set()
    for n in iter_dicts(fn_node):
        if n.get("type") == "AstExprLocal":
            k = n["local"]["location"]
            if k in locs:
                used.add(k)
    return used


def _indexed_bases(fn_node, locs):
    """Declarations among `locs` that are used as the base of an index expression."""
    used = set()
    for n in iter_dicts(fn_node):
        if n.get("type") in ("AstExprIndexExpr", "AstExprIndexName"):
            e = n["expr"]
            if e.get("type") == "AstExprLocal" and e["local"]["location"] in locs:
                used.add(e["local"]["location"])
    return used


def maker_info(root, disp=None):
    """One record per VM maker (v15.1 layouts).  Keys follow the v15 record
    (at, var, proto, proto_index, upvals_index, pf_key, maker, vm, stmt, captures)
    plus: family, kind, inner, dispatchers, modes, proto_params, array_params,
    mode_param, pc_param, op_array_param, captured_params."""
    pm = parent_map(root)
    if disp is None:
        disp = find_dispatchers(root)
    makers = {}
    for d in disp:
        lay = vm_layout(d, pm)
        if lay is None:
            continue
        maker, vm, inner = lay
        rec = makers.get(id(maker))
        if rec is None:
            rec = makers[id(maker)] = {"maker": maker, "vm": vm, "inner": inner, "dispatchers": [], "origin": Origin(maker)}
        rec["dispatchers"].append(d)
        d["layout"] = lay
    out = []
    for rec in makers.values():
        maker, vm, inner = rec["maker"], rec["vm"], rec["inner"]
        args = maker["args"]
        origin = rec["origin"]
        locs = {a["location"]: i for i, a in enumerate(args)}
        kind, stmt, var = _closure_site(vm, pm)
        # operand arrays: params used as ARR[pc] by any dispatcher or indexed by a pc local
        arr_params = {}
        for d in rec["dispatchers"]:
            for ad in (d["arr_decl"],):
                pi = origin.param_of(ad)
                if pi is not None:
                    arr_params[pi] = True
        op_param = origin.param_of(rec["dispatchers"][0]["arr_decl"])
        pcs = {d["pc_decl"] for d in rec["dispatchers"]}
        for n in iter_dicts(vm):
            if n.get("type") == "AstExprIndexExpr" and n["expr"].get("type") == "AstExprLocal" \
                    and n["index"].get("type") == "AstExprLocal" and n["index"]["local"]["location"] in pcs:
                pi = origin.param_of(n["expr"]["local"]["location"])
                if pi is not None:
                    arr_params[pi] = True
        used = _refs_to(vm, locs)
        indexed = _indexed_bases(vm, locs)
        captured = sorted(locs[k] for k in used)
        tableish = sorted(set(locs[k] for k in indexed) | set(arr_params))
        modes, mode_param = [], None
        for d in rec["dispatchers"]:
            lm = loop_mode(d, pm)
            d["mode"] = lm
            if lm is not None:
                modes.append(lm["value"])
                mp = origin.param_of(lm["decl"])
                if mp is not None:
                    mode_param = mp
        # SAMPLE-SPECIFIC HEURISTIC avoided: pc start param = first param aliased by a pc variable
        pc_param = None
        for d in rec["dispatchers"]:
            pc_param = origin.param_of(d["pc_decl"])
            if pc_param is not None:
                break
        legacy_init = None
        families = {d["form"] for d in rec["dispatchers"]}
        # keep the maker's proto identity = the opcode array
        proto_index = op_param if op_param is not None else 1
        upvals_index = next((i for i in captured if i not in (0, proto_index)), proto_index + 1)
        l1, c1, l2, c2 = loc(stmt if stmt is not None else vm)
        at = (l2, c2) if stmt is not None else (l1, c1)
        names = {}
        for i, a in enumerate(args):
            names[a["name"]] = i                    # last duplicate wins = the visible one
        info = {
            "at": at, "var": var, "proto": args[proto_index]["name"], "proto_index": proto_index,
            "upvals_index": upvals_index, "pf_key": args[proto_index]["name"],
            "maker": maker, "vm": vm, "stmt": stmt, "inner": inner, "kind": kind,
            "family": "predicate" if "predicate" in families else "direct",
            "dispatchers": rec["dispatchers"], "modes": sorted(set(modes)),
            "mode_param": mode_param, "pc_param": pc_param, "op_array_param": op_param,
            "array_params": sorted(arr_params), "tableish_params": tableish,
            "captured_params": captured, "visible": {i for i in names.values()},
            "captures": [],
        }
        out.append(info)
    out.sort(key=lambda r: loc(r["maker"])[:2])
    return out


def closure_entries(root, makers=None):
    """(line, col of the first statement of the protected body, proto key expr) per VM body."""
    out, seen = [], set()
    for mk in (makers if makers is not None else maker_info(root)):
        inner = mk["inner"]
        l1, c1, _, _ = loc(inner["body"]["body"][0])
        if (l1, c1) in seen:
            continue
        seen.add((l1, c1))
        out.append((l1, c1, "__k"))
    return out


# ---------------------------------------------------------------------------
# backend detection (prompt API: detect_v151_backend / mode / mapper)
# ---------------------------------------------------------------------------

class Backend:
    """One (maker, mode) pair: a dispatcher together with the mode that selects it."""

    def __init__(self, maker, disp, mode):
        self.maker = maker
        self.dispatcher = disp
        self.mode = mode["value"] if mode else None
        self.mode_info = mode
        self.family = disp["form"]               # 'direct' (v15 shape) | 'predicate' (15.1)

    def describe(self):
        d = self.dispatcher
        return "mode=%s family=%s op=%s arr=%s pc=%s form=%s handlers=%d at %s" % (
            self.mode, self.family, d["op"], d["arr"], d["pc"], d["form"], len(handler_map(d)),
            d["node"]["location"])


class Backends(list):
    @property
    def modes(self):
        return sorted({b.mode for b in self if b.mode is not None})

    def by_mode(self, mode, family=None):
        for b in self:
            if b.mode == mode and (family is None or b.family == family):
                return b
        return None


def detect_v151_backend(root, makers=None):
    """List of Backend, one per dispatch loop.  `.modes` are the mode constants
    (SAMPLE: legacy 73/97/239/…, new 40/142/217/118)."""
    out = Backends()
    for mk in (makers if makers is not None else maker_info(root)):
        for d in mk["dispatchers"]:
            out.append(Backend(mk, d, d.get("mode")))
    return out


# ---------------------------------------------------------------------------
# hook edits for the dynamic harness
# ---------------------------------------------------------------------------

def _prologue_code(mk, tag, l, c):
    """Maker prologue: one proto table per opcode array, P[i] = value of maker
    parameter i (arrays AND scalars: mode, start pc, register count ...), and
    the v15-style capture record (`__PA[P]`) keyed by the same table."""
    args = mk["maker"]["args"]
    visible = {}
    for i, a in enumerate(args):
        visible[a["name"]] = i
    names = [(i, args[i]["name"]) for i in mk["captured_params"] if visible.get(args[i]["name"]) == i]
    key = args[mk["op_array_param"]]["name"] if mk["op_array_param"] is not None else "nil"
    ptab = ",".join("[%d]=%s" % (i, nm) for i, nm in names if i != 0)
    cap = "".join("__c.%s=%s " % (nm, nm) for _, nm in names)
    return (" local __k=__P151[%s] if not __k then __k={%s} __P151[%s]=__k end "
            "if __PA and not __PA[__k] then __PA[__k]={} __PA.n=__PA.n+1 local __c=__PA[__k] "
            "__c.__seq=__PA.n __c.__maker=\"%s@%d,%d\" __c.P=__k %s end "
            % (key, ptab, key, tag, l, c, cap))


def _field(i, name):
    """Dump field name for maker parameter i: the parameter's own name (v15 keeps names)."""
    return name


def patch_entries(source, path, tag, root=None):
    """Instrumented copy of `source` (same single-line layout rules as v15's patchEntries)."""
    if root is None:
        root = load_ast(path)
    makers = maker_info(root)
    lines = source.split("\n")
    edits = []                                   # (line, col, delete_len, text)
    seen_entry = set()
    for mk in makers:
        body0 = mk["maker"]["body"]["body"][0]
        bl, bc, _, _ = loc(body0)
        l, c = mk["at"]
        edits.append((bl, bc, 0, _prologue_code(mk, tag, l, c)))
        kind, stmt = mk["kind"], mk["stmt"]
        if stmt is not None:
            sl1, sc1, sl2, sc2 = loc(stmt)
            if kind == "local_function":
                edits.append((sl2, sc2, 0, " __PF[%s]=__k " % mk["var"]))
            elif kind == "return_function":
                edits.append((sl1, sc1, 6, "local __cl="))
                edits.append((sl2, sc2, 0, " __PF[__cl]=__k return __cl "))
            elif kind in ("assign", "local"):
                edits.append((sl2, sc2, 0, " __PF[%s]=__k " % mk["var"]))
        # closure factory: what the maker returns (`return function(q,G)` /
        # `return Q`); a parent calls it as `w[i](upvals,nil,nil)` to get the VM closure
        last = mk["maker"]["body"]["body"][-1]
        if last.get("type") == "AstStatReturn" and len(last["list"]) == 1:
            rl1, rc1, rl2, rc2 = loc(last)
            edits.append((rl1, rc1, 6, "local __f="))
            edits.append((rl2, rc2, 0, " __PQ[__f]=__k return __f "))
        l1, c1, _, _ = loc(mk["inner"]["body"]["body"][0])
        if (l1, c1) not in seen_entry:
            seen_entry.add((l1, c1))
            k = "__k"
            edits.append((l1, c1, 0,
                          "if not __PID[{k}] then __PID.n=__PID.n+1;__PID[{k}]=__PID.n;end;"
                          "__ENT.n=__ENT.n+1;__ENT[__ENT.n%64]=__PID[{k}];__PLAST[__PID[{k}]]=__ENT.n;"
                          "if __VT then __VT.n=__VT.n+1;__VT[__VT.n]=-__PID[{k}] end;"
                          "if __SKIPP[__PID[{k}]] then return end;".format(k=k)))
    edits.sort(key=lambda e: (e[0], e[1]), reverse=True)
    for l, c, dl, text in edits:
        lines[l] = lines[l][:c] + text + lines[l][c + dl:]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# instrumentation helpers kept for API parity with luraph_v15.vmmap
# ---------------------------------------------------------------------------

def instrument(src, disp_index, probes, root=None, tmp_path=None):
    lines = src.split("\n")
    if root is None:
        root = load_ast(tmp_path)
    d = find_dispatchers(root)[disp_index - 1]
    inserts = []
    for op, code in probes.items():
        blk = resolve_op(d, op)
        if blk is None:
            continue
        l1, c1, _, _ = loc(blk)
        inserts.append((l1, c1, code))
    for l1, c1, code in sorted(inserts, reverse=True):
        s = lines[l1]
        lines[l1] = s[:c1] + " " + code + " " + s[c1:]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CLI / debug
# ---------------------------------------------------------------------------

def summary(root, lines=None, out=sys.stderr, prefix="[V15.1] "):
    """Short human report (used by --debug-v151)."""
    makers = maker_info(root)
    backs = detect_v151_backend(root, makers)
    print("%sdispatchers: %d (direct=%d predicate=%d)" % (
        prefix, len(backs), sum(b.family == "direct" for b in backs),
        sum(b.family == "predicate" for b in backs)), file=out)
    print("%sbackend modes: %s" % (prefix, backs.modes), file=out)
    for mk in makers:
        print("%smaker at %s: params=%d kind=%s op_array=%s mode_param=%s pc_param=%s modes=%s" % (
            prefix, mk["maker"]["location"], len(mk["maker"]["args"]), mk["kind"],
            mk["maker"]["args"][mk["op_array_param"]]["name"] if mk["op_array_param"] is not None else None,
            mk["mode_param"], mk["pc_param"], mk["modes"]), file=out)
    for b in backs:
        print("%sdispatcher: %s" % (prefix, b.describe()), file=out)
    return makers, backs


def main(argv):
    if len(argv) < 2:
        print("usage: vmmap.py FILE [--patch TAG | --json | --handlers I OP...]")
        return 2
    path = argv[1]
    root = load_ast(path)
    with open(path, encoding="latin-1") as f:
        src = f.read()
    lines = src.split("\n")
    if len(argv) >= 4 and argv[2] == "--patch":
        sys.stdout.buffer.write(patch_entries(src, path, argv[3], root).encode("latin-1"))
        return 0
    if len(argv) >= 3 and argv[2] == "--json":
        makers = maker_info(root)
        print(json.dumps([{"maker": loc(m["maker"]), "kind": m["kind"], "modes": m["modes"],
                           "family": m["family"], "params": len(m["maker"]["args"])} for m in makers]))
        return 0
    if len(argv) >= 5 and argv[2] == "--handlers":
        d = find_dispatchers(root)[int(argv[3]) - 1]
        for op in [int(x) for x in argv[4:]]:
            blk = resolve_op(d, op)
            print("---- op %d" % op)
            print(text_of(lines, blk) if blk else "<none>")
        return 0
    summary(root, lines, out=sys.stdout, prefix="")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

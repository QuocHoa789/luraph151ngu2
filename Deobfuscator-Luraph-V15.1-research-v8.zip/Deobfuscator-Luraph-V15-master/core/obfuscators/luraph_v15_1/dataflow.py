"""Constant data-flow helpers for the v15.1 lifter (round 2, phase 3).

Everything here is *evaluation of values the program itself computes from
known constants*; nothing is guessed:

  * `PURE`            builtins whose result depends only on their arguments
  * `fold_call`       a materialized call of one of them whose arguments are all
                      constant facts -> its result values
  * `eval_int`        an IR expression made of registers / integer constants,
                      evaluated under the facts -> int, or None (never coerced)
  * `Pending`         a decode-key value that still names registers; it is
                      resolved against the facts of the instruction that wrote it

Types are kept exact: a bytes/float/bool/nil value is never turned into an
integer, `eval_int` answers None for it.
"""

PURE_PREFIXES = ("bit32.", "math.")
PURE_EXCLUDE = {"math.random", "math.randomseed", "bit32.btest_"}


def pure_name(name):
    return isinstance(name, str) and name.startswith(PURE_PREFIXES) and name not in PURE_EXCLUDE


def is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


KEY_REG_BASE = 950000      # virtual registers holding decode-key locals (outside any real register range)


class Pending:
    """A key local's value that is an expression over registers (e.g. `R1`).  The value
    was copied into the virtual register `kreg` by the step that wrote it."""
    __slots__ = ("expr", "text", "kreg")

    def __init__(self, expr, text, kreg):
        self.expr, self.text, self.kreg = expr, text, kreg

    def __eq__(self, o):
        return isinstance(o, Pending) and (o.text, o.kreg) == (self.text, self.kreg)

    def __hash__(self):
        return hash(("pending", self.text, self.kreg))

    def __repr__(self):
        return "<pending %s -> k%s>" % (self.text, self.kreg)


class SymKey:
    """A key local whose integer value is not statically known: it is carried as the
    virtual register `kreg` (reading it as a value is exact; using it as a decode key
    fails the step, it is never guessed)."""
    __slots__ = ("kreg",)

    def __init__(self, kreg):
        self.kreg = kreg

    def __eq__(self, o):
        return isinstance(o, SymKey) and o.kreg == self.kreg

    def __hash__(self):
        return hash(("symkey", self.kreg))

    def __repr__(self):
        return "<symbolic key k%s>" % self.kreg


def eval_const(e, facts, E):
    """Value of `e` under `facts` as ('c', value) / None.  Registers, constants only."""
    if isinstance(e, E.Const):
        return ("c", e.v)
    if isinstance(e, E.Reg):
        f = facts.get(e.n)
        return f if f is not None and f[0] == "c" else None
    return None


def eval_int(e, facts, E):
    c = eval_const(e, facts, E)
    if c is not None and is_int(c[1]):
        return c[1]
    return None


def fold_call(fn_fact, args, facts, E):
    """Results of `fn(args...)` when `fn` is a pure builtin (fact ("t", Global)) and
    every argument is a constant fact; else None."""
    if not fn_fact or fn_fact[0] != "t" or len(fn_fact) < 2 or not isinstance(fn_fact[1], E.Global):
        return None
    name = fn_fact[1].name
    if not pure_name(name):
        return None
    fn = E.S.CONCRETE.get(name)
    if fn is None:
        return None
    vals = []
    for a in args:
        c = eval_const(a, facts, E)
        if c is None:
            return None
        vals.append(c[1])
    try:
        r = fn(*vals)
    except Exception:
        return None
    if isinstance(r, (tuple, list)):
        return tuple(r)
    return (r,)


def written_regs(node):
    """Registers assigned anywhere in an instruction's IR tree."""
    out = set()
    stack = [node]
    from ir import Assign
    while stack:
        n = stack.pop()
        if n is None:
            continue
        for st in n.stmts:
            if isinstance(st, Assign) and hasattr(st.target, "n"):
                out.add(st.target.n)
        stack.append(getattr(n, "then", None))
        stack.append(getattr(n, "els", None))
    return out

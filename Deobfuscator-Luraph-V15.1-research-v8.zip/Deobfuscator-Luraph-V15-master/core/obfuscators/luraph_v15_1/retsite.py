"""Return-site abstraction for outlined helpers that return through a jump register.

THE FAILURE (verified on the sample, see V15.1-PHASE6.md)
    Luraph v15.1 outlines code shared by many places into subroutines.  A caller stores
    its continuation pc in a register (r62), jumps to the helper, and the helper ends in
    `pc = r62`.  The v15 walk tracks the constant value of every "jump register" and puts
    it into the state key (`State.jregs`), so the helper body is stepped once per distinct
    return address: 820 states for the 10-instruction helper at 239:13794, ~8 200 of the
    first 15 000 states, and a CFG with >20 000 blocks that cannot be lowered.

THE ABSTRACTION (context-insensitive body + runtime dispatch)
    * A *link register* is a jump register whose consumer is exactly `pc = Reg(r) [+ c]`.
    * When a call-like transfer (a non-sequential jump) leaves a constant K in a link
      register, the value is replaced in the state by a `LinkTok(reg, mode, entry_pc)`
      and K is recorded in the helper's *return table* `T[tok]`.  The helper body is
      therefore keyed by its entry, not by its caller.
    * Reading the register inside the body yields the real `Reg(r)` (the assignment is
      emitted, `st.jump` is cleared), so data uses stay exact.
    * When the body ends in `pc = Reg(r) + c`, the leaf becomes a dispatch
      `if r == K1 then goto K1+c elseif r == K2 ...`, one branch per recorded return site;
      distinct continuations stay distinct states.  The last branch is the default: the
      table is complete for every call the walk reached (an unreached caller would be an
      unlifted block anyway).
    * A site registered after the dispatch was built rebuilds it and re-queues the node.

No sample address or register number appears in this module.
"""

import os

from luasym import Reg, Const, Bin, Un
from obfuscators.luraph_v15_1 import helpersum as HS

# Context-sensitivity bound.  A helper entered from at most MIN_SITES distinct return addresses keeps the
# engine's exact behaviour (one body state per return address: strictly more precise, and the one the
# key-carrying / expansion machinery was validated with).  Only a helper that exceeds the bound switches to
# the entry-keyed abstraction below, i.e. the abstraction is applied where cloning would explode, not
# everywhere.  See V15.1-PHASE6.md ("why a bound": proto 11 loses decode-key locals without it).
MIN_SITES = int(os.environ.get("DEVIRT_V151_RETSITE_MIN", "12") or 0)
# entry-context-keyed tokens (phase 7); "0" restores the v6 behaviour (one table per (reg, mode, entry)) for ablation
RETCTX = os.environ.get("DEVIRT_V151_RETCTX", "1") not in ("0", "")

# Deferred register discovery.  The v15 walk restarts from scratch the moment it meets a symbolic pc whose
# register it does not track yet; on a program with dozens of such registers (the outlined-helper return
# registers of the sample) every restart repeats the whole prefix of the walk and learns ONE register.
# With deferral the register is only recorded; the walk goes on (that node stays an honest error node) and
# is restarted once, after DEFER_SLACK more states or at its end, with every register found meanwhile.
DEFER_ON = os.environ.get("DEVIRT_V151_DEFER", "1") not in ("0", "")
DEFER_SLACK = int(os.environ.get("DEVIRT_V151_DEFER_SLACK", "1500") or 1500)


def defer_regs(lf, regs, n_order):
    """-> True when the discovery was deferred (the caller keeps walking), False for the engine's restart."""
    if not DEFER_ON or not getattr(lf.vm, "v151", False):
        return False
    d = getattr(lf, "v151_deferred", None)
    if d is None:
        d = lf.v151_deferred = set()
    if not d:
        lf.v151_defer_at = n_order
    d.update(regs)
    lf.v151_defer_total = getattr(lf, "v151_defer_total", 0) + 1
    return True


def defer_packs(lf, bad, n_order):
    """Same deferral for the engine's `pack-unstable` restarts (one more unstable pack register per restart)."""
    if not DEFER_ON or not getattr(lf.vm, "v151", False):
        return False
    if not getattr(lf, "v151_deferred", None) and not getattr(lf, "v151_deferred_packs", None):
        lf.v151_defer_at = n_order
    p = getattr(lf, "v151_deferred_packs", None)
    if p is None:
        p = lf.v151_deferred_packs = set()
    p.update(bad)
    lf.v151_defer_total = getattr(lf, "v151_defer_total", 0) + 1
    return True


def has_deferred(lf):
    return bool(getattr(lf, "v151_deferred", None) or getattr(lf, "v151_deferred_packs", None))


def defer_due(lf, n_order):
    d = has_deferred(lf)
    if not d:
        return False
    first = getattr(lf, "v151_defer_at", n_order)
    return n_order - first >= max(DEFER_SLACK, first // 4)


def take_deferred(lf):
    """Move the deferred registers into the tracked set; -> the set (empty if nothing was deferred)."""
    d = getattr(lf, "v151_deferred", None) or set()
    pk = getattr(lf, "v151_deferred_packs", None) or set()
    lf.v151_deferred = set()
    lf.v151_deferred_packs = set()
    lf.jump_regs |= d
    if pk:
        lf.pack_unstable |= pk
    return d | pk


class LinkTok(object):
    """Abstract value of a link register inside a helper body: 'the return address the
    caller of the helper that starts at (mode, entry) stored'.

    `ctx` identifies the NON-link part of the state the helper was entered with (kstack depth, overlay,
    packs, carried locals, decode keys, non-link jump registers, outer tokens).  The return table of a
    token only holds the sites of callers that entered with that same context, so a continuation is
    never built from helper-exit state of one caller context and the return site of another
    (phase 7: that product was the source of infeasible states at the real sample's helper 239:13794)."""
    __slots__ = ("reg", "mode", "entry", "ctx")

    def __init__(self, reg, mode, entry, ctx=0):
        self.reg, self.mode, self.entry, self.ctx = reg, mode, entry, ctx

    def _t(self):
        return (self.reg, self.mode, self.entry, self.ctx)

    def __eq__(self, o):
        return isinstance(o, LinkTok) and self._t() == o._t()

    def __ne__(self, o):
        return not self.__eq__(o)

    def __hash__(self):
        return hash(("LinkTok",) + self._t())

    def __lt__(self, o):
        return self._t() < o._t()

    def __repr__(self):
        return "link(r%s@%s:%s%s)" % (self.reg, self.mode, self.entry, "#%d" % self.ctx if self.ctx else "")


def _int(x):
    """Plain int value of Const / int, else None."""
    if isinstance(x, Const):
        x = x.v
    if isinstance(x, bool) or not isinstance(x, int):
        return None
    return x


def affine(expr):
    """(register, offset) when expr is `Reg r`, `r + c`, `c + r` or `r - c`, else None."""
    if isinstance(expr, Reg):
        return (expr.n, 0)
    if isinstance(expr, Bin) and expr.op in ("Add", "Sub"):
        a, b = expr.a, expr.b
        if isinstance(a, Reg) and _int(b) is not None:
            return (a.n, _int(b) if expr.op == "Add" else -_int(b))
        if expr.op == "Add" and isinstance(b, Reg) and _int(a) is not None:
            return (b.n, _int(a))
    return None


class RetSites(object):
    """Return tables and the nodes whose ending is a dispatch over them (one per walk)."""

    def __init__(self):
        self.tables = {}          # LinkTok -> set(K)
        self.nodes = {}           # LinkTok -> {state key: (node, leaf, offset, template state)}
        self.dirty = set()        # tokens whose table grew since their return nodes were last queued
        self.ver = {}             # LinkTok -> table version (bumped by every new return site)
        self.seen_ctx = {}        # (mode, entry) -> distinct tuples of live link-register constants seen before the bound
        self.seen_k = {}          # (reg, mode, entry) -> (constant, context id) seen before the bound was crossed
        self.ctx_ids = {}         # non-link entry context -> small id (insertion order: deterministic)
        self.active = set()       # (mode, entry) helpers that crossed the bound (abstracted from then on)
        self.calls = 0            # call-like transfers tokenised
        self.iterations = 0       # nodes processed by the walk (new states + re-propagations)
        self.requeues = 0         # return nodes re-queued because their helper's table grew
        self.rebuilds = 0
        self.facts = {}           # (mode, pc) -> observed read/write behaviour of the steps there (helpersum)
        self.entries_seen = set() # (mode, pc) entered by a call-like transfer that left a constant in a link register
        self.summaries = {}       # entry -> helper summary (helpersum.try_summarize)
        self.rejected = {}        # entry -> why it has no summary
        self.sum_hits = 0         # calls replaced by the summarised continuation
        self.sum_misses = 0       # calls into an entry that had no summary yet (exact clone / token path)
        self.sum_unusable = 0     # summary present but the link was not a constant
        self.sum_sig_miss = 0     # summary present but the helper cells are in a decode it was not observed on (one-shot self-modification pending)
        self.sum_apps = {}        # caller state key -> {(mode, entry, exit pc)}

    def register(self, tok, K):
        t = self.tables.setdefault(tok, set())
        if K in t:
            return False
        t.add(K)
        self.ver[tok] = self.ver.get(tok, 0) + 1
        if tok in self.nodes:
            self.dirty.add(tok)
        return True


def of(lf):
    rs = getattr(lf, "retsites", None)
    if rs is None:
        rs = lf.retsites = RetSites()
    return rs


def reset(lf):
    lf.retsites = RetSites()
    lf.link_new = {}
    lf.v151_deferred = set()
    lf.v151_deferred_packs = set()
    return lf.retsites


# ---------------------------------------------------------------------------------------
# step side: assignments and state creation
# ---------------------------------------------------------------------------------------

def note_assign(lf, st, Assign):
    """Called after the engine emitted `st`.  Assignments to a link register must reach the
    output (they feed the return dispatch) and a constant is remembered for tokenising."""
    links = getattr(lf, "link_regs", None)
    if not links or not (isinstance(st, Assign) and isinstance(st.target, Reg)) or st.target.n not in links:
        return
    st.jump = False
    new = getattr(lf, "link_new", None)
    if new is None:
        new = lf.link_new = {}
    v = _int(st.value)
    if v is not None:
        new[st.target.n] = v
    else:
        new.pop(st.target.n, None)


def finish_state(lf, state, ns):
    """Turn the link-register constants of the successor state `ns` into tokens when the step
    was a call-like transfer; keep tokens that a read would have dropped.  -> State."""
    links = getattr(lf, "link_regs", None)
    if not links:
        return ns
    jr = dict(ns.jregs)
    changed = False
    for r, v in getattr(lf, "jvals", {}).items():                   # tokens survive reads
        if isinstance(v, LinkTok) and r not in jr:
            jr[r] = v
            changed = True
    concrete = isinstance(ns.pc, int) and isinstance(ns.mode, int)
    sequential = state is not None and ns.pc == state.pc + 1 and ns.mode == state.mode
    if concrete and not sequential:
        rs = of(lf)
        ints = [(r, jr.get(r)) for r in sorted(links) if type(jr.get(r)) is int and jr.get(r) != ns.pc]
        cid = 0
        if ints:
            ent = (ns.mode, ns.pc)
            rs.entries_seen.add(ent)
            if HS.ON and ent in rs.summaries and HS.apply(lf, rs, state, ns, ent, jr, getattr(lf.vm, "kstack_link", None)):
                return ns
            rs.sum_misses += 1
            # entry context = everything of the entered state except the constants being tokenised here
            kk = ns.key(getattr(lf.vm, "kstack_link", None))
            raw = (kk[2],) + tuple(kk[4:]) + (tuple((r, v) for r, v in sorted(jr.items(), key=lambda kv: kv[0])
                                                    if r not in links or isinstance(v, LinkTok)),
                                              getattr(lf, "v151_frame", ()))
            cid = rs.ctx_ids.setdefault(raw, len(rs.ctx_ids)) if RETCTX else 0
            if ent not in rs.active:
                # context-sensitivity bound PER ENTRY (not per register): the contexts are the whole tuple of live
                # link-register constants, whose number is the PRODUCT over registers (outer helpers' pending return
                # addresses stay live across an inner call) -- 61 jump-register sets for one 10-instruction helper
                ctxs = rs.seen_ctx.setdefault(ent, set())
                ctxs.add(tuple(ints))
                for r, K in ints:
                    rs.seen_k.setdefault((r,) + ent, set()).add((K, cid))
                if len(ctxs) <= MIN_SITES:
                    ints = []                                    # below the bound: exact clones, as the engine does
                else:
                    rs.active.add(ent)
                    for (r, mode_, pc_), ks in list(rs.seen_k.items()):
                        if (mode_, pc_) == ent:                  # bound crossed: earlier sites join the tables
                            for K0, c0 in sorted(ks):
                                rs.register(LinkTok(r, mode_, pc_, c0), K0)
            for r, K in ints:
                tok = LinkTok(r, ns.mode, ns.pc, cid)
                rs.register(tok, K)
                rs.calls += 1
                jr[r] = tok
                changed = True
    if not changed:
        return ns
    ns.jregs = tuple(sorted(jr.items(), key=lambda kv: kv[0]))
    return ns


def read_value(lf, k, value):
    """`index()` hook: a token is read as the real register."""
    return Reg(k) if isinstance(value, LinkTok) else value


# ---------------------------------------------------------------------------------------
# walk side: successors of a return step
# ---------------------------------------------------------------------------------------

def _find_leaf(node, ns):
    stack = [node]
    while stack:
        n = stack.pop()
        if n is None:
            continue
        oc = getattr(n, "outcome", None)
        if oc is not None and getattr(oc, "state", None) is ns:
            return n
        stack.append(n.then)
        stack.append(n.els)
    return None


def _clone(ns, pc, drop):
    jr = tuple((k, v) for k, v in ns.jregs if k != drop)
    kw = {}
    if hasattr(ns, "keys"):
        return type(ns)(ns.mode, pc, ns.kstack, jr, ns.ov, ns.packs, ns.locs, ns.keys, getattr(ns, "kvals", ()))
    return type(ns)(ns.mode, pc, ns.kstack, jr, ns.ov, ns.packs, ns.locs)


def build_dispatch(leaf, reg, off, ns, tok, table, Node, Next):
    """Rewrite `leaf` (a Node ending in Next(symbolic)) into the dispatch over `table`."""
    ks = sorted(table)
    leaf.outcome = None
    leaf.cond = leaf.then = leaf.els = None
    conts = [(K, Next(_clone(ns, K + off, reg))) for K in ks]
    if len(conts) == 1:
        leaf.outcome = conts[0][1]
        return
    cur = Node([], outcome=conts[-1][1])
    for K, oc in reversed(conts[:-1]):
        cur = Node([], cond=Bin("CompareEq", Reg(reg), Const(K)), then=Node([], outcome=oc), els=cur)
    leaf.cond, leaf.then, leaf.els = cur.cond, cur.then, cur.els


def successors(prog, lf, k, node, succ, facts, work, inwork, nodes, states, propagate, Node, Next):
    """Called by the walk for every stepped node (`succ` = its propagated successors).
    -> successors to use.  Discovers link registers, turns return steps into dispatches and
    re-queues earlier return nodes whose table grew.

    Cost: a new return site only marks the helper's return nodes stale and queues them behind the
    frontier; a stale node is rebuilt once, when it is processed (not once per registration), so
    hundreds of sites cost one rebuild per return node and per drain of the queue, not one per site."""
    rs = of(lf)
    rs.iterations += 1
    redo = False
    if rs.dirty:
        for tok in sorted(rs.dirty):
            for k2, ent in list(rs.nodes.get(tok, {}).items()):
                n2 = ent[0]
                if k2 not in nodes or n2 is not nodes.get(k2):
                    del rs.nodes[tok][k2]
                    continue
                if k2 != k and k2 in states and k2 not in inwork:
                    work.insert(0, k2)             # behind the frontier: many new sites -> one re-propagation
                    inwork.add(k2)
                    rs.requeues += 1
        rs.dirty.clear()
    for tok in sorted(rs.nodes):                    # stale dispatch of THIS node: rebuild now
        ent = rs.nodes[tok].get(k)
        if ent is not None and ent[0] is node and ent[4] != rs.ver.get(tok, 0):
            _n, leaf2, off2, ns2, _v = ent
            build_dispatch(leaf2, tok.reg, off2, ns2, tok, rs.tables[tok], Node, Next)
            rs.nodes[tok][k] = (node, leaf2, off2, ns2, rs.ver.get(tok, 0))
            rs.rebuilds += 1
            redo = True
    links = getattr(lf, "link_regs", None)
    if links is None:
        links = lf.link_regs = set()
    for ns, _nf in succ:
        if isinstance(ns.pc, int) and isinstance(ns.mode, int):
            continue
        if not isinstance(ns.mode, int):
            continue
        a = affine(ns.pc)
        if a is None:
            continue
        reg, off = a
        tok = next((v for r, v in ns.jregs if r == reg and isinstance(v, LinkTok)), None)
        if tok is None:
            if reg not in links:
                links.add(reg)                                   # discovery: restart with it tracked
                if not defer_regs(lf, {reg}, len(nodes)):
                    lf.jump_regs.discard(reg)                    # engine restart (deferral off)
            continue
        leaf = _find_leaf(node, ns)
        if leaf is None:
            continue
        table = rs.tables.get(tok)
        if not table:
            continue
        build_dispatch(leaf, reg, off, ns, tok, table, Node, Next)
        rs.nodes.setdefault(tok, {})[k] = (node, leaf, off, ns, rs.ver.get(tok, 0))
        if "symbolic next pc" in str(getattr(node, "error", "") or ""):
            node.error = None
        redo = True
    if not redo:
        return succ
    out = []
    propagate(node, dict(facts[k]), out, lf)
    return out


# ---------------------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------------------

def report(lf):
    rs = getattr(lf, "retsites", None)
    if rs is None:
        return None
    return {"link_registers": sorted(getattr(lf, "link_regs", ()) or ()), "site_bound": MIN_SITES,
            "helpers_below_bound": sum(1 for h in rs.seen_ctx if h not in rs.active),
            "max_contexts_below_bound": max([len(v) for h, v in rs.seen_ctx.items() if h not in rs.active] or [0]),
            "call_transfers": rs.calls, "dispatch_rebuilds": rs.rebuilds,
            "worklist_iterations": rs.iterations, "requeues": rs.requeues,
            "abstracted_entries": len(rs.active), "entry_contexts": len(rs.ctx_ids), "return_sites_total": sum(len(t) for t in rs.tables.values()),
            "deferred_discoveries": getattr(lf, "v151_defer_total", 0),
            "summaries": [{"entry": "%s:%s" % e, "exit_pc": v["exit_pc"], "link_register": v["reg"], "offset": v["off"],
                           "chain": len(v["chain"]), "observed_steps": v["observed_steps"]} for e, v in sorted(rs.summaries.items())],
            "summary_hits": rs.sum_hits, "summary_misses": rs.sum_misses, "summary_unusable_link": rs.sum_unusable, "summary_cell_signature_misses": rs.sum_sig_miss,
            "summary_hit_rate": (rs.sum_hits / float(rs.sum_hits + rs.sum_misses)) if (rs.sum_hits + rs.sum_misses) else None,
            "summary_rejected": {"%s:%s" % e: why for e, why in sorted(rs.rejected.items())},
            "helpers": [{"link_register": t.reg, "mode": t.mode, "entry_pc": t.entry, "entry_context": t.ctx,
                         "return_sites": sorted(rs.tables[t]),
                         "return_nodes": len(rs.nodes.get(t, {}))} for t in sorted(rs.tables)]}

"""Observation hooks that feed ``diagnostics.Diag`` from the private v15.1
engine copy (installed by ``engine_patch.install``).  They only *observe*:
no hook changes a value the engine computes, a branch it takes or an
exception it raises.
"""
import os

from obfuscators.luraph_v15_1 import diagnostics as DG

E = None            # the engine copy (set by install)
DIAG = None
_STACK = None
_MAPPERS = None
_SEM = None
_ORACLE = None
MAX_CHAIN = 4000
ENABLED = os.environ.get("DEVIRT_NO_DIAG", "") in ("", "0")


def install(engine, diag, stack, mappers, sem=None, oracle=None):
    global E, DIAG, _STACK, _MAPPERS, _SEM, _ORACLE
    E, DIAG, _STACK, _MAPPERS, _SEM, _ORACLE = engine, diag, stack, mappers, sem, oracle
    if not ENABLED:
        return

    # -- provenance of every write into the proto's instruction arrays ----------
    orig_write_ov = E.ProtoLifter.write_ov

    def write_ov(self, key, v, base):
        try:
            nm = arr_names(self).get(key[0])
            if nm is not None and isinstance(key[1], int):
                op = self.last_op[1] if getattr(self, "last_op", None) else None
                DIAG.note_write(pkey(self), nm, key[1], v, base, op)
        except Exception:                                   # diagnostics never break the lift
            pass
        return orig_write_ov(self, key, v, base)

    E.ProtoLifter.write_ov = write_ov

    # -- register facts of the nodes worth explaining -----------------------------
    orig_prop = E.propagate

    def propagate(node, facts, succ, lf):
        try:
            if not getattr(node, "_dg", False):
                node._dg = True
                if getattr(node, "error", None) or any(isinstance(s, E.CallStmt) for s in node.stmts):
                    c = DIAG.cur
                    if c is not None:
                        DIAG.facts[(c[0], c[1], c[2])] = {("r%s" % r): _fact(f) for r, f in list(facts.items())[:48]}
        except Exception as ex:
            DIAG.last_error = "propagate hook: %s: %s" % (type(ex).__name__, ex)
        return orig_prop(node, facts, succ, lf)

    E.propagate = propagate


def _scan_nil(node, facts):
    """[(index, stmt, callee reg or None, facts at the call)] of every call in the
    instruction's IR whose callee is nil: the literal nil, or a register whose
    constant fact is nil (the code generator then prints `(nil)(...)`)."""
    out, idx = [], 0
    stack = [(node, dict(facts))]
    while stack:
        n, f = stack.pop()
        if n is None:
            continue
        for st in n.stmts:
            if isinstance(st, E.CallStmt):
                fe = E.eval_fact(st.fn, f) if not is_nil(st.fn) else ("c", None)
                if fe is not None and fe[0] == "c" and fe[1] is None:
                    out.append((idx, st, st.fn.n if type(st.fn).__name__ == "Reg" else None, dict(f)))
                    idx += 1
            E.apply_stmt_facts(st, f, _NullLF)
        stack.append((n.then, dict(f)))
        stack.append((n.els, dict(f)))
    return out


class _NullLF:
    """apply_stmt_facts only consults captured_regs / frame calls of the lifter."""
    captured_regs = ()


def _fact(f):
    s = repr(f)
    return s if len(s) <= 60 else s[:59] + "…"


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def pkey(lf):
    """Key of the proto in the harness dump ("11"), or t<tid>."""
    dump = lf.dump
    m = getattr(dump, "_v151_t2k", None)
    if m is None:
        m = {}
        for key, cap in dump.protos.items():
            p = cap.get("P") if isinstance(cap, dict) else None
            p = p if p is not None else (cap.get("self") if isinstance(cap, dict) else None)
            tid = getattr(p, "tid", None)
            if tid is not None:
                m[tid] = key
        dump._v151_t2k = m
    tid = getattr(lf.proto, "tid", None)
    return m.get(tid, "t%s" % tid)


def arr_names(lf):
    m = getattr(lf, "_dg_names", None)
    if m is None:
        m = {id(v): str(k) for k, v in lf.proto.h.items() if isinstance(v, E.LTable)}
        lf._dg_names = m
    return m


def is_nil(e):
    return e is None or (type(e).__name__ == "Const" and e.v is None)


def nil_calls_in(node):
    out, stack = [], [node]
    while stack:
        n = stack.pop()
        if n is None:
            continue
        for st in n.stmts:
            if isinstance(st, E.CallStmt) and is_nil(st.fn):
                out.append(st)
        stack.append(n.then)
        stack.append(n.els)
    return out


def operands_at(lf, pc):
    """{array: {raw, current, writer}} for every instruction/operand array at pc."""
    out = {}
    ov = lf.cur_ov()
    pk = pkey(lf)
    for name, arr in arr_names_items(lf):
        raw = arr.get(pc)
        cur = ov.get((id(arr), pc), raw) if ov is not None else raw
        w = DIAG.writers_at(pk, pc).get(name)
        if raw is None and cur is None and w is None:
            out[name] = {"raw": "nil", "current": "nil", "empty_at_pc": True}
            continue
        d = {"raw": DG.show(raw), "current": DG.show(cur), "type": DG.type_of(cur)}
        if w:
            d["writer"] = w["writer"]
        out[name] = d
    return out


def arr_names_items(lf):
    names = arr_names(lf)
    return [(names[id(v)], v) for v in lf.proto.h.values() if isinstance(v, E.LTable) and id(v) in names]


def handler_info(mode, opcode):
    mp = _MAPPERS().get(mode)
    spec = mp.get(opcode) if mp is not None and opcode is not None else None
    if spec is None:
        return {"loc": None, "kind": "UNKNOWN", "semantic": None, "confidence": 0.0}
    loc = spec.block.get("location") if isinstance(spec.block, dict) else None
    sem = _SEM(mode, opcode) if _SEM else None
    return {"loc": loc, "kind": spec.kind, "pc_effect": spec.pc_effect, "semantic": sem, "confidence": spec.confidence}


def real_trace(pk, mode, pc, opcode):
    """Ground truth from the real run's execution trace (see trace_oracle)."""
    try:
        o = _ORACLE() if _ORACLE else None
        if not o:
            return {"verdict": "NO_TRACE"}
        v, extra = o.verdict(mode, pc, opcode, pk)
        out = {"verdict": v, "proto_ran_in_real_run": o.ran(pk)}
        out.update({k: {str(a): b for a, b in x.items()} for k, x in extra.items()})
        return out
    except Exception as ex:
        return {"verdict": "NO_TRACE", "error": str(ex)}


def code_len(lf):
    for nm in ("A", "_"):
        arr = lf.proto.h.get(nm)
        if isinstance(arr, E.LTable):
            return arr.length()
    return 0


# ---------------------------------------------------------------------------
# step-level hooks (called by V151Stepper)
# ---------------------------------------------------------------------------

def on_step_start(lf, state):
    if not ENABLED:
        return
    DIAG.set_cur(pkey(lf), state.mode, state.pc, " > ".join(_STACK))


def on_step_ok(lf, state, node):
    if not ENABLED:
        return
    try:
        if any(isinstance(s, E.CallStmt) for s in node.stmts) or node.then is not None or node.els is not None:
            node._dg_ops = operands_at(lf, state.pc)
    except Exception:
        pass


def on_step_error(lf, state, msg, op):
    if not ENABLED:
        return
    """The step raised Unsupported: make the unlifted-block record (links to
    predecessors / successors are added after the walk)."""
    mode, opcode = (op if op else (state.mode, None))
    pk = pkey(lf)
    reason = DG.reason_of(msg)
    ops = {}
    try:
        ops = operands_at(lf, state.pc)
    except Exception:
        pass
    writers = {n: o["writer"] for n, o in ops.items() if "writer" in o}
    cls, evidence = DG.class_of(reason, msg, state.pc, code_len(lf), "; ".join(
        "%s@%s:%s" % (n, w["mode"], w["pc"]) for n, w in sorted(writers.items())))
    h = handler_info(mode, opcode)
    kind = h.get("kind")
    rec = {"proto": pk, "closure": " > ".join(_STACK), "mode": state.mode, "pc": state.pc, "opcode": opcode,
           "opcode_mode": mode, "handler": h, "reason": reason, "block_class": cls, "class_evidence": evidence,
           "message": msg, "operands": ops, "predecessors": [], "successors": [], "registers": {},
           "reachable_from_entry": True, "reachability_basis": "stepped by the conditional-constant walk from the proto entry",
           "affects": {"call": kind == "CALL", "return": kind == "RETURN", "closure": kind == "CLOSURE",
                       "jump": kind in ("JUMP", "COND_JUMP", "MODE_SWITCH"), "materialization": kind in ("EXPAND", "BLOB_DECRYPT")},
           "closure_ref": None,
           "upvalues": {"count": len(getattr(getattr(lf, "upvals", None), "items", []) or []) if hasattr(lf, "upvals") else None},
           "materialization": {"writers_at_pc": {n: w for n, w in DIAG.writers_at(pk, state.pc).items()}}}
    DIAG.add_unlifted(rec)


# ---------------------------------------------------------------------------
# post-walk: predecessors / successors / nil calls
# ---------------------------------------------------------------------------

def after_walk(prog, lf, order, restart=False):
    if not ENABLED:
        return
    """Fill the links of the records of this walk and collect its nil calls."""
    try:
        pk = pkey(lf)
        closure = " > ".join(_STACK)
        by_key = {k: n for k, n in order}
        edges = getattr(prog, "edges", {}) or {}
        pred = getattr(prog, "pred", {}) or {}
        rev = {}
        for k, succs in edges.items():
            for nk in succs:
                rev.setdefault(nk, []).append(k)
        DIAG.walks += 1
        if not restart:
            from obfuscators.luraph_v15_1 import conformance as _CF
            from obfuscators.luraph_v15_1 import semantics as _SM
            DIAG.add_walk(_CF.record_walk(pk, closure, order, edges, getattr(getattr(lf, 'retsites', None), 'sum_apps', None)), closure)
            for _k, _n in order:
                _op = getattr(_n, "op", None)
                if _op:
                    _SM.COLLECTOR.observe(_op[0], _op[1], _n, E)
        for k, node in order:
            err = getattr(node, "error", None)
            mode, pc = k[0], k[1]
            if err:
                rec = DIAG.unlifted.get((pk, mode, pc))
                if rec is None:                      # error set by the walk itself (restart / symbolic pc / stack depth)
                    reason = DG.reason_of(err)
                    cls, ev = DG.class_of(reason, err, pc, code_len(lf), "")
                    op = getattr(node, "op", None)
                    rec = {"proto": pk, "closure": closure, "mode": mode, "pc": pc,
                           "opcode": op[1] if op else None, "opcode_mode": op[0] if op else mode,
                           "handler": handler_info(*(op if op else (mode, None))), "reason": reason, "block_class": cls,
                           "class_evidence": ev, "message": err, "operands": {}, "predecessors": [], "successors": [],
                           "registers": {}, "reachable_from_entry": True,
                           "reachability_basis": "stepped by the conditional-constant walk from the proto entry",
                           "affects": {}, "closure_ref": None, "upvalues": {}, "materialization": {}}
                    DIAG.add_unlifted(rec)
                rec["closure"] = closure
                rec["predecessors"] = _chain(k, pred, by_key, rev)
                rec["successors"] = [{"mode": s[0], "pc": s[1]} for s in sorted(edges.get(k, ()), key=lambda x: (x[0], x[1]))][:8]
                rec["successor_candidates"] = {"fallthrough_pc": pc + 1 if isinstance(pc, int) else None}
                rec["registers"] = DIAG.facts.get((pk, mode, pc), rec.get("registers", {}))
                rt = real_trace(pk, mode, pc, rec.get("opcode"))
                rec["real_trace"] = rt
                if rt["verdict"] == "DIFFERENT_OP":
                    rec["block_class"] = "DYNAMIC_MATERIALIZATION"
                    rec["class_evidence"] = "the real run executed this pc with opcode %s, the lifter decoded %s (decode divergence)" % (
                        sorted(rt.get("real_ops", {})), rec.get("opcode"))
                elif rt["verdict"] == "NOT_REACHED" and rt.get("proto_ran_in_real_run"):
                    rec["block_class"] = "JUNK_UNREACHABLE"
                    rec["class_evidence"] = "the proto ran in the real run but never executed this (mode, pc): a path the lifter walked and the VM does not take"
            _scan_calls(lf, pk, closure, k, node, pred, by_key)
    except Exception as ex:                                       # diagnostics only
        DIAG.overflow = True
        DIAG.last_error = "%s: %s" % (type(ex).__name__, ex)


def _chain(k, pred, by_key, rev, n=6):
    out, cur, seen = [], k, set()
    while len(out) < n:
        p = pred.get(cur)
        if p is None or p in seen:
            break
        seen.add(p)
        node = by_key.get(p)
        op = getattr(node, "op", None) if node is not None else None
        out.append({"mode": p[0], "pc": p[1], "opcode": op[1] if op else None})
        cur = p
    return out


def _nil_value(v):
    return v is None or (type(v).__name__ == "Const" and v.v is None)


def _calls_in(node):
    """[(stmt, preceding statements of its own node)] for every call of the instruction's IR tree."""
    out, stack = [], [node]
    while stack:
        n = stack.pop()
        if n is None:
            continue
        for i, st in enumerate(n.stmts):
            if isinstance(st, E.CallStmt):
                out.append((st, n.stmts[:i]))
        stack.append(n.then)
        stack.append(n.els)
    return out


def _last_assign(stmts, reg_n):
    found = None
    for st in stmts:
        if isinstance(st, E.Assign) and type(st.target).__name__ == "Reg" and st.target.n == reg_n:
            found = st
    return found


def _reaching_def(k, reg_n, before, pred, by_key):
    """(statement, key, hops) of the nearest earlier assignment of register
    `reg_n`: first inside the call's own instruction, then up the first-discovered
    predecessor path.  None when the path never writes it."""
    w = _last_assign(before, reg_n)
    if w is not None:
        return w, k, 0
    cur, hops, seen = pred.get(k), 1, set()
    while cur is not None and hops <= MAX_CHAIN and cur not in seen:
        seen.add(cur)
        nd = by_key.get(cur)
        if nd is not None:
            stack = [nd]
            last = None
            while stack:
                n = stack.pop()
                if n is None:
                    continue
                last = _last_assign(n.stmts, reg_n) or last
                stack.append(n.then)
                stack.append(n.els)
            if last is not None:
                return last, cur, hops
        cur, hops = pred.get(cur), hops + 1
    return None, None, hops


def _scan_calls(lf, pk, closure, k, node, pred, by_key):
    for idx, (st, before) in enumerate(_calls_in(node)):
        fn = st.fn
        if _nil_value(fn):
            _record_nil_call(lf, pk, closure, k, node, st, idx, pred, by_key, None, None, None, "literal nil callee")
        elif type(fn).__name__ == "Reg":
            w, wk, hops = _reaching_def(k, fn.n, before, pred, by_key)
            if w is not None and _nil_value(w.value):
                _record_nil_call(lf, pk, closure, k, node, st, idx, pred, by_key, fn.n, w, wk,
                                 "register r%d was assigned nil" % fn.n)
            elif w is None and fn.n >= 0:
                _record_nil_call(lf, pk, closure, k, node, st, idx, pred, by_key, fn.n, None, None,
                                 "register r%d is not written on the first-discovered path to the call (%d hops)" % (fn.n, hops),
                                 uninitialized=True)


def _record_nil_call(lf, pk, closure, k, node, st, idx, pred, by_key, callee_reg, writer, writer_key, why,
                     uninitialized=False):
    mode, pc = k[0], k[1]
    ops = getattr(node, "_dg_ops", None) or {}
    args = [E.fmt_any(a) for a in (st.args.items if hasattr(st.args, "items") else [])][:8]
    op = getattr(node, "op", None)
    empty = sorted(n for n, o in ops.items() if o.get("empty_at_pc"))
    wr = None
    if writer is not None:
        wop = getattr(by_key.get(writer_key), "op", None) if writer_key is not None else None
        wr = {"mode": writer_key[0], "pc": writer_key[1], "opcode": wop[1] if wop else None,
              "value": E.fmt_any(writer.value), "value_type": DG.type_of(None)}
        wops = getattr(by_key.get(writer_key), "_dg_ops", None) or {}
        wr["empty_operand_arrays_at_writer"] = sorted(n for n, o in wops.items() if o.get("empty_at_pc"))
    if writer is not None:
        source = "register"
        cause = "callee r%s assigned nil by op %s:%s at pc %s" % (callee_reg, writer_key[0], wr["opcode"], writer_key[1])
        if wr["empty_operand_arrays_at_writer"]:
            cause += " (loaded from empty operand array(s) %s)" % ",".join(wr["empty_operand_arrays_at_writer"])
            source = "constant"
    elif uninitialized:
        source, cause = "register", "callee r%s never written on the path" % callee_reg
    else:
        source, cause = "unknown", why
    rec = {"proto": pk, "closure": closure, "mode": mode, "pc": pc, "index": idx,
           "opcode": op[1] if op else None, "handler": handler_info(*(op if op else (mode, None))),
           "callee": "nil" if callee_reg is None else "r%s" % callee_reg, "callee_register": callee_reg,
           "args": args, "operands": ops, "last_writer": wr, "uninitialized_register": uninitialized,
           "predecessor": ({"mode": pred[k][0], "pc": pred[k][1]} if k in pred else None),
           "real_trace": real_trace(pk, mode, pc, op[1] if op else None),
           "empty_operand_arrays": empty, "why": why, "root_cause": cause, "kind": DG.nil_kind(source, None),
           "register_state": DIAG.facts.get((pk, mode, pc), {})}
    DIAG.add_nil_call(rec)


def on_expansion(lf, state, ov):
    if not ENABLED:
        return
    """An in-place decode-and-re-execute event (called before the Expander bounds are applied)."""
    try:
        names = arr_names(lf)
        fields = {names[k[0]]: DG.show(v) for k, v in ov.items()
                  if isinstance(k, tuple) and len(k) == 2 and k[1] == state.pc and k[0] in names}
        op = lf.last_op
        DIAG.add_expansion(pkey(lf), state.mode, state.pc, {"mode": op[0], "opcode": op[1]} if op else None,
                           op[1] if op else None, fields)
    except Exception:
        pass

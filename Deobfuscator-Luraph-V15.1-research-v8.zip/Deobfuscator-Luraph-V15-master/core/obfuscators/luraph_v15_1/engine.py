"""Private copy of the shared symbolic engine, bound to the v15.1 mapper.

`luraph_v15/devirt.py` is executed a second time into its own module object
(`obfuscators.luraph_v15_1._engine`) with exactly one source substitution
(its `vmmap` import) and one inserted call (`_unwrap_factory`, see PATCHES).
The v15 module itself is never touched, so v15 behaviour is byte-for-byte what
it was; v15.1 gets its own class objects that this file then specialises:

    V151VMModel   proto = table of maker parameters (P[i] = param i), VM
                  closure produced by `local function g` / `return function`
    V151Stepper   mode selection `if F==K` / `M=F==K` / `i,E=U,c`
    ProtoLifter   closure *factory* unwrapping (maker -> factory -> VM closure)
"""
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
CORE = os.path.dirname(os.path.dirname(HERE))
V15_DEVIRT = os.path.join(CORE, "obfuscators", "luraph_v15", "devirt.py")
NAME = "obfuscators.luraph_v15_1._engine"

# (needle, replacement): every needle must occur exactly once in the v15 source.
PATCHES = [
    ("from obfuscators.luraph_v15 import vmmap",
     "from obfuscators.luraph_v15_1 import vmmap"),
    ('        if not isinstance(f, LuaFunc) or f.node is not vm.vm:\n'
     '            raise Unsupported("closure maker did not return the VM closure")',
     '        f = self._unwrap_factory(it, f, vm, upvals)\n'
     '        if not isinstance(f, LuaFunc) or f.node is not vm.vm:\n'
     '            raise Unsupported("closure maker did not return the VM closure")'),
    # the plateau stop (25000 states without a new pc) is a v15 tuning constant; v15.1 programs
    # clone shared subroutines per call site (jump-register sets), so it is configurable here
    ("if plateau >= 25000:", "if plateau >= _env_int(\"DEVIRT_PLATEAU\", 25000):"),
    # return-site abstraction (retsite.py): the successors of a return step through a link register
    # are a dispatch over the helper's recorded return sites instead of one clone per return address
    ("                for ns, nf in succ:\n                    if not isinstance(ns.pc, int) or not isinstance(ns.mode, int):\n",
     "                for ns, nf in _v151_successors(self, lf, k, node, succ, facts, work, inwork, nodes, states):\n"
     "                    if not isinstance(ns.pc, int) or not isinstance(ns.mode, int):\n"),
    # deferred register discovery (retsite.defer_regs): record the register, keep the node an error node and
    # restart once, instead of restarting the whole walk for every register
    ("                        if regs:\n\n                            lf.jump_regs |= regs\n                            return restart_exit(\"jump-regs\")\n",
     "                        if regs:\n"
     "                            if _v151_defer_regs(lf, regs, len(order)):\n"
     "                                node.error = \"symbolic next pc/mode: %s / %s\" % (fmt_any(ns.pc), fmt_any(ns.mode))\n"
     "                                continue\n"
     "                            lf.jump_regs |= regs\n"
     "                            return restart_exit(\"jump-regs\")\n"),
    ("                    if getattr(st, \"new_carry\", False):\n",
     "                    if _v151_defer_due(lf, len(order)):\n"
     "                        _v151_take_deferred(lf)\n"
     "                        return restart_exit(\"jump-regs\")\n"
     "                    if getattr(st, \"new_carry\", False):\n"),
    ("                        if bad - lf.pack_unstable:\n                            lf.pack_unstable |= bad\n                            return restart_exit(\"pack-unstable\")\n",
     "                        if bad - lf.pack_unstable:\n"
     "                            if not _v151_defer_packs(lf, bad - lf.pack_unstable, len(order)):\n"
     "                                lf.pack_unstable |= bad\n"
     "                                return restart_exit(\"pack-unstable\")\n"),
    # an unpack of the register file whose range is larger than any frame the VM can hold is an
    # infeasible decode (an operand of another record used as an argument count): report it as an
    # unsupported (= unresolved) node instead of materialising millions of Reg objects
    # overlay content hash (state identity): a symbolic value written into an instruction array is identified by its
    # STRUCTURE, not by the id() of the object that happens to carry it (two paths storing the same register expression
    # into the same cell are the same state; with id() a loop that re-stores it never reaches a repeated state)
    ("        return v\n    return id(v)\n",
     "        return v\n    if isinstance(v, Expr):\n        return (\"expr\", fmt_expr(v))\n    return id(v)\n"),
    # worklist order (engine_patch._v151_pick): LIFO is the v15 depth-first order; a depth-first walk spends its whole budget
    # inside the first lineage it enters (including a garbage one) while the sibling branch of the real lineage waits
    ("                else:\n                    k = work.pop()\n                inwork.discard(k)\n",
     "                else:\n                    k = _v151_pick(work, st)\n                inwork.discard(k)\n"),
    ("            return Multi([FrameArg(n) if self.jvals.get(n) is FRAME else Reg(n) for n in range(i, j + 1)])\n",
     "            _v151_unpack_guard(self, i, j)\n"
     "            return Multi([FrameArg(n) if self.jvals.get(n) is FRAME else Reg(n) for n in range(i, j + 1)])\n"),
]


def _source():
    with open(V15_DEVIRT, encoding="utf-8") as f:
        src = f.read()
    for needle, repl in PATCHES:
        if src.count(needle) != 1:
            raise RuntimeError("v15 devirt.py changed: patch point not found exactly once: %r" % needle[:60])
        src = src.replace(needle, repl)
    return src


def load():
    mod = sys.modules.get(NAME)
    if mod is not None:
        return mod
    mod = types.ModuleType(NAME)
    mod.__file__ = V15_DEVIRT
    sys.modules[NAME] = mod
    try:
        exec(compile(_source(), V15_DEVIRT, "exec"), mod.__dict__)
        from obfuscators.luraph_v15_1 import engine_patch
        engine_patch.install(mod)
    except BaseException:
        sys.modules.pop(NAME, None)
        raise
    return mod

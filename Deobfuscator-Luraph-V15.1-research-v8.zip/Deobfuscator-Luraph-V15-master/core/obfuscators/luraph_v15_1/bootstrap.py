"""Bootstrap locator for Luraph v15.1 (Phase 4a).

A v15.1 script is ``return <VM table>:ZV()(...)`` where the VM table is one
very large constructor holding

    * the *bootstrap state machine*: step methods (``WV YV pV sV MV ...``) that
      ``ZV`` drives; they read the encoded blob (a printable-ASCII string
      starting with ``LPH$``) with a base-85 style decoder, rebuild the
      instruction arrays / constant offsets, and create the byte buffer
      (``[28]=buffer.fromstring``) the VM later reads;
    * numeric slots ``[53]=buffer.readu8`` ... (the helpers the handlers call
      through ``Y[53]``);
    * the string patterns the decoder uses (``gV="[ v-~]"``).

This module only *locates* those pieces (AST facts, no execution) and reports
what it found with a confidence.  The stream itself is decoded by running the
script's own bootstrap (the dynamic harness) - see ``stream_decoder.py`` for
why a static re-implementation is not attempted for the bootstrap and what is
implemented statically.
"""
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

from obfuscators.luraph_v15_1 import vmmap as VM          # noqa: E402

KEY_CONSTANTS = (54337324, 16843009, 536870911)           # SAMPLE-SPECIFIC HEURISTIC: constants seen in decrypt handlers
BLOB_PREFIX = "LPH"


def _dotted(n):
    """`buffer.readu8` / `bit32.bxor` / `next` for a global or index chain, else None."""
    t = n.get("type")
    if t == "AstExprGlobal":
        return n["global"]
    if t == "AstExprIndexName":
        b = _dotted(n["expr"])
        return None if b is None else "%s.%s" % (b, n["index"])
    return None


def vm_table(root):
    """The VM table constructor: the largest table constructor of the script."""
    best = None
    for n in VM.iter_dicts(root):
        if n.get("type") == "AstExprTable" and (best is None or len(n["items"]) > len(best["items"])):
            best = n
    return best


def entry_method(root):
    """Name of the method the script invokes on the VM table (`:ZV()`), or None."""
    if not root["body"]:
        return None
    last = root["body"][-1]
    if last.get("type") != "AstStatReturn" or not last["list"]:
        return None
    n = last["list"][0]
    while n is not None and n.get("type") == "AstExprCall":
        f = n["func"]
        if f.get("type") == "AstExprIndexName":
            return f["index"]
        n = f if f.get("type") == "AstExprCall" else None
    return None


def blob(root):
    """(length, location, prefix) of the encoded stream: the longest string constant."""
    best = None
    for n in VM.iter_dicts(root):
        if n.get("type") == "AstExprConstantString" and (best is None or len(n["value"]) > len(best["value"])):
            best = n
    if best is None:
        return None
    v = best["value"]
    return {"length": len(v), "location": best["location"], "prefix": v[:4],
            "looks_like_luraph": v.startswith(BLOB_PREFIX), "charset": _charset(v)}


def _charset(s, limit=200000):
    s = s[:limit]
    return {"min": min(s) if s else None, "max": max(s) if s else None, "distinct": len(set(s))}


def patterns(root):
    """String constants shaped like Lua patterns / character classes (decoder alphabets)."""
    out = []
    for n in VM.iter_dicts(root):
        if n.get("type") == "AstExprConstantString":
            v = n["value"]
            if 2 <= len(v) <= 60 and ("[" in v and "]" in v) and any(c in v for c in "%-^"):
                out.append((n["location"], v))
    return out


def helper_slots(table):
    """{numeric key: dotted builtin} for `[53]=buffer.readu8`-style entries."""
    out = {}
    for it in table["items"]:
        k, v = it.get("key"), it["value"]
        if it["kind"] == "general" and k and k.get("type") == "AstExprConstantNumber":
            name = _dotted(v)
            if name:
                out[int(k["value"])] = name
    return out


def step_methods(table):
    """{name: parameter count} for record entries holding functions."""
    out = {}
    for it in table["items"]:
        k, v = it.get("key"), it["value"]
        if it["kind"] == "record" and k and k.get("type") == "AstExprConstantString" and v.get("type") == "AstExprFunction":
            out[k["value"]] = len(v["args"]) + (1 if v.get("self") else 0)
    return out


def driver_loop(table, name):
    """Names of the step methods the entry function calls (`Y:WV(...)`)."""
    for it in table["items"]:
        k, v = it.get("key"), it["value"]
        if it["kind"] == "record" and k and k.get("value") == name and v.get("type") == "AstExprFunction":
            calls = []
            for n in VM.iter_dicts(v):
                if n.get("type") == "AstExprCall" and n.get("self") and n["func"].get("type") == "AstExprIndexName":
                    calls.append(n["func"]["index"])
            return sorted(set(calls))
    return []


def key_constant_sites(root):
    """{constant: [locations]} of the decrypt-key constants."""
    out = {c: [] for c in KEY_CONSTANTS}
    for n in VM.iter_dicts(root):
        if n.get("type") == "AstExprConstantNumber" and n["value"] in out:
            out[n["value"]].append(n["location"])
    return out


def analyze(root):
    """Everything this module can say about the bootstrap, with a confidence.
    Never raises on a script that does not have the v15.1 shape; returns
    ``found=False`` instead."""
    tab = vm_table(root)
    entry = entry_method(root)
    info = {"found": False, "confidence": 0.0, "notes": []}
    if tab is None or entry is None:
        info["notes"].append("no VM table / entry method")
        return info
    steps = step_methods(tab)
    drv = driver_loop(tab, entry)
    bl = blob(root)
    slots = helper_slots(tab)
    pats = patterns(root)
    sites = key_constant_sites(root)
    info.update({
        "found": True,
        "table_location": tab["location"], "table_entries": len(tab["items"]),
        "entry": entry, "entry_calls": drv,
        "step_methods": steps, "blob": bl, "patterns": pats,
        "helper_slots": slots,
        "key_constants": {str(k): len(v) for k, v in sites.items()},
    })
    score = 0.0
    score += 0.3 if entry in steps else 0.0
    score += 0.2 if len(drv) >= 4 else 0.0
    score += 0.2 if bl and bl["looks_like_luraph"] else 0.0
    score += 0.15 if "buffer.readu8" in slots.values() and "buffer.fromstring" in slots.values() else 0.0
    score += 0.15 if all(sites[c] for c in KEY_CONSTANTS) else 0.0
    info["confidence"] = round(score, 2)
    if not (bl and bl["looks_like_luraph"]):
        info["notes"].append("blob does not start with %r" % BLOB_PREFIX)
    info["notes"].append("blob decoding is performed by the script's own bootstrap (dynamic); not re-implemented")
    return info


def summary_lines(info, prefix="[V15.1] "):
    if not info.get("found"):
        return ["%sbootstrap: not found (%s)" % (prefix, "; ".join(info.get("notes", [])))]
    bl = info["blob"] or {}
    return [
        "%sbootstrap: VM table at %s (%d entries), entry method %s, %d step methods, confidence %.2f" % (
            prefix, info["table_location"], info["table_entries"], info["entry"], len(info["step_methods"]),
            info["confidence"]),
        "%sbootstrap: stream blob %s chars at %s prefix %r" % (
            prefix, bl.get("length"), bl.get("location"), bl.get("prefix")),
    ]


def main(argv):
    import json
    if len(argv) < 2:
        print("usage: bootstrap.py FILE")
        return 2
    info = analyze(VM.load_ast(argv[1]))
    print(json.dumps(info, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

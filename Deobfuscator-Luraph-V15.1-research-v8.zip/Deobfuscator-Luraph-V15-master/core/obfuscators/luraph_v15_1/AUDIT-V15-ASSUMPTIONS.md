# Audit: what the v15 lifter assumes, and the v15.1 adapter for each (round 2, phase 8)

Architecture (unchanged rule: `luraph_v15/*` is not edited):

    V15   frontend (luraph_v15/vmmap, driver) -> luraph_v15/devirt.py (engine)
    V15.1 frontend (luraph_v15_1/vmmap, opcode_maps, bootstrap, stream_decoder)
            -> engine.py: the v15 engine source executed a second time as a *private module*
               (two string patches, see PATCHES) -> engine_patch.py specialisations
            -> shared IR / codegen only where it is compatible (ir_bridge.py)
            -> gate.py / validator.py (verdict) -> output only on PASS

| # | v15 assumption (where) | Why it breaks on v15.1 | v15.1 adapter |
|---|---|---|---|
| 1 | The stepper re-runs the VM-function prologue for every instruction and carries only *stack-pointer candidate* locals (`Stepper._note_access`, `_carried`). | v15.1 in-place decoders keep a decode key in an ordinary prologue local (`J=L[R[i]]`). It silently reset to its initial value each step, so every later in-place decode used the wrong key (verified numerically: op 54 only with the carried key; the initial key decodes 84). Root cause of the unlifted blocks / type mismatches of v4. | `State151.keys`, `V151Stepper._note_access/_key_tuple/_fresh_scopes`: key locals are discovered from evidence (read-first in one step, written with a different value in another), carried separately from `State.locs` (which the v15 stack logic interprets). |
| 2 | `_AccessLog.read_first` is filled by subscript reads. | The interpreter reads locals through `Scope.get` -> `dict.get`, which bypasses it, so `read_first` stays empty (the v15 carry heuristic is effectively inert). | `_Acc151` records `.get` reads too (`reads_first`), keeps the v15 `read_first` meaning unchanged. |
| 3 | A guest-level call `R[a](R[a+1]..)` is an opaque `CallStmt`; `fact_of` knows only constants/closures. | v15.1 keys are computed by guest code (`bit32.bxor` over constants) and then fed to the decoders. | `dataflow.fold_call` + `apply_stmt_facts` extension: pure builtins (`bit32.*`, `math.*`) over constant facts are folded into facts; key values are resolved against the facts of the instruction that wrote them (`Pending` -> int or `SymKey`). |
| 4 | Path merging by `meet` of facts. | Two paths that load different constants into the key source register lose the constant at the join. | Optional path-sensitive tracked register constants (`State151.kvals`, demand driven: `DEVIRT_V151_KVALS`). Costs states; see status. |
| 5 | `State.key()` is `(mode, pc, depth, jregs, ov.h, packs, locs)`; `_walk` reads `nk[:5]`, `nk[5]`. | Extra state needs a place in the key. | `State151.key()` appends `(keys, kvals)`; indices 0-6 untouched. |
| 6 | `ProtoLifter.index` assumes the in-place override values are numbers (`S.fmt_num(cur)`). | A decode that depends on an unresolved key stores a symbolic value -> `TypeError` crashed the lift. | wrapped: `V151_SYMBOLIC_VALUE` unsupported step (a diagnosed unlifted block, never a crash). |
| 7 | The walk stops after 25000 states without a new pc ("plateau"). | v15.1 programs call shared helpers from thousands of call sites; each return address (jump register) clones the helper. | `DEVIRT_PLATEAU` (private module patch). The cloning itself is the open blocker (status). |
| 8 | Restarting the walk keeps the in-place decryption done so far. | XOR layers applied twice decrypt garbage. | round 1: `_walk` replays from the start snapshot on restart. |
| 9 | The maker's 2nd argument is the proto. | proto = table of all maker parameters; closure = maker -> factory -> VM closure. | round 1: `V151VMModel`, `closure.py`. |
| 10 | Mode switch is `if mode==K` on a variable that handlers assign. | legacy-shaped maker switches mode with `break`; predicate-form dispatchers. | round 1: `V151Stepper` loops/conds. |

Nothing above changes `luraph_v15/devirt.py`; `tests/` check the v15 regression output byte for byte.

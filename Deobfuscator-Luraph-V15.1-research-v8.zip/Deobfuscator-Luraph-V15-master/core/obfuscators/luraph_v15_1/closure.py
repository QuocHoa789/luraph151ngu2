"""Closure / proto graph for Luraph v15.1 (Phase 6).

v15.1 does not follow the v15 convention "the maker's second argument is the
proto".  A proto is the table of *all* maker parameters (``P[i] = parameter i``;
instruction arrays, operand arrays, constant tables and scalars together) and
the closure is made in two steps: ``maker(params...)`` returns a *factory*
(`function(q,G)` / `Q(x,h,h)`) and the factory, called with the upvalue list
(``w[i](W,nil,nil)``), returns the VM closure.  This module keeps the resulting
graph::

    function (VM closure)  --captures-->  upvalue list entries
    function               --proto----->  proto table (P)
    proto                  --child------>  proto (via a factory stored in `w`)

Two sources feed it:

* ``from_dump(dump)``   the factories the dynamic run made visible
                        (``pq`` entries of the dump, see envlog ``__PQ``);
* ``ClosureGraph.edge`` called by the engine while it lifts (every
                        ``ClosureExpr`` it creates), so the graph also covers
                        protos that never ran.

The graph is bounded (``MAX_NODES``) and cycle-aware (a proto that is its own
ancestor is a recursion, flagged, never followed twice).
"""
import json
import os

MAX_NODES = int(os.environ.get("DEVIRT_MAX_CLOSURE_NODES", "200000"))


class ClosureGraph:
    def __init__(self):
        self.nodes = {}             # key -> {"key", "pid", "tag", "upvals": n, "length": n}
        self.edges = []             # (parent key, child key, upvalue count)
        self._edge_set = set()
        self.overflow = False

    def node(self, key, **info):
        if key not in self.nodes:
            if len(self.nodes) >= MAX_NODES:
                self.overflow = True
                return None
            self.nodes[key] = {"key": key}
        self.nodes[key].update({k: v for k, v in info.items() if v is not None})
        return self.nodes[key]

    def edge(self, parent, child, upvals=None):
        if parent is None or child is None:
            return False
        k = (parent, child)
        if k in self._edge_set:
            return False
        if self.node(parent) is None or self.node(child) is None:
            return False
        self._edge_set.add(k)
        self.edges.append((parent, child, upvals))
        return True

    def children(self, key):
        return [c for p, c, _ in self.edges if p == key]

    def parents(self, key):
        return [p for p, c, _ in self.edges if c == key]

    def roots(self):
        has_parent = {c for _, c, _ in self.edges}
        return [k for k in self.nodes if k not in has_parent]

    def recursive(self):
        """Keys that reach themselves (a proto that creates a closure of itself)."""
        adj = {}
        for p, c, _ in self.edges:
            adj.setdefault(p, []).append(c)
        out = []
        for start in adj:
            seen, stack = set(), list(adj.get(start, ()))
            while stack:
                n = stack.pop()
                if n == start:
                    out.append(start)
                    break
                if n in seen:
                    continue
                seen.add(n)
                stack.extend(adj.get(n, ()))
        return out

    def depth(self):
        """Longest chain from a root (cycle-safe)."""
        adj = {}
        for p, c, _ in self.edges:
            adj.setdefault(p, []).append(c)
        best = 0

        def walk(k, d, path):
            nonlocal best
            best = max(best, d)
            for c in adj.get(k, ()):
                if c not in path and d < 10000:
                    walk(c, d + 1, path | {c})
        for r in self.roots():
            walk(r, 1, {r})
        return best

    def summary(self):
        return {"closures": len(self.edges), "protos": len(self.nodes), "roots": len(self.roots()),
                "recursive": len(self.recursive()), "depth": self.depth(), "overflow": self.overflow}

    def as_dict(self):
        return {"nodes": list(self.nodes.values()), "edges": [list(e) for e in self.edges], **self.summary()}


def from_dump(path_or_dict):
    """Graph of the protos and factories a harness dump shows (SAMPLE-INDEPENDENT:
    uses the `P` capture field and `pq` factory records, not parameter positions)."""
    d = path_or_dict
    if not isinstance(d, dict):
        with open(path_or_dict, encoding="utf-8") as f:
            d = json.load(f)
    g = ClosureGraph()
    tables = d["tables"]
    key_of_table = {}
    for key, cap in d["protos"].items():
        p = cap.get("P") or cap.get("self")
        tid = p["t"] if isinstance(p, dict) and "t" in p else None
        mk = cap.get("__maker")
        mk = bytes.fromhex(mk["s"]).decode("latin-1") if isinstance(mk, dict) and "s" in mk else None
        g.node(key, tid=tid, tag=mk, seq=cap.get("__seq"))
        if tid is not None:
            key_of_table[tid] = key

    def factories(v, out):
        if isinstance(v, dict):
            if "lf" in v and isinstance(v.get("pq"), dict) and "t" in v["pq"]:
                out.append(v["pq"]["t"])
            else:
                for x in v.values():
                    factories(x, out)
        elif isinstance(v, list):
            for x in v:
                factories(x, out)

    for key, cap in d["protos"].items():
        found = []
        for name, v in cap.items():
            if isinstance(v, dict) and "t" in v:
                t = tables.get(str(v["t"]))
                if t is not None and (t.get("kv") or t.get("arr")):
                    factories(t.get("kv"), found)
                    factories(t.get("arr"), found)
        for tid in found:
            child = key_of_table.get(tid)
            if child is None:
                child = "t%s" % tid
                g.node(child, tid=tid)
            g.edge(key, child)
    return g

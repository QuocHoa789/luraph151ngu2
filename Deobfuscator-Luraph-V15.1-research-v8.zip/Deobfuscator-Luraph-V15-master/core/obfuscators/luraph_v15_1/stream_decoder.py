"""Stream decoder for Luraph v15.1 (Phase 4b).

What can and cannot be done statically
--------------------------------------
The instruction stream of a v15.1 script is produced by the script's own
bootstrap (``bootstrap.py``): a printable-ASCII blob is decoded by a state
machine whose step methods are generated per script, then the instruction
arrays and the VM byte buffer are built from it.  Re-implementing that state
machine offline would be a per-sample re-implementation (it is regenerated for
every obfuscation run), so this module does **not** do that.  Instead:

* the *decoded* streams are read from the dynamic harness dump
  (``DumpStreams``): the bootstrap ran for real, the instruction arrays were
  captured when each proto was created (before any in-place decryption, see
  ``runtime/envlog.luau`` ``CFG.v151`` restore), so they are exactly the
  streams the VM starts from;
* the *in-place string/blob decryption* that the VM performs at run time
  (handler ``BLOB_DECRYPT`` in ``opcode_maps``) **is** implemented statically
  and exactly (``decrypt_blob``), verified against the real handler source
  executed by Luau in ``tests/test_v151_stream.py``.

Everything returns plain Python values; failures raise ``StreamError`` with a
reason (never a silent empty result).
"""
import json
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

OFFSET_KEY = 54337324          # SAMPLE-SPECIFIC: xor applied to a blob offset before first use
STRIDE_KEY = 16843009          # 0x01010101: per-byte repeat of the instruction's key operand


class StreamError(Exception):
    pass


# ---------------------------------------------------------------------------
# primitives (mirror the handler text exactly)
# ---------------------------------------------------------------------------

def read_varint(buf, pos):
    """Luraph's 7-bit big-endian-ish varint: returns (value, next_pos).
    Mirrors `z<128` / `(z-128)*128+A2` / ... in the BLOB_DECRYPT handler."""
    n = len(buf)

    def b(i):
        if i >= n:
            raise StreamError("varint runs past the buffer (offset %d, size %d)" % (i, n))
        return buf[i]
    z = b(pos)
    if z < 128:
        return z, pos + 1
    a = b(pos + 1)
    if a < 128:
        return (z - 128) * 128 + a, pos + 2
    r = b(pos + 2)
    if r < 128:
        return (z - 128) * 16384 + (a - 128) + r * 128, pos + 3
    w = b(pos + 3)
    return (z - 128) * 2097152 + (a - 128) * 128 + (r - 128) * 16384 + w % 128 + (w - w % 128) * 2097152, pos + 4


def decrypt_blob(buf, offsets, index, key):
    """Run the in-place decryption of one blob.

    buf      bytearray, decrypted *in place* (as the VM does)
    offsets  mutable mapping/list (1-based Lua array semantics: offsets[index])
    index    operand U (key into offsets)
    key      operand m

    The offset stored in ``offsets[index]`` is first xor-ed with OFFSET_KEY (and
    written back - which is why running the handler twice on the same slot
    reads garbage), then ``varint length`` bytes are xor-ed with ``key``: whole
    4-byte words with ``key*0x01010101`` (mod 2^32), the tail bytes with ``key``.
    Returns the decrypted bytes.
    """
    enc = offsets[index] if not isinstance(offsets, list) else offsets[index - 1]
    if enc is None:
        raise StreamError("no offset at index %r" % (index,))
    z = int(enc) ^ OFFSET_KEY
    if isinstance(offsets, list):
        offsets[index - 1] = z
    else:
        offsets[index] = z
    if z < 0 or z >= len(buf):
        raise StreamError("decrypted offset %d outside the buffer (size %d)" % (z, len(buf)))
    n, start = read_varint(buf, z + 1)          # the byte at z is skipped by the handler (`S=z+1`)
    end = start + n
    if end > len(buf):
        raise StreamError("blob [%d, %d) runs past the buffer (size %d)" % (start, end, len(buf)))
    word = (int(key) * STRIDE_KEY) & 0xFFFFFFFF
    words_end = end - n % 4
    for p in range(start, words_end, 4):
        v = int.from_bytes(buf[p:p + 4], "little") ^ word
        buf[p:p + 4] = v.to_bytes(4, "little")
    for p in range(words_end, end):
        buf[p] = (buf[p] ^ int(key)) & 0xFF
    return bytes(buf[start:end])


# ---------------------------------------------------------------------------
# dump access
# ---------------------------------------------------------------------------

def _lua_array(t):
    """list (index 0 = Lua 1) of a dumped table's array part, or None."""
    if not isinstance(t, dict):
        return None
    return t.get("arr")


class DecodedProto:
    __slots__ = ("pid", "seq", "maker", "ops", "operands", "scalars", "length", "start_pc", "mode")

    def __init__(self, pid, seq, maker, ops, operands, scalars, mode, start_pc):
        self.pid, self.seq, self.maker = pid, seq, maker
        self.ops, self.operands, self.scalars = ops, operands, scalars
        self.mode, self.start_pc = mode, start_pc
        self.length = len(ops)

    def instruction(self, pc):
        """(op, {array name: value}) at 1-based pc."""
        return self.ops[pc - 1], {k: (v[pc - 1] if pc - 1 < len(v) else None) for k, v in self.operands.items()}


class DumpStreams:
    """Decoded instruction streams of every captured proto in a harness dump."""

    def __init__(self, path_or_dict, op_array="A", mode_field="c", pc_field="U"):
        if isinstance(path_or_dict, dict):
            d = path_or_dict
        else:
            with open(path_or_dict, encoding="utf-8") as f:
                d = json.load(f)
        self.raw = d
        self.tables = d["tables"]
        self.protos = []
        for key, cap in d["protos"].items():
            ops = self._arr(cap.get(op_array))
            if ops is None:
                continue
            operands, scalars = {}, {}
            for name, v in cap.items():
                if name == op_array or name.startswith("__") or name in ("self", "P"):
                    continue
                if isinstance(v, dict) and "t" in v:
                    a = self._arr(v)
                    if a and abs(len(a) - len(ops)) <= max(8, len(ops) // 50):
                        operands[name] = a
                elif isinstance(v, (int, float)) and not isinstance(v, bool):
                    scalars[name] = v
            mk = cap.get("__maker")
            mk = bytes.fromhex(mk["s"]).decode("latin-1") if isinstance(mk, dict) and "s" in mk else None
            seq = cap.get("__seq")
            self.protos.append(DecodedProto(key, seq, mk, ops, operands, scalars,
                                            scalars.get(mode_field), scalars.get(pc_field)))
        self.protos.sort(key=lambda p: (p.seq if p.seq is not None else 1 << 30))

    def _arr(self, ref):
        if not isinstance(ref, dict) or "t" not in ref:
            return None
        t = self.tables.get(str(ref["t"]))
        a = _lua_array(t)
        return a

    def __len__(self):
        return len(self.protos)

    def total_instructions(self):
        return sum(p.length for p in self.protos)

    def op_histogram(self, proto):
        h = {}
        for o in proto.ops:
            h[o] = h.get(o, 0) + 1
        return h


def main(argv):
    if len(argv) < 2:
        print("usage: stream_decoder.py DUMP.protos.json")
        return 2
    ds = DumpStreams(argv[1])
    print("protos: %d, instructions: %d" % (len(ds), ds.total_instructions()))
    for p in ds.protos[:10]:
        print(" proto %s seq=%s mode=%s start=%s len=%d arrays=%s" % (
            p.pid, p.seq, p.mode, p.start_pc, p.length, sorted(p.operands)))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

"""v15.1 -> shared IR bridge (Phase 7).

The devirtualizer's IR (``core/ir.py``) is shared with v14/v15; v15.1 adds
nothing to it except one *diagnostic* statement, ``V151_UNKNOWN``, and a
normalisation record that says, for every instruction, which PC effect the
mode's handler has (``opcode_maps``).

    NormInstr(mode, pc, opcode, kind, pc_effect, advance, operands)

``pc_effect`` is one of::

    NEXT  ADVANCE(n)  JUMP  COND_JUMP  RETURN  CALL(*)  MODE_SWITCH
    EXPAND_AND_REEXECUTE

(* CALL is a *kind*; its PC effect is NEXT.  The effect list above is the
contract of the spec: NEXT / JUMP / COND_JUMP / RETURN / CALL / ADVANCE(n) /
EXPAND_AND_REEXECUTE; MODE_SWITCH is the extra v15.1 effect for legacy-shaped
dispatchers that ``break`` into another mode.)

``V151_UNKNOWN(mode, opcode, operands)`` is what an instruction the lifter
could not translate becomes: a visible diagnostic in the output, never silently
dropped and never replaced by invented code.
"""
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

from ir import IRStmt                                            # noqa: E402

PC_EFFECTS = ("NEXT", "ADVANCE", "JUMP", "COND_JUMP", "RETURN", "CALL", "MODE_SWITCH", "EXPAND_AND_REEXECUTE")


class NormInstr:
    __slots__ = ("mode", "pc", "opcode", "kind", "pc_effect", "advance", "operands", "confidence")

    def __init__(self, mode, pc, opcode, kind, pc_effect, advance, operands, confidence):
        self.mode, self.pc, self.opcode = mode, pc, opcode
        self.kind, self.pc_effect, self.advance = kind, pc_effect, advance
        self.operands, self.confidence = operands, confidence

    def __repr__(self):
        return "NormInstr(%s:%s op=%s %s %s%s)" % (self.mode, self.pc, self.opcode, self.kind, self.pc_effect,
                                                  "" if self.advance == 1 else "(%s)" % self.advance)


class V151Unknown(IRStmt):
    """Diagnostic statement; rendered as `-- V151_UNKNOWN(mode=M, opcode=O, operands=[...])`."""

    def __init__(self, mode, opcode, operands=(), reason=""):
        self.mode, self.opcode, self.operands, self.reason = mode, opcode, tuple(operands), reason

    def text(self):
        s = "V151_UNKNOWN(mode=%s, opcode=%s, operands=%s)" % (self.mode, self.opcode, list(self.operands))
        return s + (": " + self.reason if self.reason else "")


def normalize(mapper, mode, pc, opcode, operands=None):
    """NormInstr for the instruction (mode, opcode) at pc using that mode's
    OpcodeMapper; an opcode the mapper does not know becomes kind UNKNOWN."""
    spec = mapper.get(opcode) if mapper is not None else None
    if spec is None or not spec.known:
        return NormInstr(mode, pc, opcode, "UNKNOWN", "NEXT", 1, operands or [], 0.0)
    eff = spec.pc_effect
    return NormInstr(mode, pc, opcode, spec.kind, eff, spec.advance, operands or list(spec.operands), spec.confidence)


def normalize_stream(mappers, mode, ops, operands=None, start_pc=1):
    """List of NormInstr for an instruction array (1-based pc)."""
    mp = mappers.get(mode)
    out = []
    for i, op in enumerate(ops):
        row = None
        if operands:
            row = {k: (v[i] if i < len(v) else None) for k, v in operands.items()}
        out.append(normalize(mp, mode, start_pc + i, op, row))
    return out


def unknown_text(mapper_for_mode, mode, opcode, reason=""):
    """The V151_UNKNOWN diagnostic text for an instruction that failed to lift,
    carrying the handler kind the opcode map found (if any)."""
    ops = []
    if mapper_for_mode is not None:
        spec = mapper_for_mode.get(opcode)
        ops = list(spec.operands) if spec is not None else []
        kind = spec.kind if spec is not None else "UNKNOWN"
        reason = ("kind=%s; " % kind if spec is not None else "") + reason
    return V151Unknown(mode, opcode, ops, reason).text()

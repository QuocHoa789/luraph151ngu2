"""Validation gate for the v15.1 backend (round 2, phase 9).

`evaluate(facts)` turns the measured facts of one run into a verdict:

  PASS     everything below is clean *and* the lifted CFG replays the real behaviour trace
  PARTIAL  something was lifted, but at least one check is not clean (the reasons say which)
  BLOCKED  the run could not happen here: a runtime / native dependency is missing
  FAIL     the execution or the decode itself broke (no usable harness dump, lifter crash)

PASS requires ALL of: 0 unlifted blocks, 0 nil calls, 0 unknown-opcode steps, a closure
graph that covers every proto the real run entered, and trace conformance
(`conformance.check`).  A run without a behaviour trace can be at best PARTIAL unless the
caller says the trace is not required (`trace_required=False`); the report then carries
`validated_against_trace: false` so nobody mistakes it for a behavioural proof.

The driver emits final Luau only for a PASS.  Nothing here changes what the lifter did.
"""

PASS, PARTIAL, BLOCKED, FAIL = "PASS", "PARTIAL", "BLOCKED", "FAIL"
VERDICTS = (PASS, PARTIAL, BLOCKED, FAIL)


def _reason(code, detail, **extra):
    r = {"code": code, "detail": detail}
    r.update(extra)
    return r


def evaluate(f, trace_required=True):
    """`f` (all keys optional; a missing measurement is never read as "clean"):
      runtime        {"available": bool, "reason": str}
      harness        {"ok": bool, "error": str}
      decode         {"protos": int, "instructions": int}
      lift           {"ran": bool, "error": str}
      unlifted_blocks, nil_calls, unknown_opcode_steps    int
      closure        {"entered_not_lifted": [proto keys], "dangling_edges": int}
      conformance    conformance.check() report, or {"verdict": "NO_TRACE"}
    """
    reasons = []
    rt = f.get("runtime")
    if rt is not None and not rt.get("available", False):
        return _out(BLOCKED, [_reason("RUNTIME_MISSING", rt.get("reason") or "no usable native runtime")], f)
    hs = f.get("harness")
    if hs is not None and not hs.get("ok", False):
        return _out(FAIL, [_reason("HARNESS_FAILED", hs.get("error") or "the dynamic harness did not produce a dump")], f)
    dec = f.get("decode")
    if dec is None or not dec.get("protos"):
        return _out(FAIL, [_reason("NO_PROTOS", "no protos were decoded from the harness dump")], f)
    lf = f.get("lift")
    if lf is not None and lf.get("budget"):
        return _out(PARTIAL, [_reason("LIFT_BUDGET_EXHAUSTED", lf.get("error") or "the CFG is too large to lower within the budget",
                                      detail_data=lf.get("budget"))], f)
    if lf is None or not lf.get("ran", False) or lf.get("error"):
        return _out(FAIL, [_reason("LIFT_FAILED", (lf or {}).get("error") or "the lifter did not run")], f)

    u = f.get("unlifted_blocks")
    n = f.get("nil_calls")
    k = f.get("unknown_opcode_steps")
    if u is None or u > 0:
        reasons.append(_reason("UNLIFTED_BLOCKS", "%s unlifted block(s)" % ("unknown number of" if u is None else u), count=u))
    if n is None or n > 0:
        reasons.append(_reason("NIL_CALLS", "%s call(s) of a nil value in the lifted code" % ("unknown number of" if n is None else n), count=n))
    if k is None or k > 0:
        reasons.append(_reason("UNKNOWN_OPCODES", "%s step(s) with an opcode without evidence-based semantics" % ("unknown number of" if k is None else k), count=k))
    cl = f.get("closure")
    if cl is None:
        reasons.append(_reason("INVALID_CLOSURE_GRAPH", "closure graph not checked"))
    else:
        miss = cl.get("entered_not_lifted") or []
        if miss or cl.get("dangling_edges"):
            reasons.append(_reason("INVALID_CLOSURE_GRAPH",
                                   "%d proto(s) the real run entered were never lifted, %d dangling closure edge(s)" % (len(miss), cl.get("dangling_edges") or 0),
                                   protos=list(miss)[:20]))
    cf = f.get("conformance") or {"verdict": "NO_TRACE"}
    validated = False
    if cf.get("verdict") == "CONFORMANT":
        validated = True
    elif cf.get("verdict") == "NOT_CONFORMANT":
        t = cf.get("total", {})
        reasons.append(_reason("TRACE_NOT_CONFORMANT",
                               "the real run does not replay through the lifted CFG: %d missing edge(s), %d step(s) decoded to another opcode, %d bad entr(ies)" % (
                                   t.get("fail", 0), t.get("nosrc", 0), t.get("entry_fail", 0)),
                               failures=cf.get("failures", [])[:6]))
    else:
        if trace_required:
            reasons.append(_reason("NO_TRACE", "no behaviour trace of the real run to validate the lift against"))
    verdict = PASS if not reasons else PARTIAL
    return _out(verdict, reasons, f, validated)


def _out(verdict, reasons, f, validated=False):
    return {"verdict": verdict, "emit_source": verdict == PASS, "validated_against_trace": validated,
            "reasons": reasons,
            "metrics": {k: f.get(k) for k in ("decode", "unlifted_blocks", "nil_calls", "unknown_opcode_steps")},
            "closure": f.get("closure"),
            "conformance": _short_conf(f.get("conformance"))}


def _short_conf(c):
    if not c:
        return None
    return {k: c.get(k) for k in ("verdict", "total", "transitions", "ratio", "protos_checked", "failures")}


def closure_check(oracle, records, dump_protos):
    """Closure-graph validity from the real run: every proto the real run entered
    (oracle.entries, proto ids) must have a lifted walk; every lifted proto must exist."""
    lifted = {r["proto"] for r in records}
    entered = set()
    for pid in oracle.entries:
        entered.add(str(pid))
    # entry markers use the harness' proto numbering; keys of `protos` are the same strings
    known = set(dump_protos)
    not_lifted = sorted(p for p in entered if p in known and p not in lifted)
    dangling = sum(1 for p in lifted if p not in known)
    return {"entered_not_lifted": not_lifted, "dangling_edges": dangling,
            "entered": len(entered), "lifted": len(lifted)}

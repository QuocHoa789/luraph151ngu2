"""Dynamic instruction expansion for Luraph v15.1 (Phase 5).

Some v15.1 handlers do not execute an instruction, they *decode it in place*:
they read the packed instruction word, write the decoded fields back into the
instruction arrays at the current pc (``A[v]=...; R[v]=...; s[i]=...``) and
then decrement the pc (``e-=1`` / ``i=i-1``) so that the dispatch loop's own
``pc+1`` executes the freshly rewritten instruction.  That is the
``EXPAND_AND_REEXECUTE`` effect (see ``opcode_maps``).

Two parts:

* static  - ``find_expanders(mappers)`` lists the handlers with that effect
            (from the opcode maps; nothing is assumed about their semantics);
* dynamic - ``Expander`` is the bounded, cycle-checked, deterministic account
            the devirtualizer engine keeps while it re-executes: every
            rewrite-then-re-execute event is recorded; exceeding a bound or
            seeing the same (mode, pc, fingerprint) twice raises
            ``ExpansionLimit`` (the engine turns that into an unlifted block
            with this diagnostic, never an endless loop).

Bounds (environment overridable, all deterministic):
    DEVIRT_MAX_REEXEC_PER_PC   expansion events of one pc in one step (all decision paths; default 128, the engine itself stops a single path after 8)
    DEVIRT_MAX_EXPANSIONS      expansion events per lifted proto         (default 2_000_000)
"""
import os


class ExpansionLimit(Exception):
    pass


def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


MAX_REEXEC_PER_PC = _env_int("DEVIRT_MAX_REEXEC_PER_PC", 128)
MAX_EXPANSIONS = _env_int("DEVIRT_MAX_EXPANSIONS", 2000000)


def find_expanders(mappers):
    """[(mode, opcode, arrays written)] for handlers whose PC effect is
    EXPAND_AND_REEXECUTE.  `mappers` is `opcode_maps.build_mappers()` output."""
    out = []
    for mode, mp in sorted(mappers.items()):
        for s in mp.handlers():
            if s.pc_effect == "EXPAND_AND_REEXECUTE":
                arrays = sorted(set(s.features.get("written_by_pc", [])) | set(s.features.get("written_other", [])))
                out.append((mode, s.opcode, arrays))
    return out


class Expander:
    """Bounded record of expansion (decode-in-place + re-execute) events."""

    def __init__(self, max_per_pc=None, max_total=None):
        self.max_per_pc = MAX_REEXEC_PER_PC if max_per_pc is None else max_per_pc
        self.max_total = MAX_EXPANSIONS if max_total is None else max_total
        self.total = 0
        self.by_op = {}                 # (mode, op) -> count
        self.seen = set()               # (mode, pc, fingerprint): same instruction decoded to the same thing twice = a cycle
        self.limit_hits = 0
        self._step_pc = None
        self._step_n = 0

    def begin_step(self, mode, pc):
        """Call at the start of each instruction step (resets the per-step counter)."""
        self._step_pc = (mode, pc)
        self._step_n = 0

    def record(self, mode, pc, op, fingerprint=None):
        """Note that the handler (mode, op) rewrote the instruction at `pc`
        and it will run again.  Raises ExpansionLimit on a bound / cycle."""
        self.total += 1
        self._step_n += 1
        self.by_op[(mode, op)] = self.by_op.get((mode, op), 0) + 1
        if self.total > self.max_total:
            self.limit_hits += 1
            raise ExpansionLimit("more than %d expansion events" % self.max_total)
        if self._step_n > self.max_per_pc:
            self.limit_hits += 1
            raise ExpansionLimit("instruction %s:%s re-decoded %d times in one step (op %s)" % (
                mode, pc, self._step_n, op))
        if fingerprint is not None:
            key = (mode, pc, fingerprint)
            if key in self.seen and self._step_n > 1:
                self.limit_hits += 1
                raise ExpansionLimit("expansion cycle at %s:%s (op %s)" % (mode, pc, op))
            self.seen.add(key)

    def summary(self):
        return {"expansions": self.total, "distinct_ops": len(self.by_op), "limit_hits": self.limit_hits,
                "top": sorted(self.by_op.items(), key=lambda kv: -kv[1])[:6]}


def self_check():
    """Tiny deterministic exercise used by the tests (no engine needed)."""
    e = Expander(max_per_pc=3, max_total=100)
    e.begin_step(73, 5)
    e.record(73, 5, 1, "a")
    e.record(73, 5, 77, "b")
    try:
        e.record(73, 5, 1, "b")
    except ExpansionLimit:
        return True
    return False

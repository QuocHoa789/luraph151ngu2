"""Trace conformance of a lifted CFG (round 2, phases 5 and 9).

The harness run (`--debug-v151`) records every dispatch step the *real* program executed:
(array id, mode, pc, opcode) plus closure entries.  A lifted control-flow graph conforms
to that run when the run can be replayed through it: every executed step must be
reachable from the previous executed step of the same call frame through an edge the
lifter built, with the opcode the lifter decoded.

  record_walk(proto_key, closure, order, edges)  ->  compact record of one finished walk
  check(oracle, records, return_kinds)           ->  report (per proto and total)

Replay rules (no step is ever skipped silently):
  * a call frame is opened by a closure-entry marker and closed by an executed RETURN;
  * consecutive steps of one frame with the same (mode, pc) are one instruction that
    re-dispatched itself after an in-place decode: only the last one is compared;
  * several lifted instances of one proto (closures with different upvalues) are merged
    by union - a transition is `ok` when any instance has it;
  * the first step of a frame must be a state the lifter has (entry check).
A step whose source state does not exist in the lift is `nosrc` (the lift decoded another
opcode there); a missing edge is `fail`.  Nothing here changes what the lifter emits.
"""

AID = 1 << 40
TAG = 1 << 34
PC = 1 << 10


def record_walk(proto_key, closure, order, edges, summaries=None):
    """Compact record: the (mode, pc, opcode) of every stepped state and the edges between
    them as triples.  `order` is [(state key, node)], `edges` {state key: {state key}}."""
    triple = {}
    errors = 0
    for k, node in order:
        op = getattr(node, "op", None)
        if getattr(node, "error", None):
            errors += 1
        if op and op[1] is not None and not isinstance(op[1], bool) and isinstance(op[1], int):
            triple[k] = (op[0], k[1], op[1])
    states = set(triple.values())
    out = set()
    for k, succs in (edges or {}).items():
        a = triple.get(k)
        if a is None:
            continue
        for nk in succs:
            b = triple.get(nk)
            if b is not None:
                out.add((a, b))
    summ = {}
    for k, apps in (summaries or {}).items():
        a = triple.get(k)
        if a is not None:
            summ.setdefault(a, set()).update(apps)
    return {"proto": proto_key, "closure": closure, "states": states, "edges": out,
            "stepped": len(order), "errors": errors, "summaries": summ}


def merge(records):
    """{proto key: {"states": set, "edges": set}} (union over instances)."""
    m = {}
    for r in records:
        d = m.setdefault(r["proto"], {"states": set(), "edges": set(), "instances": 0, "stepped": 0, "errors": 0,
                                      "summaries": {}})
        d["states"] |= r["states"]
        d["edges"] |= r["edges"]
        for a, apps in (r.get("summaries") or {}).items():
            d["summaries"].setdefault(a, set()).update(apps)
        d["instances"] += 1
        d["stepped"] += r["stepped"]
        d["errors"] += r["errors"]
    return m


def scrub_map(mappers, source_lines, locate):
    """{(mode, decrypt opcode): scrub opcode}: the in-place decryptors end in `A[i]=C` and the cell then decodes as C --
    an opcode WITHOUT a handler (a no-op).  Evidence from the VM source, not from any sample constant.
    `locate(block) -> source text of the handler block`."""
    import re
    out = {}
    for mode, mp in mappers.items():
        noop = set(getattr(mp, "unresolved", ()) or ())
        for sp in mp.handlers():
            if sp.kind != "BLOB_DECRYPT" or sp.block is None:
                continue
            try:
                text = locate(sp.block)
            except Exception:
                continue
            m = re.search(r"A\[[A-Za-z_]\w*\]\s*=\s*(\d+)\s*;?\s*$", text.strip())
            if m and int(m.group(1)) in noop:
                out[(mode, sp.opcode)] = int(m.group(1))
    return out


def check(oracle, records, return_kinds, sample=12, scrub=None):
    """`return_kinds`: {(mode, opcode)} whose handler returns from the VM function.
    `scrub`: {(mode, decrypt opcode): scrub opcode} (see scrub_map).  The flow-insensitive shared overlay of the walk
    shows an in-place decryptor's cell as its scrub no-op once ANY path has executed it; a real step of the decryptor
    whose (mode, pc, scrub opcode) the lift has is counted `scrub_equivalent` (reported apart from `ok`, never merged
    into it: `ratio` stays the strict ratio, `ratio_scrub_equivalent` adds them)."""
    scrub = scrub or {}
    rscrub = {}
    for (m_, d_), s_ in scrub.items():
        rscrub.setdefault((m_, s_), []).append(d_)
    lifted = merge(records)
    aid2key = {}
    for key in lifted:
        for a in oracle.aids_of(key):
            aid2key[a] = key
    per = {}
    fails = {}
    eq = {"n": 0}

    def count(key, what):
        d = per.setdefault(key, {"ok": 0, "fail": 0, "nosrc": 0, "entry_ok": 0, "entry_fail": 0, "ok_scrub_equivalent": 0})
        d[what] += 1

    def commit(fr):
        cur = fr["pend"]
        if cur is None:
            return
        fr["pend"] = None
        key = aid2key.get(fr["aid"])
        if key is not None:
            L = lifted[key]
            if cur not in L["states"]:
                alt = None
                sc = scrub.get((cur[0], cur[2]))
                if sc is not None and (cur[0], cur[1], sc) in L["states"]:
                    alt = (cur[0], cur[1], sc)               # real = the decryptor's first execution, lift = its decoded no-op
                else:
                    for d in rscrub.get((cur[0], cur[2]), ()):
                        if (cur[0], cur[1], d) in L["states"]:
                            alt = (cur[0], cur[1], d)        # real = a LATER activation (the cell was decoded by an earlier one),
                            break                            # lift = the first activation's decryptor
                if alt is not None:
                    eq["n"] += 1
                    cur = alt
                    fr["equiv"] = True
            if fr["last"] is None:
                if cur in L["states"]:
                    count(key, "entry_ok")
                else:
                    count(key, "entry_fail")
                    fails[(key, None, cur, "entry")] = fails.get((key, None, cur, "entry"), 0) + 1
            elif fr["last"] not in L["states"]:
                count(key, "nosrc")
                fails[(key, fr["last"], cur, "nosrc")] = fails.get((key, fr["last"], cur, "nosrc"), 0) + 1
            elif (fr["last"], cur) in L["edges"]:
                count(key, "ok_scrub_equivalent" if fr.pop("equiv", False) else "ok")
            else:
                count(key, "fail")
                fails[(key, fr["last"], cur, "fail")] = fails.get((key, fr["last"], cur, "fail"), 0) + 1
        fr["last"] = cur

    stack = []
    summarised = [0]
    for v in oracle.trace:
        if v < 0:
            stack.append({"aid": None, "last": None, "pend": None})
            continue
        aid, rest = divmod(v, AID)
        tag, rest = divmod(rest, TAG)
        pc, op = divmod(rest, PC)
        mode = oracle.mode_of_tag.get(tag)
        cur = (mode, pc, op)
        if not stack:
            stack.append({"aid": None, "last": None, "pend": None})
        fr = stack[-1]
        if fr["aid"] is not None and fr["aid"] != aid:
            commit(fr)
            stack.append({"aid": aid, "last": None, "pend": None})
            fr = stack[-1]
        fr["aid"] = aid
        sk = fr.get("skip")
        if sk is not None:
            if sk[3]:
                sk[3] = (pc != sk[2])                      # inside the helper until its exit step has been seen
                summarised[0] += 1
                if not sk[3]:
                    sk[4] = True
                continue
            fr["skip"] = None                              # first step after the helper's exit: compared normally
        p = fr["pend"]
        if p is not None and (p[0], p[1]) == (mode, pc):
            fr["pend"] = cur
        else:
            commit(fr)
            key_ = aid2key.get(aid)
            apps = lifted[key_]["summaries"].get(fr["last"]) if key_ is not None and fr["last"] is not None else None
            hit = [a for a in (apps or ()) if (a[0], a[1]) == (mode, pc)]
            if hit:
                # entering a summarised helper from a state that has the summary: swallow up to its exit step
                sk = [mode, pc, hit[0][2], pc != hit[0][2], False]
                fr["skip"] = sk
                summarised[0] += 1
                if pc == hit[0][2]:
                    sk[3] = False
                    sk[4] = True
                continue
            fr["pend"] = cur
        if (mode, op) in return_kinds:
            commit(fr)
            stack.pop()
    for fr in stack:
        commit(fr)
    total = {"ok": 0, "fail": 0, "nosrc": 0, "entry_ok": 0, "entry_fail": 0, "ok_scrub_equivalent": 0}
    for d in per.values():
        for k, v in d.items():
            total[k] += v
    transitions = total["ok"] + total["fail"] + total["nosrc"] + total["ok_scrub_equivalent"]
    first = sorted(fails.items(), key=lambda kv: -kv[1])[:sample]
    return {"per_proto": per, "total": total, "transitions": transitions,
            "conformant": transitions > 0 and total["fail"] == 0 and total["nosrc"] == 0 and total["entry_fail"] == 0,
            "ratio": (total["ok"] / transitions) if transitions else None,
            "ratio_scrub_equivalent": ((total["ok"] + total["ok_scrub_equivalent"]) / transitions) if transitions else None,
            "ratio_all_real_steps": ((total["ok"] + total["ok_scrub_equivalent"] + summarised[0]) / (transitions + summarised[0]))
            if transitions + summarised[0] else None,       # comparable with a run without summaries: a swallowed helper step
                                                            # counts as followed only because the step after it was checked
            "protos_checked": len(per), "summarised_steps": summarised[0],
            "failures": [{"proto": k[0], "from": k[1], "to": k[2], "kind": k[3], "count": n} for k, n in first]}

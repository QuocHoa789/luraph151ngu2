"""Gate between the v15.1 lifter and the final output (round 2, phase 9 / 12).

`run_gate(...)` measures the finished lift, asks `validator.evaluate` for the verdict and
writes the evidence next to the job outputs:

    <job>.v151diag.json     verdict + reasons + unlifted blocks + nil calls + conformance +
                            semantic evidence + key-carry log (always written)
    <job>.v151-report.txt   the same for people (UNLIFTED BLOCK layout, nil-call groups)

The caller writes the devirtualized Luau only when the verdict is PASS.  Without PASS the
behaviour trace stays the result (the driver already falls back to it).
"""
import json
import os

from obfuscators.luraph_v15_1 import validator as V
from obfuscators.luraph_v15_1 import diagnostics as DG


def measure(EP, ppath, finished_text, stats, trace_required=True):
    """The facts `validator.evaluate` needs, measured from this process' lift."""
    facts = {"runtime": {"available": True}, "harness": {"ok": True}}
    try:
        from obfuscators.luraph_v15_1 import stream_decoder as SD
        ds = SD.DumpStreams(ppath)
        facts["decode"] = {"protos": len(ds), "instructions": ds.total_instructions()}
    except Exception as ex:
        facts["decode"] = {"protos": 0, "instructions": 0, "error": "%s: %s" % (type(ex).__name__, ex)}
    facts["lift"] = {"ran": finished_text is not None}
    dsum = EP.DIAG.summary()
    nil_text = finished_text.count("(nil)(") if finished_text else None
    facts["unlifted_blocks"] = max(int(stats.get("errors", 0) or 0), dsum["unlifted_blocks"]) if stats else None
    facts["nil_calls"] = max(nil_text or 0, dsum["nil_calls"]) if nil_text is not None else None
    facts["nil_calls_in_text"] = nil_text
    facts["unknown_opcode_steps"] = EP.STATS.get("unknown_steps")
    cf = EP.conformance_report()
    facts["conformance"] = cf
    orc = EP.oracle()
    try:
        import json as _j
        with open(ppath, encoding="utf-8") as f:
            protos = set((_j.load(f).get("protos") or {}).keys())
        facts["closure"] = V.closure_check(orc, EP.DIAG.walk_records, protos) if orc else None
        if facts["closure"] is None:
            facts["closure"] = {"entered_not_lifted": [], "dangling_edges": 0, "note": "no trace: entered protos unknown"}
    except Exception as ex:
        facts["closure"] = None
        facts["closure_error"] = "%s: %s" % (type(ex).__name__, ex)
    return facts


def failure_facts(EP, ppath, error):
    """Facts of a lift that raised: a lowering-budget stop is an incomplete lift (PARTIAL), any other
    exception is a failed lift."""
    msg = "%s" % error
    lift = {"ran": True, "error": msg}
    if "V151_LOWER_BUDGET" in msg or "V151_LOWER_MEMORY" in msg:
        lift["budget"] = list(EP.DIAG.budget_hits)[-3:] or [{"error": msg[:300]}]
    return lift


def run_gate(job_path, EP, ppath, finished_text, stats, trace_required=True, extra=None, lift_error=None):
    """-> (result dict, diag path, report path).  `job_path(suffix)` builds an output path."""
    facts = measure(EP, ppath, finished_text, stats, trace_required)
    if lift_error is not None:
        facts["lift"] = failure_facts(EP, ppath, lift_error)
    if extra:
        facts.update(extra)
    res = V.evaluate(facts, trace_required=trace_required)
    diag = EP.DIAG.as_dict()
    try:
        sem = EP.semantic_report()
    except Exception as ex:
        sem = {"error": "%s: %s" % (type(ex).__name__, ex)}
    doc = {"verdict": res["verdict"], "emit_source": res["emit_source"],
           "validated_against_trace": res["validated_against_trace"], "reasons": res["reasons"],
           "metrics": res["metrics"], "closure": res["closure"], "conformance": facts.get("conformance"),
           "diagnostics": diag, "semantics": sem,
           "key_carry": _key_carry(EP), "lift_stats": {k: v for k, v in (stats or {}).items() if isinstance(v, (int, float, str))}}
    dpath = job_path(".v151diag.json")
    with open(dpath, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, default=str)
    rpath = job_path(".v151-report.txt")
    with open(rpath, "w", encoding="utf-8") as f:
        f.write(render_report(doc))
    try:
        from obfuscators.luraph_v15_1 import diag_report as _DR
        _DR.write(job_path, diag, res.get("metrics"))          # <out>.v151-unlifted-blocks.json / -nil-calls.json
    except Exception as ex:                                     # evidence files must never break the verdict
        with open(rpath, "a", encoding="utf-8") as f:
            f.write("\n(diag_report failed: %s: %s)\n" % (type(ex).__name__, ex))
    return res, dpath, rpath


def _key_carry(EP):
    return EP.KEY_CARRY if hasattr(EP, "KEY_CARRY") else {}


def render_report(doc):
    out = ["VERDICT: %s%s" % (doc["verdict"], "" if doc["verdict"] != "PASS" else
                              ("  (validated against the real behaviour trace)" if doc["validated_against_trace"]
                               else "  (structural checks only; no behaviour trace)")), ""]
    for r in doc["reasons"]:
        out.append("  - %s: %s" % (r["code"], r["detail"]))
    m = doc["metrics"]
    out += ["", "metrics: unlifted_blocks=%s nil_calls=%s unknown_opcode_steps=%s decode=%s" % (
        m.get("unlifted_blocks"), m.get("nil_calls"), m.get("unknown_opcode_steps"), m.get("decode"))]
    cf = doc.get("conformance") or {}
    if cf.get("total") is not None:
        out.append("trace conformance: %s  %s  ratio=%s" % (cf.get("verdict"), cf.get("total"), cf.get("ratio")))
        for f in (cf.get("failures") or [])[:6]:
            out.append("    divergence in proto %s: %s -> %s (%s, x%s)" % (f["proto"], f["from"], f["to"], f["kind"], f["count"]))
    d = doc["diagnostics"]
    out += ["", "unlifted blocks by class: %s" % d["summary"]["by_class"],
            "nil calls by root cause: %s" % d["summary"]["nil_by_root_cause"], ""]
    for r in d["unlifted_blocks"][:200]:
        out.append(DG.format_block(r))
        out.append("")
    for r in d["nil_calls"][:200]:
        out.append("NIL CALL proto=%s mode=%s pc=%s kind=%s root_cause=%s callee=%s" % (
            r.get("proto"), r.get("mode"), r.get("pc"), r.get("kind"), r.get("root_cause"), r.get("callee")))
    return "\n".join(out) + "\n"

"""Machine-readable reports of what is still unlifted (phase C) and of every nil call (phase D).

Two documents, built from the records `diag_hooks` collected during the final walks and enriched here:

  <out>.v151-unlifted-blocks.json   one entry per reachable unlifted block
  <out>.v151-nil-calls.json         one entry per nil-call site, grouped by root cause

Nothing is guessed: a field that the tooling cannot capture (for example the register value the real
run observed -- the step trace holds pc/opcode only) is written as an explicit NOT_CAPTURED marker.
The `proposed_fix` of a block is rule based and names the evidence it rests on; it is a lead for the
next change, not a claim that the fix is correct.
"""
import json
import re

from obfuscators.luraph_v15_1 import diagnostics as DG

PROPOSED = {
    "UNKNOWN_RETURN_CONTINUATION": (
        "Record the constants the register can hold at this return/computed jump: either the assignment is a "
        "non-constant expression (value-set analysis over its operands) or the register is written through a path "
        "retsite.py does not tokenise (a non-call-like transfer).",
        "message shows `pc = <register> (+ offset)`; see `register_definitions`"),
    "RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW": (
        "The walk's loop-stack depth bound (MAX_STACK_DEPTHS) was hit: model the stack as a call-return abstraction "
        "like the link registers instead of one state per depth.",
        "'stack depth' message with the depths already seen"),
    "MISSING_CFG_SUCCESSOR": (
        "Resolve the next pc/mode of this instruction (it is symbolic and not an affine function of a tracked "
        "register); check the handler kind for a computed jump table.",
        "symbolic next pc/mode that is not `register (+/-) constant`"),
    "WRONG_BRANCH_TARGET": (
        "The target pc lies far outside the instruction array: check the jump-offset decoding (sign/width) and whether "
        "the instruction was re-decoded in place before this branch.", "pc beyond the array length + 64"),
    "DYNAMIC_MATERIALIZATION": (
        "Verify the in-place decode of the operand arrays at this pc (expansion log) and re-execute with the "
        "decoded instruction; the lifter saw a value the real VM would not have after decoding.",
        "operand arrays at this pc written by an in-place decoder, or the real run executed another opcode here"),
    "UNKNOWN_OPCODE_SEMANTIC": (
        "Recover the handler semantics from its source with evidence (register reads/writes, control effect) before "
        "lifting; keep it V151_UNKNOWN until then.",
        "no handler / rule for the decoded opcode"),
    "MISSING_CLOSURE_EDGE": ("Resolve the proto the closure maker receives (maker parameter table).", "closure op without a proto"),
    "MISSING_PROTO_EDGE": ("Resolve the proto the closure maker receives (maker parameter table).", "closure op without a proto"),
    "BAD_REGISTER_STATE": (
        "An operand reached an operation with a value outside any legitimate range: trace the register back to the "
        "load that produced it (see `registers`).", "out-of-range / wrong-type operand"),
    "BAD_CONSTANT": (
        "A decoded string/constant reached a numeric operation: check the lazy constant decode for the request key "
        "(a further harness round may supply it) or whether this path is taken at all.",
        "string operand in a numeric/bit operation, or a constant that is not decoded yet"),
    "UNSUPPORTED_CALL": ("Model the callee (builtin / closure) or mark the call as opaque with evidence.", "call of an unknown function"),
    "JUNK_UNREACHABLE": (
        "No change needed for fidelity if the path is junk: confirm it is not reachable from any lifted block "
        "(the real run never executed this pc although its proto ran).", "real-run trace: proto ran, this pc never executed"),
    "OTHER": ("Inspect the message; no rule classified it.", "unmatched message"),
}


def _exit_class(rec):
    a = rec.get("affects") or {}
    kind = (rec.get("handler") or {}).get("kind")
    if a.get("return") or kind == "RETURN":
        return "RETURN"
    if a.get("call") or kind == "CALL":
        return "CALL"
    if kind == "COND_JUMP":
        return "COND_JUMP"
    if a.get("jump") or kind in ("JUMP", "MODE_SWITCH"):
        return "JUMP"
    if kind in ("EXPAND", "BLOB_DECRYPT"):
        return "MATERIALIZATION"
    if kind in (None, "UNKNOWN"):
        return "UNKNOWN"
    return "FALLTHROUGH"


def _reachable(rec):
    rt = rec.get("real_trace") or {}
    v = rt.get("verdict")
    if v in ("SAME_OP", "DIFFERENT_OP"):
        return True, "the real run executed this (mode, pc)"
    if v == "NOT_REACHED":
        return False, ("the proto ran in the real run but never executed this (mode, pc)"
                       if rt.get("proto_ran_in_real_run") else "the proto did not run in the real run")
    if v == "PROTO_NOT_RUN":
        return False, "the proto never ran in the real run"
    return None, "no execution trace (run with --debug-v151)"


def _reg_defs(rec):
    """Register -> constant/non-constant fact at the block, from the walk's SCCP facts."""
    out = {}
    for r, f in (rec.get("registers") or {}).items():
        out[str(r)] = f
    return out


def block_entry(rec):
    reach, basis = _reachable(rec)
    cls = rec.get("block_class", "OTHER")
    act, ev = PROPOSED.get(cls, PROPOSED["OTHER"])
    unknown_ops = []
    msg = rec.get("message") or ""
    if "V151_UNKNOWN" in msg or rec.get("opcode") is None or (rec.get("handler") or {}).get("kind") == "UNKNOWN":
        unknown_ops.append({"mode": rec.get("opcode_mode", rec.get("mode")), "opcode": rec.get("opcode"),
                            "message": msg[:200]})
    e = {
        "function": {"proto": rec.get("proto"), "closure": rec.get("closure")},
        "block_start": {"mode": rec.get("mode"), "pc": rec.get("pc")},
        "mode": rec.get("mode"), "opcode": rec.get("opcode"), "handler": rec.get("handler"),
        "predecessors": rec.get("predecessors", []), "successors": rec.get("successors", []),
        "exit_classification": _exit_class(rec),
        "register_state": _reg_defs(rec),
        "constants_and_operands": rec.get("operands", {}),
        "upvalues": rec.get("upvalues", {}),
        "closure_proto_refs": {"closure": rec.get("closure_ref"), "closure_path": rec.get("closure")},
        "unknown_operations": unknown_ops,
        "reject_reason": {"reason": rec.get("reason"), "message": msg, "block_class": cls,
                          "class_evidence": rec.get("class_evidence")},
        "runtime_reachable": reach, "runtime_reachability_basis": basis,
        "real_trace": rec.get("real_trace"),
        "proposed_fix": {"action": act, "evidence": ev, "status": "LEAD_NOT_VERIFIED"},
        "payload_relevant": bool(reach),
    }
    return e


def _flow(rec):
    """Data-flow chain of the callee register (from the record's last writer)."""
    chain = []
    w = rec.get("last_writer")
    if w:
        chain.append({"definition": "r%s = %s" % (rec.get("callee_register"), w.get("value")),
                      "at": {"mode": w.get("mode"), "pc": w.get("pc"), "opcode": w.get("opcode")},
                      "value_type": w.get("value_type")})
    return chain


def _value_source(rec):
    k = rec.get("kind")
    return {"NIL_CALL_REGISTER": "register", "NIL_CALL_CLOSURE": "closure", "NIL_CALL_PROTO": "proto",
            "NIL_CALL_ENV": "environment", "NIL_CALL_CONSTANT": "constant", "NIL_CALL_DYNAMIC": "dynamic",
            }.get(k, "unknown")


def nil_entry(rec):
    rt = rec.get("real_trace") or {}
    v = rt.get("verdict")
    if v in ("SAME_OP",):
        validity = "RECONSTRUCTION_DEFECT"
        why = ("the real run executed this call instruction and continued: the callee was not nil there, so the "
               "nil is introduced by the reconstruction")
    elif v == "DIFFERENT_OP":
        validity = "DECODE_DIVERGENCE"
        why = "the real run executed another opcode at this pc: the lifter decoded the instruction differently"
    elif v in ("NOT_REACHED", "PROTO_NOT_RUN"):
        validity = "UNREACHED_IN_RUNTIME"
        why = "the real run never executed this pc: a path the lifter walked that the VM did not take"
    else:
        validity = "UNKNOWN"
        why = "no execution trace"
    return {
        "call_site": {"proto": rec.get("proto"), "closure": rec.get("closure"), "mode": rec.get("mode"),
                      "pc": rec.get("pc"), "call_index": rec.get("index")},
        "opcode": rec.get("opcode"), "handler": rec.get("handler"),
        "callee": {"expression": rec.get("callee"), "register": rec.get("callee_register")},
        "reaching_definition": rec.get("last_writer") if rec.get("last_writer") else
        ({"definition": "none on the first-discovered path", "register": rec.get("callee_register")}
         if rec.get("uninitialized_register") else None),
        "register_data_flow": _flow(rec),
        "value_source": _value_source(rec),
        "empty_operand_arrays": rec.get("empty_operand_arrays", []),
        "expected_callee_semantics": ("a function value: the VM call handler invokes the register named by its operand "
                                      "(handler semantic: %s)" % ((rec.get("handler") or {}).get("semantic"),)),
        "observed_runtime_value": {"status": "NOT_CAPTURED",
                                   "note": "the execution trace records (array, pc, opcode) per step, not register values"},
        "runtime_evidence": {"trace_verdict": v, "validity": validity, "explanation": why},
        "root_cause": rec.get("root_cause"), "kind": rec.get("kind"),
        "register_state": rec.get("register_state"),
        "distinction": {"nil_valid_in_vm": False if validity in ("RECONSTRUCTION_DEFECT", "DECODE_DIVERGENCE") else None,
                        "reconstruction_defect": validity in ("RECONSTRUCTION_DEFECT", "DECODE_DIVERGENCE"),
                        "decompiler_placeholder": False},
    }


def _group_nil(entries):
    g = {}
    for e in entries:
        key = re.sub(r"r\d+", "rN", e.get("root_cause") or "?")
        g.setdefault(key, {"root_cause_pattern": key, "count": 0, "sites": []})
        g[key]["count"] += 1
        if len(g[key]["sites"]) < 50:
            g[key]["sites"].append((e["call_site"]["proto"], e["call_site"]["mode"], e["call_site"]["pc"]))
    return sorted(g.values(), key=lambda x: -x["count"])


def build(diag_dict, metrics=None):
    """(unlifted_doc, nil_doc) from DIAG.as_dict() (+ gate metrics)."""
    blocks = [block_entry(r) for r in diag_dict.get("unlifted_blocks", [])]
    nils = [nil_entry(r) for r in diag_dict.get("nil_calls", [])]
    by_class, by_reach = {}, {"reachable": 0, "not_reachable": 0, "unknown": 0}
    for b in blocks:
        c = b["reject_reason"]["block_class"]
        by_class[c] = by_class.get(c, 0) + 1
        k = {True: "reachable", False: "not_reachable", None: "unknown"}[b["runtime_reachable"]]
        by_reach[k] += 1
    by_valid = {}
    for n in nils:
        v = n["runtime_evidence"]["validity"]
        by_valid[v] = by_valid.get(v, 0) + 1
    return (
        {"counting_method": "records of the final walk of every proto (diagnostics.DIAG.unlifted); a block is one "
                            "(proto, mode, pc) the walk could not step or propagate",
         "total": len(blocks), "by_class": by_class, "by_runtime_reachability": by_reach, "blocks": blocks},
        {"counting_method": "call statements of the final walks whose callee is the constant nil or a register "
                            "assigned nil / never written on the first-discovered path (diag_hooks._scan_calls)",
         "total": len(nils), "by_runtime_validity": by_valid, "by_root_cause": _group_nil(nils), "calls": nils},
    )


def write(job_path, diag_dict, metrics=None):
    ub, nc = build(diag_dict, metrics)
    pu, pn = job_path(".v151-unlifted-blocks.json"), job_path(".v151-nil-calls.json")
    for p, doc in ((pu, ub), (pn, nc)):
        with open(p, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=1, default=str)
    return pu, pn

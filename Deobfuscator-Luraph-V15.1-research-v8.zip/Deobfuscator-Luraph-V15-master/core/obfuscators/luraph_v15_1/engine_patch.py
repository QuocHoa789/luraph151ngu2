"""v15.1 specialisations installed into the private engine copy (see engine.py).

Everything here is added to the *copy's* namespace; nothing is shared with
the v15 engine module.
"""
import copy
import os

from obfuscators.luraph_v15_1 import instruction_expander as _IE
from obfuscators.luraph_v15_1 import closure as _CL
from obfuscators.luraph_v15_1 import ir_bridge as _IR
from obfuscators.luraph_v15_1 import diagnostics as _DG
from obfuscators.luraph_v15_1 import diag_hooks as _DH
from obfuscators.luraph_v15_1 import dataflow as _DF
from obfuscators.luraph_v15_1 import retsite as _RS
from obfuscators.luraph_v15_1 import helpersum as _HS

EXPANDER = _IE.Expander()
GRAPH = _CL.ClosureGraph()
STATS = {"source": None, "unknown_steps": 0, "steps": 0, "nodes": {}, "unknown_ops": {}}
DIAG = _DG.Diag()
_MAPPERS = {}


_ORACLE = {}
KVALS_ON = os.environ.get("DEVIRT_V151_KVALS", "0") not in ("0", "")
PERSIST_ON = os.environ.get("DEVIRT_V151_PERSIST", "1") not in ("0", "")             # carry walk knowledge between lifts
WALK_MEMORY = {}
DEPTH_WIDEN = int(os.environ.get("DEVIRT_V151_DEPTH_WIDEN", "0") or 0)    # saturate the loop-stack depth of a state key (0 = off)
# Loop-stack growth quarantine: more than DEPTH_CAP distinct loop-stack depths of ONE state shape (everything of the key
# except the depth identical) is an unbounded push loop; the states beyond the cap are not stepped (error node, reported as
# RECURSIVE_OR_CONTEXT_SENSITIVE_CONTROL_FLOW) so one runaway lineage cannot starve the rest of the worklist.  0 = off.
DEPTH_CAP = int(os.environ.get("DEVIRT_V151_DEPTH_CAP", "24") or 0)
RETSITE_ON = os.environ.get("DEVIRT_V151_RETSITE", "1") not in ("0", "")      # return-site abstraction (retsite.py)
# Path-sensitive instruction-array overlay.  The v15 stepper merges the writes of every stepped instruction into ONE global
# overlay (`gov`), so which XOR layers cell X has already received depends on the ORDER the worklist happens to step states in,
# not on the path that reached it (a decryptor that only runs later in the real program poisons earlier cells).  With PATHOV the
# overlay travels in the state (State.ov, hashed into the state key); the global one is only a read-through proxy.
PATHOV = os.environ.get("DEVIRT_V151_PATHOV", "1") not in ("0", "")
ORDER = os.environ.get("DEVIRT_V151_ORDER", "novel")                         # worklist order of the walk: lifo | fifo | novel
NOVEL_WINDOW = int(os.environ.get("DEVIRT_V151_NOVEL_WINDOW", "512") or 512)
LOWER_BUDGET = int(os.environ.get("DEVIRT_LOWER_BUDGET", "50000000"))   # blocks x assigned registers
LOWER_BLOCKS = int(os.environ.get("DEVIRT_LOWER_BLOCKS", "12000"))     # blocks of one function (a CFG this large is de-outlining blow-up, not code)
KEY_CARRY = {}          # proto key -> what the key-local carrying learned (diagnostics)


def oracle():
    """Execution-trace oracle of the dump being lifted (empty when the run had no trace)."""
    key = STATS.get("dump_path")
    if key not in _ORACLE:
        from obfuscators.luraph_v15_1 import trace_oracle as _TO, vmmap as _VM
        try:
            _ORACLE[key] = _TO.load(key, _TO.mode_of_tag_from_source(_VM.load_ast(STATS["source"])))
        except Exception:
            _ORACLE[key] = _TO.Oracle([], {})
    return _ORACLE[key]


def _semantic(mode, opcode):
    """Evidence-based semantic name of an opcode (semantics.py), or None."""
    try:
        from obfuscators.luraph_v15_1 import semantics as _SM
        sp = _SM.semantic_of(mode, opcode, mappers())
        return sp.name if sp is not None and sp.name != "UNKNOWN" else None
    except Exception:
        return None


def semantic_report():
    """Evidence report of opcode semantics from what the lift observed (semantics.py)."""
    from obfuscators.luraph_v15_1 import semantics as _SM
    orc = oracle()
    return _SM.report(mappers(), orc if orc else None)


def conformance_report():
    """Replay of the real run through the lifted CFG (conformance.py); {"verdict": "NO_TRACE"} without a trace."""
    from obfuscators.luraph_v15_1 import conformance as _CF
    orc = oracle()
    if not orc:
        return {"verdict": "NO_TRACE", "conformant": None}
    kinds = {(m, s.opcode) for m, x in mappers().items() for s in x.handlers() if s.kind == "RETURN"}
    scrub = {}
    try:
        from obfuscators.luraph_v15_1 import vmmap as _VMM
        with open(STATS["source"], encoding="latin-1") as fh:
            lines = fh.read().split("\n")
        scrub = _CF.scrub_map(mappers(), lines, lambda blk: _VMM.text_of(lines, blk))
    except Exception as ex:                      # diagnostics only
        DIAG.last_error = "scrub map: %s" % ex
    r = _CF.check(orc, DIAG.walk_records, kinds, scrub=scrub)
    r["scrub_opcodes"] = {"%s/%s" % k: v for k, v in sorted(scrub.items())}
    r["verdict"] = "CONFORMANT" if r["conformant"] else "NOT_CONFORMANT"
    return r


def mappers():
    """Opcode mappers of the script being lifted (lazy: parses the source once)."""
    src = STATS["source"]
    if src is None:
        return {}
    if src not in _MAPPERS:
        from obfuscators.luraph_v15_1 import opcode_maps as _OM
        try:
            _MAPPERS[src] = _OM.load(src)
        except Exception:                       # diagnostics only: never break the lift
            _MAPPERS[src] = {}
    return _MAPPERS[src]


def reset():
    KEY_CARRY.clear()
    WALK_MEMORY.clear()
    from obfuscators.luraph_v15_1 import semantics as _SM
    _SM.COLLECTOR.reset()
    DIAG.reset()
    EXPANDER.__init__()
    GRAPH.__init__()
    STATS.update(source=None, unknown_steps=0, steps=0, nodes={}, unknown_ops={})


def _local_node(name, location):
    return {"type": "AstExprLocal", "location": "0,0 - 0,0",
            "local": {"name": name, "location": location, "type": "AstLocal"}}


def _eq_cond(name, location, value):
    return {"type": "AstExprBinary", "location": "0,0 - 0,0", "op": "CompareEq",
            "left": _local_node(name, location),
            "right": {"type": "AstExprConstantNumber", "location": "0,0 - 0,0", "value": value}}


def install(E):
    BaseVM = E.VMModel
    BaseStepper = E.Stepper
    BaseLifter = E.ProtoLifter
    S = E.S
    vmmap = E.vmmap

    # ------------------------------------------------------------------
    class V151VMModel(BaseVM):
        """Maker whose parameters ARE the proto (arrays + scalars)."""
        v151 = True

        def proto_index(self):
            return self.info.get("proto_index", 1)

        def maker_args(self, vmobj, proto, upvals):
            n = len(self.maker["args"])
            vals = [None] * n
            vals[0] = vmobj
            for k, v in proto.h.items():
                if isinstance(k, int) and 0 < k < n:
                    vals[k] = v
            return vals

        def proto_of(self, cap):
            p = cap.get("P")
            return p if p is not None else cap.get("self")

    E.VMModel = V151VMModel

    # ------------------------------------------------------------------
    def _unwrap_factory(self, it, f, vm, upvals):
        """maker(...) returns a closure *factory* in v15.1 (`Q(upvals)` /
        `function(q, G)`); call it until the VM closure comes out."""
        if not getattr(vm, "v151", False):
            return f
        for _ in range(4):
            if not isinstance(f, E.LuaFunc) or f.node is vm.vm:
                return f
            r = it.call_lua(f, E.Multi([upvals, None, None]))
            f = r.first() if isinstance(r, E.Multi) else r
        return f

    BaseLifter._unwrap_factory = _unwrap_factory

    # ------------------------------------------------------------------
    # closure factories: `w[i](upvals, nil, nil)` where w[i] is what a maker
    # returned (envlog `__PQ`: factory -> proto table, dump field "pq")
    _orig_val = E.Dump.val

    def _val(self, v):
        r = _orig_val(self, v)
        if isinstance(r, E.OpaqueFn) and isinstance(v, dict) and "lf" in v:
            pq = v.get("pq")
            if pq is not None and "t" in pq:
                r.pq_tid = pq["t"]
        return r

    E.Dump.val = _val
    E.OpaqueFn.pq_tid = None

    _orig_call_sym = BaseLifter.call_symbolic

    def call_symbolic(self, fn, args, it, stat):
        if getattr(self.vm, "v151", False) and isinstance(fn, E.OpaqueFn) and fn.pq_tid is not None:
            proto = self.dump.tables.get(fn.pq_tid)
            vm = self._vm_of_proto(proto)
            ups = args.items[0] if args.items else None
            pi, ui = vm.proto_index(), vm.upvals_index()
            vals = [None] * (max(pi, ui) + 1)
            vals[pi], vals[ui] = proto, ups
            return self.make_closure(E.Multi(vals), vm)
        return _orig_call_sym(self, fn, args, it, stat)

    def _vm_of_proto(self, proto):
        """VMModel whose maker built `proto` (via the capture record's __maker tag)."""
        for cap in self.dump.protos.values():
            if cap.get("P") is proto or cap.get("self") is proto:
                tag = cap.get("__maker")
                tag = tag.decode("latin-1") if isinstance(tag, bytes) else tag
                for vm in self.vm.siblings.values():
                    if getattr(vm, "tag", None) == tag:
                        return vm
        return self.vm

    BaseLifter.call_symbolic = call_symbolic
    BaseLifter._vm_of_proto = _vm_of_proto

    # ------------------------------------------------------------------
    # v15.1 blob decryption reads/writes the buffer 4 bytes at a time
    # (`j(U,N,X(d(U,N),z))` over the region, then bytes for the tail); v15 only
    # tracks byte accesses path-sensitively. Every fixed-width integer access
    # with concrete operands goes through the same byte overlay here.
    _WIDTH = {"u8": (1, False), "i8": (1, True), "u16": (2, False), "i16": (2, True),
              "u32": (4, False), "i32": (4, True)}
    _orig_buffer_op = BaseLifter.buffer_op

    def buffer_op(self, name, args):
        nm = name.split(".", 1)[1] if "." in name else name
        rw = "read" if nm.startswith("read") else "write" if nm.startswith("write") else None
        w = _WIDTH.get(nm[len(rw):]) if rw else None
        if w is None or len(args) < 2 or not isinstance(args[1], int) or isinstance(args[1], bool):
            return _orig_buffer_op(self, name, args)
        b, off = args[0], args[1]
        size, signed = w
        if off < 0 or off + size > len(b.data):
            raise E.Unsupported("%s out of range (offset %d, size %d)" % (name, off, len(b.data)))
        ov = self.cur_ov()
        if rw == "read":
            v = 0
            for k in range(size):
                v |= ov.get((id(b), off + k), b.data[off + k]) << (8 * k)
            if signed and v >= 1 << (8 * size - 1):
                v -= 1 << (8 * size)
            return v
        if len(args) < 3 or not isinstance(args[2], (int, float)) or isinstance(args[2], bool):
            return _orig_buffer_op(self, name, args)
        val = int(args[2]) & ((1 << (8 * size)) - 1)
        for k in range(size):
            self.write_ov((id(b), off + k), (val >> (8 * k)) & 255, b.data[off + k])
        return E.Multi([])

    BaseLifter.buffer_op = buffer_op

    # ------------------------------------------------------------------
    # A walk restart ("the lifter learned a carried local / jump register")
    # begins again from the entry with the same stepper. v15 keeps the
    # stepper's global overlay (the in-place decryption done so far) and the
    # dump's patch logs across restarts, which is harmless when decryptors
    # store absolute values. v15.1 decryptors are XOR layers (`S[U]=X(S[U],k)`,
    # the buffer region XOR) and applying them twice decrypts garbage, so a
    # restart here replays from the state the first pass started with.
    _orig_walk = E.Program._walk

    # What a walk learns about a proto (jump / link registers, carried locals) is learned again by
    # every later lift of the same proto -- each time through a restart of the whole walk.  Carry it
    # over (same process: the constant-request rounds and the final lift).  Knowledge only grows.
    def _load_seed():
        # developer aid: DEVIRT_V151_SEED=<file> keeps what walks learned across processes (not a product cache)
        path = os.environ.get("DEVIRT_V151_SEED")
        if not path or WALK_MEMORY.get("__seeded__") or not os.path.exists(path):
            return
        WALK_MEMORY["__seeded__"] = True
        try:
            import json
            with open(path) as f:
                for k, v in json.load(f).items():
                    WALK_MEMORY[k] = {a: set(b) for a, b in v.items()}
        except Exception as ex:
            DIAG.last_error = "seed load: %s" % ex

    def _save_seed():
        path = os.environ.get("DEVIRT_V151_SEED")
        if not path:
            return
        try:
            import json
            with open(path, "w") as f:
                json.dump({k: {a: sorted(b) for a, b in v.items()} for k, v in WALK_MEMORY.items()
                           if k != "__seeded__"}, f)
        except Exception as ex:
            DIAG.last_error = "seed save: %s" % ex

    def _seed_walk(lf, st):
        if not PERSIST_ON:
            return
        _load_seed()
        mem = WALK_MEMORY.get(_DH.pkey(lf))
        if not mem:
            return
        lf.link_regs = set(getattr(lf, "link_regs", None) or ()) | mem["link"]
        lf.jump_regs |= mem["jump"]
        if hasattr(st, "carry"):
            st.carry |= mem["carry"]
            st.not_carried |= mem["not_carried"]
            st.read_first |= mem["read_first"]
            st.written |= mem["written"]

    def _remember_walk(lf, st):
        if not PERSIST_ON:
            return
        mem = WALK_MEMORY.setdefault(_DH.pkey(lf), {"link": set(), "jump": set(), "carry": set(),
                                                    "not_carried": set(), "read_first": set(), "written": set()})
        mem["link"] |= set(getattr(lf, "link_regs", None) or ())
        mem["jump"] |= set(lf.jump_regs)
        for attr in ("carry", "not_carried", "read_first", "written"):
            mem[attr] |= set(getattr(st, attr, ()) or ())
        _save_seed()

    def _walk(self, vm, lf, st, limit):
        if getattr(vm, "v151", False):
            DIAG.begin_proto(_DH.pkey(lf))
            _RS.reset(lf)
            st.depth_shapes = {}
            st._v151_seen = set()
            _seed_walk(lf, st)
        if getattr(vm, "v151", False) and hasattr(st, "gov"):
            dump = lf.dump
            snap = getattr(st, "_v151_start", None)
            if snap is None:
                st._v151_start = (dict(dump.buf_patch), dict(dump.tab_patch))
            else:
                for attr, saved in zip(("buf_patch", "tab_patch"), snap):
                    cur = getattr(dump, attr)
                    dirty = set(getattr(cur, "dirty", ()))
                    cur.clear()
                    dict.update(cur, saved)
                    if hasattr(cur, "dirty"):
                        cur.dirty = dirty & set(cur)
                st.gov = _make_gov(st) if PATHOV else E.Overlay()
                lf.ov = None
                lf.ov_base = st.gov
        res = _orig_walk(self, vm, lf, st, limit)
        if getattr(lf.vm, "v151", False) and _RS.has_deferred(lf) and not (len(res) > 2 and res[2]):
            # the walk ended with discoveries still deferred: it is not a result, restart with them
            found = _RS.take_deferred(lf)
            try:
                res[1].info["restart"] = "jump-regs"
                res[1].info["final_stop"] = "restart:jump-regs"
            except Exception:
                pass
            res = (res[0], res[1], True)
            try:
                DIAG.walk_notes.append({"proto": _DH.pkey(lf), "deferred_at_end": sorted(found)})
            except Exception:                          # diagnostics only (synthetic lifters have no dump)
                pass
        if getattr(vm, "v151", False):
            _remember_walk(lf, st)
            _DH.after_walk(self, lf, res[1], bool(res[2]) if len(res) > 2 else False)
            try:
                from obfuscators.luraph_v15_1 import cfg_stats as _CS
                note = _CS.summary(res[1])
                note.update({"proto": _DH.pkey(lf), "restart": res[1].info.get("restart"), "stop": res[1].info.get("final_stop"),
                             "closed": res[1].info.get("closed"), "pending": res[1].info.get("pending"),
                             "link_registers": sorted(getattr(lf, "link_regs", ()) or ())})
                if len(DIAG.walk_notes) < 200:
                    DIAG.walk_notes.append(note)
            except Exception as ex:                     # diagnostics only
                DIAG.last_error = "cfg_stats: %s" % ex
            if not (len(res) > 2 and res[2]):
                rep = _RS.report(lf)
                if rep is not None:
                    DIAG.ret_sites[_DH.pkey(lf)] = rep
            if hasattr(st, "key_locals") and not (len(res) > 2 and res[2]):
                KEY_CARRY[_DH.pkey(lf)] = {"key_locals": len(st.key_locals), "tracked_registers": sorted(st.ktrack),
                                           "persistent_registers": sorted(st.kpersist),
                                           "log": [x for x in st.key_log if "unresolved_local" not in x][:40],
                                           "unresolved_key_writes": sum(1 for x in st.key_log if "unresolved_local" in x)}
        try:
            order = res[1]
            nodes = list(order)
            STATS["nodes"][id(lf)] = (len(nodes), sum(1 for _, n in nodes if getattr(n, "error", None)))
        except Exception:                        # diagnostics only
            pass
        return res

    E.Program._walk = _walk

    # ------------------------------------------------------------------
    # Bounds: a path the walk should not have taken (junk code behind an
    # opaque predicate, an operand that is still encrypted) must end as an
    # unlifted block, never as an allocation of hundreds of millions of cells.
    MAX_RANGE = int(__import__("os").environ.get("DEVIRT_MAX_RANGE", "65536"))
    _orig_call_builtin = BaseLifter.call_builtin

    def call_builtin(self, fn, args, it, stat):
        if getattr(self.vm, "v151", False):
            name = fn.name
            items = args.items
            nums = [x for x in items if isinstance(x, (int, float)) and not isinstance(x, bool)]
            if name in ("buffer.create", "string.rep") and nums and max(nums) > MAX_RANGE * 64:
                raise E.Unsupported("%s of %d (bound %d)" % (name, max(nums), MAX_RANGE * 64))
        return _orig_call_builtin(self, fn, args, it, stat)

    BaseLifter.call_builtin = call_builtin

    _orig_tmove = BaseLifter.tmove

    def tmove(self, a):
        if getattr(self.vm, "v151", False):
            src, f, e, t, dst = (a.items + [None] * 5)[:5]
            if isinstance(f, int) and isinstance(e, int) and e - f + 1 > MAX_RANGE:
                raise E.Unsupported("table.move of %d elements (bound %d)" % (e - f + 1, MAX_RANGE))
        return _orig_tmove(self, a)

    BaseLifter.tmove = tmove

    # ------------------------------------------------------------------
    # diagnostics: source path, closure graph, V151_UNKNOWN
    _orig_prog_init = E.Program.__init__

    def _prog_init(self, source_path, dump_path, chunk_paths=()):
        reset()
        STATS["source"] = source_path
        STATS["dump_path"] = dump_path
        _orig_prog_init(self, source_path, dump_path, chunk_paths)

    E.Program.__init__ = _prog_init

    _orig_lift = E.FunctionLifter.lift
    _stack = []

    def _lift(self, vm, vmobj, proto, upvals, upnames, depth=0):
        key = getattr(proto, "tid", None)
        GRAPH.node("t%s" % key, tid=key, depth=depth)
        _stack.append("t%s" % key)
        try:
            return _orig_lift(self, vm, vmobj, proto, upvals, upnames, depth)
        finally:
            _stack.pop()

    E.FunctionLifter.lift = _lift

    _orig_closure = E.FunctionLifter.closure

    def _closure(self, vm, vmobj, c, parent_names, depth):
        child = getattr(getattr(c, "proto", None), "tid", None)
        if _stack and child is not None:
            GRAPH.edge(_stack[-1], "t%s" % child, len(getattr(c, "upvals", ()) or ()))
        return _orig_closure(self, vm, vmobj, c, parent_names, depth)

    E.FunctionLifter.closure = _closure

    _DH.install(E, DIAG, _stack, mappers, _semantic, oracle)

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # Key locals (round 2).  Handlers of the v15.1 in-place decoders keep their
    # decode key in a prologue local of the VM function (`J=L[R[i]]`).  The v15
    # stepper re-runs the prologue for every instruction, so such a local would
    # silently reset to its initial value and every later in-place decode would
    # use the wrong key.  V151Stepper therefore carries these locals between
    # steps in `State151.keys` (separate from `State.locs`, which the v15 stack
    # logic interprets).  A key local is discovered from evidence only: a
    # prologue local with an integer initial value that is read before being
    # written in one step AND written with a value that differs from its
    # initial value in another.
    class _Unresolved:
        """Key value that could not be reduced to an integer (never guessed)."""
        __slots__ = ()

        def __repr__(self):
            return "<unresolved key>"

    UNRESOLVED = _Unresolved()

    class _Acc151(dict):
        """Scope dict recording read-first / written locals.  `read_first` keeps the
        v15 meaning (subscript reads only); `reads_first` also sees `.get` reads (what
        the interpreter uses), and an UNRESOLVED value raises when it is read."""
        __slots__ = ("read_first", "written", "reads_first")

        def __init__(self, *a):
            dict.__init__(self, *a)
            self.read_first = set()
            self.written = set()
            self.reads_first = set()

        def __getitem__(self, k):
            if k not in self.written:
                self.read_first.add(k)
            return dict.__getitem__(self, k)

        def get(self, k, default=None):
            v = dict.get(self, k, default)
            if k in self and k not in self.written:
                self.reads_first.add(k)
                if v is UNRESOLVED:
                    raise E.Unsupported("V151_KEY_UNRESOLVED: a decode key local carried between "
                                        "instructions has no known integer value")
            return v

        def __setitem__(self, k, v):
            self.written.add(k)
            dict.__setitem__(self, k, v)

    E._AccessLog = _Acc151

    class State151(E.State):
        __slots__ = ("keys", "pend", "kvals")

        def __init__(self, mode, pc, kstack, jregs=(), ov=None, packs=(), locs=(), keys=(), kvals=()):
            E.State.__init__(self, mode, pc, kstack, jregs, ov, packs, locs)
            self.kvals = kvals           # tracked register constants (see _track_emit)
            self.keys = keys
            self.pend = keys            # as produced by the step (may hold _DF.Pending values)

        def key(self, link):
            k = E.State.key(self, link)
            if DEPTH_WIDEN and k[2] > DEPTH_WIDEN:
                k = k[:2] + (DEPTH_WIDEN,) + k[3:]          # widening: depths above the bound are one abstract state
            return k + (self.keys, self.kvals)

        @classmethod
        def of(cls, st, keys, kvals=()):
            return cls(st.mode, st.pc, st.kstack, st.jregs, st.ov, st.packs, st.locs, keys, kvals)

    E.State151 = State151

    class _NoUpdate(dict):
        def update(self, *a, **k):          # the stepper's global merge of a step's writes: replaced by the state's own overlay
            pass

    class _GovProxy(E.Overlay):
        """Read-through view of the overlay of the state being stepped (the stepper's `gov`)."""
        __slots__ = ("stepper", "_d")

        def __init__(self, stepper):
            self.stepper = stepper
            self._d = _NoUpdate()

        d = property(lambda self: self._d, lambda self, v: None)
        parent = property(lambda self: self.stepper.cur_ov, lambda self, v: None)
        h = property(lambda self: self.stepper.cur_ov.h, lambda self, v: None)
        depth = property(lambda self: self.stepper.cur_ov.depth + 1, lambda self, v: None)

    def _make_gov(stepper):
        return _GovProxy(stepper)

    E._GovProxy = _GovProxy
    E._make_gov = _make_gov
    E.UNRESOLVED = UNRESOLVED

    # -- tracked register constants -------------------------------------------------
    # Registers a decode key is loaded from (and, transitively, the registers that
    # produced them) are tracked path-sensitively: their constant value is part of the
    # state (like v15's jump registers) so paths that load different constants are not
    # merged.  Only evidence-driven: a register is tracked after a key load / a call
    # needed it, never speculatively.
    BaseLifter.kvals = None
    _orig_emit = BaseLifter.emit

    def _kconst(self, x):
        """Known constant value of an IR operand while tracking: (value,) or None."""
        if isinstance(x, E.Const):
            return (x.v,)
        if isinstance(x, E.Reg) and x.n in self.kvals:
            return (self.kvals[x.n],)
        if isinstance(x, E.Reg):
            self.kneed.add(x.n)
        return None

    def _track_emit(self, st):
        kv = self.kvals
        if isinstance(st, E.CallStmt):
            fn = None
            if isinstance(st.fn, E.Global):
                fn = ("fn", st.fn.name)
            elif isinstance(st.fn, E.Reg):
                fn = kv.get(st.fn.n)
                if fn is None:
                    self.kcallneed.setdefault(st.t, set()).add(st.fn.n)
            res = None
            if fn is not None and isinstance(fn, tuple) and fn[0] == "fn" and _DF.pure_name(fn[1]) \
                    and st.args.tail is None:
                vals, miss = [], set()
                for a in st.args.items:
                    if isinstance(a, E.Const):
                        vals.append(a.v)
                    elif isinstance(a, E.Reg) and a.n in kv:
                        vals.append(kv[a.n])
                        self.kconsumed.add(a.n)
                    elif isinstance(a, E.TempVal) and a.t in self.ktres and 0 < a.i <= len(self.ktres[a.t]):
                        vals.append(self.ktres[a.t][a.i - 1])
                    else:
                        miss.add(a.n if isinstance(a, E.Reg) else None)
                if not miss:
                    try:
                        r = E.S.CONCRETE[fn[1]](*vals)
                        res = tuple(r) if isinstance(r, (tuple, list)) else (r,)
                    except Exception:
                        res = None
                else:
                    self.kcallneed.setdefault(st.t, set()).update(x for x in miss if x is not None)
            if res is not None:
                self.ktres[st.t] = res
            return
        if not (isinstance(st, E.Assign) and isinstance(st.target, E.Reg)):
            return
        n, v = st.target.n, st.value
        if n not in self.ktrack:
            return
        val = None
        if isinstance(v, E.Const):
            val = (v.v,)
        elif isinstance(v, E.Reg):
            val = (kv[v.n],) if v.n in kv else None
            if val is None:
                self.kneed.add(v.n)
            else:
                self.kconsumed.add(v.n)
        elif isinstance(v, E.Global) and _DF.pure_name(v.name):
            val = (("fn", v.name),)
        elif isinstance(v, E.TempVal):
            if v.t in self.ktres and 0 < v.i <= len(self.ktres[v.t]):
                val = (self.ktres[v.t][v.i - 1],)
            else:
                self.kneed |= self.kcallneed.get(v.t, set())
        if val is None:
            kv.pop(n, None)
        else:
            kv[n] = val[0]

    def emit(self, st):
        if self.kvals is not None:
            try:
                _track_emit(self, st)
            except Exception as ex:
                DIAG.last_error = "track hook: %s: %s" % (type(ex).__name__, ex)
        r = _orig_emit(self, st)
        if RETSITE_ON:
            _RS.note_assign(self, st, E.Assign)         # link-register writes reach the output
        return r

    BaseLifter.emit = emit

    # -- lowering budget -------------------------------------------------------------
    # codegen's liveness keeps a register set per block: blocks x registers entries.  A walk of
    # a program with outlined helpers (one clone per return address) can reach hundreds of
    # millions and gets the process killed.  Stop with a diagnosed, honest failure instead.
    class _BackendProxy:
        def __init__(self, real):
            self._real = real

        def __getattr__(self, name):
            return getattr(self._real, name)

        def lower(self, entry, order, me, link, prefix, upnames, conv):
            regs = set()
            for _k, node in order:
                stack = [node]
                while stack:
                    x = stack.pop()
                    if x is None:
                        continue
                    for st in x.stmts:
                        if isinstance(st, E.Assign) and isinstance(st.target, E.Reg):
                            regs.add(st.target.n)
                    stack.append(getattr(x, "then", None))
                    stack.append(getattr(x, "els", None))
            product = len(order) * len(regs)
            if product > LOWER_BUDGET or len(order) > LOWER_BLOCKS:
                info = getattr(order, "info", {}) or {}
                DIAG.budget_hits.append({"blocks": len(order), "registers": len(regs), "product": product,
                                         "budget": LOWER_BUDGET, "max_blocks": LOWER_BLOCKS, "walk": {k: info.get(k) for k in
                                         ("limit", "first_stop", "final_stop", "rounds", "pending", "total", "closed")}})
                raise E.Unsupported("V151_LOWER_BUDGET: %d blocks x %d registers = %d exceeds the lowering budget %d "
                                    "(DEVIRT_LOWER_BUDGET) or the block ceiling %d (DEVIRT_LOWER_BLOCKS); "
                                    "the CFG is too large to lower" % (len(order), len(regs), product, LOWER_BUDGET, LOWER_BLOCKS))
            try:
                return self._real.lower(entry, order, me, link, prefix, upnames, conv)
            except MemoryError:
                DIAG.budget_hits.append({"blocks": len(order), "registers": len(regs), "product": product,
                                         "budget": LOWER_BUDGET, "memory_error": True})
                raise E.Unsupported("V151_LOWER_MEMORY: out of memory lowering %d blocks x %d registers "
                                    "(liveness sets); the CFG is too large to lower" % (len(order), len(regs)))

    E.backend = _BackendProxy(E.backend)

    # -- facts: pure builtins over constants, and key resolution ------------------
    _orig_apply = E.apply_stmt_facts
    _TEMPS = {}

    def apply_stmt_facts(st, facts, lf):
        _orig_apply(st, facts, lf)
        try:
            if isinstance(st, E.Assign) and isinstance(st.target, E.Reg):
                v = st.value
                if isinstance(v, E.Global) and _DF.pure_name(v.name):
                    facts[st.target.n] = ("t", v)          # a pure builtin (truthy), kept as a fact
                elif isinstance(v, E.TempVal) and v.t in _TEMPS and 0 < v.i <= len(_TEMPS[v.t]):
                    r = _TEMPS[v.t][v.i - 1]
                    if r is None or isinstance(r, (int, float, bytes, bool)):
                        facts[st.target.n] = ("c", r)
            elif isinstance(st, E.CallStmt) and isinstance(st.fn, E.Reg) and st.args.tail is None:
                r = _DF.fold_call(facts.get(st.fn.n), list(st.args.items), facts, E)
                if r is not None:
                    _TEMPS[st.t] = r
                else:
                    _TEMPS.pop(st.t, None)
        except Exception as ex:                     # facts are an optimisation of knowledge, never fatal
            DIAG.last_error = "facts hook: %s: %s" % (type(ex).__name__, ex)

    E.apply_stmt_facts = apply_stmt_facts

    _orig_index = BaseLifter.index

    def _index(self, obj, key, it):
        try:
            r = _orig_index(self, obj, key, it)
            if isinstance(r, _RS.LinkTok):
                return E.Reg(E.S.norm_key(key) if not isinstance(key, E.Expr) else key.n)
            return r
        except TypeError as ex:
            # a symbolic value where the v15 table logic needs a number (e.g. an in-place
            # decoded field that depends on an unresolved key): a failed step, not a crash
            raise E.Unsupported("V151_SYMBOLIC_VALUE: %s" % ex)

    BaseLifter.index = _index

    _prev_propagate = E.propagate
    KEY_RESOLVE_LOG = {}
    E.KEY_RESOLVE_LOG = KEY_RESOLVE_LOG

    def propagate(node, facts, succ, lf):
        f0 = dict(facts)
        n0 = len(succ)
        r = _prev_propagate(node, facts, succ, lf)
        try:
            wr = None
            for ns, _nf in succ[n0:]:
                pend = getattr(ns, "pend", None)
                if not pend or not any(isinstance(v, _DF.Pending) for _, v in pend):
                    continue
                if wr is None:
                    wr = _DF.written_regs(node)
                out = []
                for k, v in pend:
                    if isinstance(v, _DF.Pending):
                        regs = {x.n for x in E.expr_regs(v.expr)}
                        val = _DF.eval_int(v.expr, f0, E) if not (regs & wr) else None
                        if val is None:
                            kl = KEY_RESOLVE_LOG
                            ck = (str(k), v.text, "written-in-step" if (regs & wr) else "no-const-fact",
                                  str(f0.get(next(iter(regs)))) if regs else "-")
                            kl[ck] = kl.get(ck, 0) + 1
                        v = val if val is not None else _DF.SymKey(v.kreg)
                    out.append((k, v))
                ns.keys = tuple(out)
        except Exception as ex:
            DIAG.last_error = "key resolution: %s: %s" % (type(ex).__name__, ex)
        return r

    E.propagate = propagate

    def _v151_successors(prog, lf, k, node, succ, facts, work, inwork, nodes, states):
        if not RETSITE_ON or not getattr(lf.vm, "v151", False):
            return succ
        return _RS.successors(prog, lf, k, node, succ, facts, work, inwork, nodes, states, E.propagate, E.Node, E.Next)

    E._v151_successors = _v151_successors

    def _v151_pick(work, st):
        """Next state of the (non-recovery) walk.  `lifo` = v15's order.  `fifo` = breadth first (every lineage advances in
        lockstep).  `novel` = LIFO, but a state at an instruction no earlier step has visited is taken first (looked for in the
        newest NOVEL_WINDOW entries).  The fixed point does not depend on the order; the budget-limited result does."""
        if ORDER == "lifo":
            return work.pop()
        if ORDER == "fifo":
            return work.pop(0)
        seen = st.__dict__.setdefault("_v151_seen", set())
        for j in range(len(work) - 1, max(-1, len(work) - 1 - NOVEL_WINDOW), -1):
            c = work[j]
            if (c[0], c[1]) not in seen:
                work.pop(j)
                seen.add((c[0], c[1]))
                return c
        c = work.pop()
        seen.add((c[0], c[1]))
        return c
    E._v151_pick = _v151_pick
    E._v151_defer_regs = _RS.defer_regs
    E._v151_defer_due = _RS.defer_due
    E._v151_defer_packs = _RS.defer_packs
    E._v151_take_deferred = _RS.take_deferred

    MAX_UNPACK = int(os.environ.get("DEVIRT_V151_MAX_UNPACK", "1024") or 0)

    def _v151_unpack_guard(lf, i, j):
        if MAX_UNPACK and j - i + 1 > MAX_UNPACK:
            DIAG.note_unpack_overflow(i, j, MAX_UNPACK)
            raise E.Unsupported("unpack of %d registers (%d..%d) exceeds the register-file bound %d: "
                                "operand of another record decoded as an argument count" % (j - i + 1, i, j, MAX_UNPACK))

    E._v151_unpack_guard = _v151_unpack_guard

    class V151Stepper(BaseStepper):
        """Dispatch loops selected by `if F==K`, `M=F==K; if M` or, in the
        legacy-shaped maker, `if c==K then i,E=U,c; while ... end`."""

        def __init__(self, vm, lifter):
            self.vm = vm
            self.lf = lifter
            self.cs = lifter.initial_state()
            body = vm.inner_body
            disp_by_node = {}
            raw = []                       # (index, if stmt, [pre stmts], while, [post stmts], mode info)
            for i, st in enumerate(body):
                if st["type"] != "AstStatIf":
                    continue
                tb = st["thenbody"]["body"]
                k = next((j for j, s in enumerate(tb) if s["type"] == "AstStatWhile" and vm.is_dispatch(s)), None)
                if k is None:
                    continue
                raw.append((i, st, tb[:k], tb[k], tb[k + 1:]))
            if not raw:
                raise E.Unsupported("no dispatch loops in the VM function")
            # mode variable: the declaration most loops test (after `M=F==K` resolution)
            modes = []
            for i, st, pre, w, post in raw:
                mt = vmmap._mode_test(st["condition"], body, i)
                modes.append(mt)
            counts = {}
            for mt in modes:
                if mt is not None:
                    counts[mt[0]["location"]] = counts.get(mt[0]["location"], 0) + 1
            if not counts:
                raise E.Unsupported("dispatch loops without a recognisable mode test")
            mode_loc = max(counts, key=counts.get)
            mode_local = next(mt[0] for mt in modes if mt is not None and mt[0]["location"] == mode_loc)
            self.loops, self.conds, self.init_stmts = [], {}, []
            for (i, st, pre, w, post), mt in zip(raw, modes):
                if mt is None:
                    raise E.Unsupported("dispatch loop %s has no mode test" % st["location"])
                cond = _eq_cond(mode_local["name"], mode_loc, mt[1])
                syn = {"type": "AstStatIf", "location": st["location"], "condition": cond,
                       "thenbody": {"type": "AstStatBlock", "location": st["thenbody"]["location"],
                                    "body": [w] + list(post)},
                       "elsebody": None}
                self.loops.append((i, syn, w))
                self.conds[i] = cond
                if pre and not self.init_stmts:
                    self.init_stmts = list(pre)
            self.mode_decl = mode_loc
            wnode = self.loops[0][2]
            self.pc_decl = wnode["body"]["body"][0]["values"][0]["index"]["local"]["location"]
            self.first_inner = self.loops[0][0]
            self._ov_empty = E.Overlay()
            self.cur_ov = self._ov_empty
            self.gov = _make_gov(self) if PATHOV else E.Overlay()
            self.carry = set()
            self.read_first = set()
            self.written = set()
            self.not_carried = set()
            self.new_carry = False
            self.fixed_decls = {d for d in (self.pc_decl, self.mode_decl, vm.kstack_key) if d}
            self.sp_cands = self._stack_pointer_candidates()
            if not hasattr(vm, "_mode_loop_cache"):
                vm._mode_loop_cache = {}
            self._mode_loop_cache = vm._mode_loop_cache
            self.key_locals = set()          # decode-key locals carried in State151.keys
            self.key_seen_read = set()       # prologue locals read before written in some step
            self.key_seen_diff = {}          # local -> a value that differed from its initial one
            self.key_rejected = set()
            self._pvals = None
            self.ktrack = set()              # registers whose constant value is tracked in the state
            self.kpersist = set()            # tracked registers whose value is kept after it was read
            self.kdropped = set()            # tracked registers whose value was dropped after being read
            self.key_log = []                # evidence for the diagnostics (never used for decisions)

        # -- key locals ---------------------------------------------------
        def _prologue_vals(self):
            if self._pvals is None:
                _, inner = BaseStepper._fresh_scopes(self, None, S.Interp(self.lf))
                if self.init_stmts:
                    S.Interp(self.lf).exec_block(self.init_stmts, inner)
                self.lf.out = []
                self._pvals = {k: v for k, v in dict.items(inner.vars)}
            return self._pvals

        def _kreg(self, k):
            return _DF.KEY_REG_BASE + sorted(self.key_locals).index(k)

        def _key_tuple(self, acc):
            """Key values at the end of a step.  An expression over registers is copied into
            the key's virtual register (emitted into the step) and carried as Pending; the
            walk resolves it against the facts (propagate)."""
            out = []
            pv = self._prologue_vals()
            lf = self.lf
            written = {st.target.n for st in lf.out if isinstance(st, E.Assign) and isinstance(st.target, E.Reg)}
            for k in sorted(self.key_locals):
                v = dict.get(acc, k, pv.get(k))
                kreg = self._kreg(k)
                if isinstance(v, int) and not isinstance(v, bool):
                    out.append((k, v))
                elif isinstance(v, E.Reg) and v.n == kreg:
                    out.append((k, _DF.SymKey(kreg)))                # untouched symbolic key
                elif isinstance(v, E.Reg) and v.n not in written and isinstance(lf.kvals.get(v.n), int) \
                        and not isinstance(lf.kvals.get(v.n), bool):
                    out.append((k, lf.kvals[v.n]))                  # known by the tracked constants
                    lf.kconsumed.add(v.n)
                elif isinstance(v, (E.Reg, E.Const)) and not ({r.n for r in E.expr_regs(v)} & written):
                    if isinstance(v, E.Reg):
                        lf.kneed.add(v.n)
                    if KVALS_ON and isinstance(v, E.Reg) and v.n not in self.ktrack:
                        self.ktrack.add(v.n)                          # track it from now on (restart)
                        self.new_carry = True
                        self.key_log.append({"track": [v.n], "at": lf.last_op, "for_key": str(k)})
                    lf.out.append(E.Assign(E.Reg(kreg), v))
                    out.append((k, _DF.Pending(v, E.fmt_any(v), kreg)))
                else:
                    out.append((k, UNRESOLVED))
                    if len(self.key_log) < 200:
                        self.key_log.append({"unresolved_local": str(k),
                                             "value": E.fmt_any(v) if isinstance(v, E.Expr) else repr(v),
                                             "op": lf.last_op})
            return tuple(out)

        def initial(self):
            st = BaseStepper.initial(self)
            pv = self._prologue_vals()
            return State151.of(st, tuple((k, pv[k]) for k in sorted(self.key_locals)))

        def _begin_run(self, state):
            lf = self.lf
            lf.link_new = {}
            lf.kvals = dict(getattr(state, "kvals", ()) or ()) if state is not None else {}
            lf.ktrack = self.ktrack
            lf.kneed = set()
            lf.kconsumed = set()
            lf.kcallneed = {}
            lf.ktres = {}

        def _note_access(self, acc):
            self._last_acc = acc
            BaseStepper._note_access(self, acc)
            if getattr(self, "no_carry", False):
                return
            pv = self._prologue_vals()
            isint = lambda v: isinstance(v, int) and not isinstance(v, bool)
            for k in acc.reads_first:
                if k in pv and isint(pv[k]) and k not in self.fixed_decls and k not in self.sp_cands:
                    self.key_seen_read.add(k)
            for k in acc.written:
                if k not in pv or not isint(pv[k]) or k in self.fixed_decls or k in self.sp_cands \
                        or k in self.lf.special or k in self.key_rejected:
                    continue
                v = dict.get(acc, k)
                if isint(v) and v == pv[k]:
                    continue
                if isint(v):
                    self.key_seen_diff.setdefault(k, v)
                elif isinstance(v, E.Expr):
                    self.key_seen_diff.setdefault(k, v)
            for k in (self.key_seen_read & set(self.key_seen_diff)) - self.key_locals:
                self.key_locals.add(k)
                self.key_log.append({"local": str(k), "initial": pv[k],
                                     "first_written_value": E.fmt_any(self.key_seen_diff[k])
                                     if isinstance(self.key_seen_diff[k], E.Expr) else self.key_seen_diff[k]})
                self.new_carry = True

        def _depth_guard(self, state):
            """Quarantine of an unbounded loop-stack growth (see DEPTH_CAP); raises Unsupported."""
            k = state.key(self.vm.kstack_link)
            shape = (k[0], k[1]) + tuple(k[3:])
            seen = self.depth_shapes.setdefault(shape, set())
            d = k[2]
            if d in seen:
                return
            if len(seen) >= DEPTH_CAP:
                DIAG.note_depth_growth(_DH.pkey(self.lf), state.mode, state.pc, len(seen), d)
                raise E.Unsupported("stack depth growth at %s:%s: %d distinct loop-stack depths with identical jump registers, "
                                    "overlay, packs, locals and decode keys (unbounded push loop; states above depth cap %d not stepped)"
                                    % (state.mode, state.pc, len(seen), DEPTH_CAP))
            seen.add(d)

        def step(self, state, tprefix):
            EXPANDER.begin_step(state.mode, state.pc)
            STATS["steps"] += 1
            _DH.on_step_start(self.lf, state)
            try:
                if DEPTH_CAP:
                    self._depth_guard(state)
                node = BaseStepper.step(self, state, tprefix)
                _DH.on_step_ok(self.lf, state, node)
                return node
            except E.Unsupported as ex:
                msg = str(ex)
                if not msg.startswith("V151_UNKNOWN"):
                    op = self.lf.last_op
                    mode, opcode = (op if op else (state.mode, None))
                    msg = _IR.unknown_text(mappers().get(mode), mode, opcode, msg)
                STATS["unknown_steps"] += 1
                op = self.lf.last_op
                k = tuple(op) if op else (state.mode, None)
                STATS["unknown_ops"][k] = STATS["unknown_ops"].get(k, 0) + 1
                _DH.on_step_error(self.lf, state, msg, op)
                raise E.Unsupported(msg)

        def run_once(self, state, dec, tprefix):
            self._begin_run(state)
            if PATHOV:
                self.cur_ov = state.ov if (state is not None and state.ov is not None) else self._ov_empty
            it, oc = BaseStepper.run_once(self, state, dec, tprefix)
            lf = self.lf
            if PATHOV and isinstance(oc, E.Next):
                w = getattr(lf, "ov", None)
                eff = self.cur_ov
                if w is not None and w.d:
                    eff = E.Overlay(self.cur_ov)
                    eff.d = w.d
                    eff.h = w.h
                    eff = eff.flattened()
                oc.state.ov = None if eff is self._ov_empty else eff
            if getattr(lf, "mutated", False) and isinstance(oc, E.Next) and oc.state.pc == state.pc:
                ov = lf.ov.d if getattr(lf, "ov", None) is not None else {}
                fp = (lf.last_op, tuple(sorted((k[1], repr(v)) for k, v in ov.items()
                                               if isinstance(k, tuple) and len(k) == 2 and k[1] == state.pc))[:16])
                try:
                    _DH.on_expansion(lf, state, ov)
                    EXPANDER.record(state.mode, state.pc, lf.last_op[1] if lf.last_op else None, fp)
                except _IE.ExpansionLimit as ex:
                    raise E.Unsupported("instruction expansion: %s" % ex)
            if isinstance(oc, E.Next) and not isinstance(oc.state, State151):
                keys = self._key_tuple(getattr(self, "_last_acc", {}))
                new = (lf.kneed - self.ktrack) if KVALS_ON else set()
                back = ((lf.kneed & self.kdropped) - self.kpersist) if KVALS_ON else set()
                if new or back:
                    self.ktrack |= new
                    self.kpersist |= back
                    self.new_carry = True
                    self.key_log.append({"track": sorted(new), "persist": sorted(back), "at": lf.last_op})
                keep = {n: v for n, v in lf.kvals.items() if n in self.ktrack}
                for n in list(keep):
                    if n in lf.kconsumed and n not in self.kpersist:
                        del keep[n]                      # read once: not part of the state any more
                        self.kdropped.add(n)
                kv_t = tuple(sorted(keep.items()))
                if RETSITE_ON and _HS.ON:
                    _HS.note_step(lf, _RS.of(lf), state, oc.state, keys, kv_t, len(lf.out), len(it.dlog), getattr(self.vm, "kstack_link", None))
                if RETSITE_ON:
                    lf.v151_frame = (keys, kv_t)          # decode keys / tracked constants of the successor: part of the entry context
                    try:
                        oc.state = _RS.finish_state(lf, state, oc.state)
                    finally:
                        lf.v151_frame = ()
                nst = State151.of(oc.state, keys, kv_t)
                oc.state = nst
            return it, oc

        def _fresh_scopes(self, state, it):
            cs, inner = BaseStepper._fresh_scopes(self, state, it)
            if state is None and self.init_stmts:
                it.exec_block(self.init_stmts, inner)
            if state is not None:
                for k, v in getattr(state, "keys", ()):
                    if k in self.key_locals:
                        if isinstance(v, _DF.SymKey):
                            v = E.Reg(v.kreg)
                        dict.__setitem__(inner.vars, k, v)
            return cs, inner

    _orig_make = E.make_stepper

    def make_stepper(vm, lifter):
        if getattr(vm, "v151", False):
            return V151Stepper(vm, lifter)
        return _orig_make(vm, lifter)

    E.make_stepper = make_stepper
    E.V151Stepper = V151Stepper

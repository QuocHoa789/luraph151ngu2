"""`--debug-v151` report (Phase 8).

Prints, to stderr, what the v15.1 backend found and did::

    [V15.1] detected: yes (header ...)
    [V15.1] backend mode(s): 40,56,73,97,118,142,217,239   (2 makers: legacy-shaped, predicate-shaped)
    [V15.1] dispatcher(s): 8 (direct=4, predicate=4)
    [V15.1] opcode count: 8 modes, 583 handlers, 0 without a rule
    [V15.1] stream decoded: 34 protos, 25854 instructions (from the harness dump)
    [V15.1] expansions: ...
    [V15.1] unknown opcodes: ...
    [V15.1] closures recovered: ...
    [V15.1] IR instructions: ...

Static facts come from the AST (``vmmap``, ``opcode_maps``, ``bootstrap``);
the stream and closure facts from the dump the dynamic harness wrote
(``stream_decoder.DumpStreams``, ``closure.from_dump``); the expansion /
unknown-opcode / IR numbers from the live engine counters
(``engine_patch.STATS``) when the lifter ran in this process, otherwise they
are reported as "n/a (lifter did not run in this process)" - never invented.

Usage:  python3 debug_report.py SOURCE.lua [DUMP.protos.json]
"""
import os
import sys

_CORE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _CORE not in sys.path:
    sys.path.insert(0, _CORE)

from obfuscators.luraph_v15_1 import vmmap as VM                 # noqa: E402
from obfuscators.luraph_v15_1 import opcode_maps as OM           # noqa: E402
from obfuscators.luraph_v15_1 import bootstrap as BS             # noqa: E402

P = "[V15.1] "


def report_lines(source_path, dump_path=None, engine=None):
    """List of report lines.  `engine` is the `engine_patch` module (or None)."""
    lines = []
    with open(source_path, encoding="latin-1") as f:
        src = f.read()
    head = src[:500]
    import re
    m = re.search(r"Luraph Obfuscator v(\d+)(?:\.(\d+))?", head)
    try:
        root = VM.load_ast(source_path)
        backs = VM.detect_v151_backend(root)
        disps = VM.find_dispatchers(root)
        makers = VM.maker_info(root)
    except Exception as ex:                                    # never break the run for diagnostics
        return [P + "detected: no (%s: %s)" % (type(ex).__name__, ex)]
    shape = "yes" if backs else "no"
    lines.append(P + "detected: %s (header %s)" % (
        shape, ("v%s.%s" % (m.group(1), m.group(2) or "0")) if m else "absent; structural detection only"))
    modes = sorted(b.mode for b in backs if b.mode is not None)
    lines.append(P + "backend mode: %s  (%d makers: %s)" % (
        ",".join(map(str, modes)) or "none", len(makers),
        ", ".join("%s/%d params" % (mk["kind"], len(mk["maker"]["args"])) for mk in makers)))
    lines.append(P + "dispatcher: %d (direct=%d, predicate=%d)" % (
        len(disps), sum(1 for d in disps if d["form"] == "direct"), sum(1 for d in disps if d["form"] == "predicate")))
    mp = OM.build_mappers(root, src.split("\n"))
    nh = sum(len(x.handlers()) for x in mp.values())
    unk = sum(1 for x in mp.values() for s in x.handlers() if not s.known)
    kinds = {}
    for x in mp.values():
        for s in x.handlers():
            kinds[s.kind] = kinds.get(s.kind, 0) + 1
    lines.append(P + "opcode count: %d handlers in %d modes (%d without a rule); kinds: %s" % (
        nh, len(mp), unk, ", ".join("%s=%d" % kv for kv in sorted(kinds.items(), key=lambda kv: -kv[1]))))
    bs = BS.analyze(root)
    if bs.get("found"):
        lines.append(P + "bootstrap: entry %s, %d step methods, blob %s chars, confidence %.2f" % (
            bs["entry"], len(bs["step_methods"]), (bs["blob"] or {}).get("length"), bs["confidence"]))
    else:
        lines.append(P + "bootstrap: not found")

    if dump_path and os.path.exists(dump_path):
        try:
            from obfuscators.luraph_v15_1 import stream_decoder as SD
            from obfuscators.luraph_v15_1 import closure as CL
            ds = SD.DumpStreams(dump_path)
            lines.append(P + "stream decoded: %d protos, %d instructions (read from the harness dump, state at proto creation)" % (
                len(ds), ds.total_instructions()))
            g = CL.from_dump(dump_path).summary()
            lines.append(P + "closures recovered: %d (from the dump) over %d protos, %d root(s), depth %d, recursive %d" % (
                g["closures"], g["protos"], g["roots"], g["depth"], g["recursive"]))
        except Exception as ex:
            lines.append(P + "stream decoded: failed (%s: %s)" % (type(ex).__name__, ex))
    else:
        lines.append(P + "stream decoded: n/a (no harness dump)")

    st = getattr(engine, "STATS", None) if engine is not None else None
    if st and st.get("steps"):
        ex = engine.EXPANDER.summary()
        lines.append(P + "expansions: %d events, %d distinct opcodes, %d limit hit(s)" % (
            ex["expansions"], ex["distinct_ops"], ex["limit_hits"]))
        uo = st["unknown_ops"]
        top = sorted(uo.items(), key=lambda kv: -kv[1])[:6]
        lines.append(P + "unknown opcodes: %d step(s) not lifted, %d distinct (mode,opcode): %s" % (
            st["unknown_steps"], len(uo), ", ".join("%s:%s x%d" % (k[0], k[1], c) for k, c in top) or "none"))
        g2 = engine.GRAPH.summary()
        lines.append(P + "closures lifted: %d edges over %d protos (depth %d)" % (g2["closures"], g2["protos"], g2["depth"]))
        n = sum(a for a, _ in st["nodes"].values())
        e = sum(b for _, b in st["nodes"].values())
        lines.append(P + "IR instructions: %d state(s) in %d walked function(s), %d unlifted" % (n, len(st["nodes"]), e))
    else:
        lines.append(P + "expansions / unknown opcodes / IR instructions: n/a (lifter did not run in this process)")
    return lines


def main(argv):
    if len(argv) < 2:
        print("usage: debug_report.py SOURCE.lua [DUMP.protos.json]")
        return 2
    for ln in report_lines(argv[1], argv[2] if len(argv) > 2 else None):
        print(ln)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

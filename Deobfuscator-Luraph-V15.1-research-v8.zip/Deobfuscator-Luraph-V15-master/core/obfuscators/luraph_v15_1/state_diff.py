"""State-difference diagnostics (phase 8, phase B): WHICH components of two walk states differ, and what each
difference means.

A walk state key is `(mode, pc, depth, jregs, ov_hash, packs, locs, keys, kvals)` (see engine_patch.State151).
Two states of the same instruction are separate worklist entries because at least one component differs.  This module
reports exactly which, with the values, so a convergence policy can be argued from evidence instead of guessed:

    produced   where the component gets its value (which kind of step writes it)
    read       what reads it (which step kinds can observe it)
    observable can the code running next distinguish the two values?       (evidence: helper read/write sets, liveness)
    effect     what the difference changes downstream
    param      can it be an explicit input/output parameter of a summary instead of part of the identity?
    genuine    genuine difference of the program state, or tracking that is unnecessarily concrete?

The `semantics` table is source-derived (what each component IS in the stepper) and is the same for every sample; the
`observable` / `genuine` verdicts are computed from the evidence handed in (`facts` = helpersum read/write observations,
`live` = decode-key liveness) and say "unknown" when no evidence was supplied.  No pc, register number or address is
special-cased, and nothing here merges states: it only explains them.
"""

COMPONENTS = ("mode", "pc", "depth", "jregs", "ov", "packs", "locs", "keys", "kvals")

SEMANTICS = {
    "mode": {
        "produced": "dispatch-loop selector written by mode-changing handlers",
        "read": "every step (selects the dispatcher and so the opcode decode)",
        "param": "no: part of the program counter",
        "genuine": "always genuine (different code is executed)",
    },
    "pc": {
        "produced": "every step", "read": "every step",
        "param": "no: the node identity itself",
        "genuine": "always genuine",
    },
    "depth": {
        "produced": "loop-stack push/pop handlers (kstack length)",
        "read": "handlers that pop (return to the loop's continuation) and anything reading the stack top",
        "param": "yes, as a bounded context (loop-stack frames are a continuation); unbounded growth is quarantined (DEPTH_CAP)",
        "genuine": "genuine when the code can pop below the pushed frame; concrete when the frame is only carried",
    },
    "jregs": {
        "produced": "constant loads / arithmetic on registers later consumed as `pc = reg + c` (link registers, jump tables)",
        "read": "register-indirect transfers; a link register read by a return",
        "param": "yes: a link value is the helper's return-continuation input (retsite tokens / helper summaries)",
        "genuine": "genuine for the continuation (where the helper returns); concrete when the helper never reads the register",
    },
    "ov": {
        "produced": "in-place decryptor / expander handlers writing instruction cells (path-sensitive overlay)",
        "read": "the dispatcher's instruction fetch of every cell the overlay holds",
        "param": "no, but equal content from different paths hashes equal (merged); layers applied in another order merge",
        "genuine": "genuine when a cell the running code will fetch differs (different decode); otherwise cells never fetched again",
    },
    "packs": {
        "produced": "table.pack / vararg handlers (register file snapshots of known length)",
        "read": "unpack / select handlers",
        "param": "yes, as the packed length (not the contents) when contents are symbolic",
        "genuine": "genuine when an unpack reads it",
    },
    "locs": {
        "produced": "carried VM locals other than decode keys", "read": "handlers that reference the local",
        "param": "yes (explicit carried input)", "genuine": "genuine when read before being overwritten",
    },
    "keys": {
        "produced": "decode-key locals set by key-load handlers (e.g. `Z = L[R[i]]`) and by the stream decoder",
        "read": "instruction decryptors seeded by the key, operand decoding of key-dependent cells",
        "param": "yes: decode keys are explicit carried values; dead ones (never read before rewritten) need not separate states",
        "genuine": "genuine when a later decryptor / decode reads the key before it is rewritten; concrete otherwise",
    },
    "kvals": {
        "produced": "tracked register constants feeding a key load",
        "read": "the key load that consumed it", "param": "yes (summary input)",
        "genuine": "concrete after the single consuming read",
    },
}


def _shown(v, n=48):
    t = str(v)
    return t if len(t) <= n else t[:n - 3] + "..."


def _as_map(pairs):
    out = {}
    for a, b in pairs or ():
        out[str(a)] = b
    return out


def ov_flatten(ov):
    d = {}
    chain = []
    o = ov
    while o is not None:
        chain.append(o)
        o = getattr(o, "parent", None)
    for x in reversed(chain):
        d.update(x.d)
    return d


def ov_diff(a, b, limit=8):
    """Exact differences of two overlays: number of differing entries, the cells, and the first values."""
    fa, fb = ov_flatten(a), ov_flatten(b)
    diff = [k for k in set(fa) | set(fb) if str(fa.get(k)) != str(fb.get(k))]
    cells = sorted({k[1] for k in diff if isinstance(k, tuple) and len(k) == 2 and isinstance(k[1], int)})
    ex = []
    for k in sorted(diff, key=lambda z: (z[1] if isinstance(z, tuple) and isinstance(z[1], int) else -1))[:limit]:
        ex.append({"cell": k[1] if isinstance(k, tuple) else str(k), "a": _shown(fa.get(k, "<pristine>")),
                   "b": _shown(fb.get(k, "<pristine>"))})
    return {"entries": len(diff), "cells": len(cells), "first_cell": cells[0] if cells else None,
            "last_cell": cells[-1] if cells else None, "examples": ex}


def diff_keys(ka, kb, sa=None, sb=None):
    """{component: detail} for the components in which two state keys differ (`sa`/`sb`: the State objects, optional,
    for overlay-level detail)."""
    out = {}
    for i, name in enumerate(COMPONENTS):
        if i >= len(ka) or i >= len(kb):
            continue
        x, y = ka[i], kb[i]
        if name == "ov":
            if x == y:
                continue
            det = {"hash_a": x, "hash_b": y}
            if sa is not None and sb is not None:
                det.update(ov_diff(getattr(sa, "ov", None), getattr(sb, "ov", None)))
            out[name] = det
            continue
        if x == y:
            continue
        if name in ("jregs", "keys", "kvals", "locs", "packs"):
            ma, mb = _as_map(x), _as_map(y)
            out[name] = {r: (_shown(ma.get(r, "<absent>")), _shown(mb.get(r, "<absent>")))
                         for r in sorted(set(ma) | set(mb)) if str(ma.get(r)) != str(mb.get(r))}
        else:
            out[name] = (x, y)
    return out


def explain(diff, facts=None, live=None, mode_pc=None):
    """One answer record per differing component.

    facts : helpersum facts {(mode, pc): {...}} (observed purity of the steps), optional
    live  : set of decode-key names read before rewritten on some path from this state (liveness), optional
    """
    rows = []
    for comp, detail in diff.items():
        sem = SEMANTICS.get(comp, {})
        observable = "unknown (no evidence supplied)"
        verdict = "unknown"
        if comp == "keys" and live is not None and isinstance(detail, dict):
            dead = [k for k in detail if k not in live]
            observable = "no for %s (dead: rewritten before any read)" % dead if dead else "yes (live)"
            verdict = "concrete (dead decode keys)" if dead and len(dead) == len(detail) else "genuine (live decode key)"
        elif facts is not None and mode_pc is not None:
            f = facts.get(tuple(mode_pc))
            if f is not None and f.get("pure") and comp in ("keys", "kvals", "locs", "packs"):
                observable = "no (the observed executions of this instruction neither read nor write it)"
                verdict = "concrete at this instruction (pass-through)"
            elif f is not None and comp == "jregs":
                observable = "yes (the helper's exit reads its link register)"
                verdict = "genuine (continuation input)"
        rows.append({"component": comp, "detail": detail, "produced": sem.get("produced"), "read": sem.get("read"),
                     "observable": observable, "param": sem.get("param"), "genuine": sem.get("genuine"),
                     "verdict": verdict})
    return rows


def representatives(keys, n=3):
    """Pick up to n representative states of one instruction that differ from the first in different components."""
    if not keys:
        return []
    first = keys[0]
    seen = {}
    for k in keys[1:]:
        sig = tuple(sorted(diff_keys(first, k)))
        seen.setdefault(sig, k)
        if len(seen) >= n:
            break
    return [first] + list(seen.values())


def report(order, stobj, link, facts=None, top=3, pairs=3):
    """For the `top` most duplicated instructions: how many distinct values per component, and the exact
    differences between representative pairs."""
    from collections import defaultdict
    by = defaultdict(list)
    for k, _ in order:
        by[(k[0], k[1])].append(k)
    res = []
    for (m, pc), ks in sorted(by.items(), key=lambda kv: -len(kv[1]))[:top]:
        per = {c: len({k[i] for k in ks}) for i, c in enumerate(COMPONENTS) if i < len(ks[0])}
        reps = representatives(ks, pairs + 1)
        prs = []
        for other in reps[1:]:
            d = diff_keys(reps[0], other, stobj.get(reps[0]), stobj.get(other))
            prs.append({"differs_in": sorted(d), "explain": explain(d, facts, None, (m, pc))})
        res.append({"pc": "%s:%s" % (m, pc), "states": len(ks), "distinct_per_component": per, "pairs": prs})
    return res

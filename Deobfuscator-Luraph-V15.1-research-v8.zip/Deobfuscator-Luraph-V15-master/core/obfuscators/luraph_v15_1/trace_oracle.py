"""Execution-trace oracle for Luraph v15.1 (round 2, phases 3 and 5).

``--debug-v151`` patches every VM dispatch-loop head so the *real* run records
``TAG*2^26 + pc*1024 + opcode`` (the opcode as it is at dispatch time, i.e.
after every in-place decode that happened before it) and every closure entry as
``-proto id``.  The harness writes the list into the dump as ``trace``.

This module turns that into ground truth the lifter can be checked against:

    Oracle.verdict(mode, pc, opcode) ->
        "SAME_OP"        the real run executed this pc in this mode with this opcode
        "DIFFERENT_OP"   it executed this pc in this mode, but with another opcode
                         (the lifter decoded the instruction differently: wrong key / path)
        "NOT_REACHED"    the real run (which may stop early, e.g. at a `:Wait()`)
                         never executed this (mode, pc)
        "NO_TRACE"       no trace in the dump (run without --debug-v151)

It never changes what the lifter does; it only labels evidence.
"""
import json
import os

AID_SHIFT = 1 << 40
TAG_SHIFT = 1 << 34
PC_SHIFT = 1 << 10
KEY_RECORD = 1 << 52


class Oracle:
    """`trace` entries: aid*2^40 + tag*2^34 + pc*2^10 + opcode (a dispatch step of the
    instruction array `aid`), or -proto id (a closure entry).  `aid_of_table` maps the
    dump's table ids to array ids; `proto_arrays` maps a proto key to its candidate
    instruction-array table ids (capture fields A / _)."""

    def __init__(self, trace, mode_of_tag, aid_of_table=None, proto_arrays=None):
        self.trace = list(trace or [])
        self.mode_of_tag = dict(mode_of_tag)
        self.aid_of_table = {str(k): v for k, v in (aid_of_table or {}).items()}
        self.proto_arrays = proto_arrays or {}
        self.executed = {}                  # (aid, mode, pc) -> {opcode: count}
        self.entries = []                   # proto ids in entry order
        self.steps = 0
        self.keyrecs = []                   # (step index, key value) from DEOB_V151_TRACE_KEYS
        self.first_step = {}                # (aid, mode, pc) -> index of first execution
        self.sequence = {}                  # aid -> [(mode, pc, opcode)] in execution order (bounded)
        for i, v in enumerate(self.trace):
            if v < 0:
                self.entries.append(-v)
                continue
            if v >= KEY_RECORD:
                # decode-key record (DEOB_V151_TRACE_KEYS): value of the key local at the preceding step
                self.keyrecs.append((self.steps, v - KEY_RECORD))
                continue
            aid, rest = divmod(v, AID_SHIFT)
            tag, rest = divmod(rest, TAG_SHIFT)
            pc, op = divmod(rest, PC_SHIFT)
            mode = self.mode_of_tag.get(tag, "tag%d" % tag)
            d = self.executed.setdefault((aid, mode, pc), {})
            d[op] = d.get(op, 0) + 1
            self.first_step.setdefault((aid, mode, pc), i)
            seq = self.sequence.setdefault(aid, [])
            if len(seq) < 200000:
                seq.append((mode, pc, op))
            self.steps += 1

    def __bool__(self):
        return bool(self.trace)

    def aids_of(self, proto_key):
        out = set()
        for tid in self.proto_arrays.get(str(proto_key), ()):
            a = self.aid_of_table.get(str(tid))
            if a is not None:
                out.add(a)
        return out

    def ran(self, proto_key):
        """Did the real run execute any instruction of this proto?"""
        aids = self.aids_of(proto_key)
        return any(a in self.sequence for a in aids)

    def verdict(self, mode, pc, opcode, proto_key=None):
        if not self.trace:
            return "NO_TRACE", {}
        aids = self.aids_of(proto_key) if proto_key is not None else None
        if proto_key is not None and not any(a in self.sequence for a in aids):
            return "PROTO_NOT_RUN", {}
        ops = {}
        for (aid, m, p), d in self.executed.items() if aids is None else \
                ((k, self.executed[k]) for a in aids for k in [(a, mode, pc)] if k in self.executed):
            if m == mode and p == pc:
                for o, c in d.items():
                    ops[o] = ops.get(o, 0) + c
        if not ops:
            return "NOT_REACHED", {}
        if opcode in ops:
            return "SAME_OP", {"real_ops": ops}
        return "DIFFERENT_OP", {"real_ops": ops}

    def summary(self):
        return {"steps": self.steps, "entries": len(self.entries), "arrays": len(self.sequence),
                "distinct_pcs": len({(m, p) for _, m, p in self.executed}),
                "modes": sorted({m for _, m, _ in self.executed}, key=str)}


def load(dump_path, mode_of_tag):
    with open(dump_path, encoding="utf-8") as f:
        d = json.load(f)
    pa = {}
    for key, cap in (d.get("protos") or {}).items():
        for name in ("A", "_"):
            ref = cap.get(name)
            if isinstance(ref, dict) and "t" in ref:
                pa.setdefault(str(key), []).append(ref["t"])
    return Oracle(d.get("trace"), mode_of_tag, d.get("vt_aid"), pa)


def mode_of_tag_from_source(root):
    """Loop index (source order, as patchTrace numbers them) -> mode of that dispatcher."""
    from obfuscators.luraph_v15_1 import vmmap as VM
    backs = VM.detect_v151_backend(root)
    disps = VM.find_dispatchers(root)
    by_loc = {}
    for b in backs:
        by_loc[b.dispatcher["node"]["location"]] = b.mode
    return {i: by_loc.get(d["node"]["location"]) for i, d in enumerate(disps)}

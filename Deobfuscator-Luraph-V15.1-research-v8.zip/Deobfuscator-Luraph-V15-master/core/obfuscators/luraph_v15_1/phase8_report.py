"""Phase 8 diagnostics runner: one proto's CFG walk, then the reports the phase asks for.

    python3 -m obfuscators.luraph_v15_1.phase8_report SOURCE DUMP PROTO_KEY OUTDIR [--oracle]

(run from `core/`, same environment variables as the pipeline: DEVIRT_WALK_LIMIT, DEVIRT_PLATEAU, DEVIRT_V151_*).
It walks the proto exactly like the pipeline's final lift does and writes

  convergence.json      states / blocks / pending / dedup hit rate / worklist counters / error causes / depth growth /
                        state-component duplication / helper-summary cache statistics
  state_diff.json       exact differing components between representative states of the most duplicated instructions
                        (state_diff.py), with the produced / read / observable / param / genuine-or-concrete answers
  helper_facts.json     observed read/write behaviour of every executed step of every helper entry, the summaries
                        that were learned and the reasons the others were not
  decode_divergence.json  (with --oracle) first replay failure of the real trace over the lifted CFG, its class
                        (UNEXPLORED_FRONTIER / DECODE_DIFFERS / MISSING_TRANSITION / ...), and for a decode
                        difference the writers (layers) of the cell with the value each one produces

No sample address, register number or opcode is special-cased.  Nothing here changes the walk.
"""
import collections
import json
import os
import sys


def _jd(x):
    return json.dumps(x, default=str, indent=1, sort_keys=True)


def run(source, dump, proto_key, outdir, oracle=False):
    from backend import run_big_stack
    from obfuscators.luraph_v15_1 import devirt as D, retsite as RS, cfg_stats as CS, state_diff as SD
    from obfuscators.luraph_v15_1 import engine_patch as EP
    E = D._E
    os.makedirs(outdir, exist_ok=True)
    res = {}

    def main():
        prog = E.Program(source, dump, [])
        cap = prog.dump.protos[proto_key]
        vm = prog.vm_of(cap)
        proto = vm.proto_of(cap)
        lf = E.ProtoLifter(vm, prog.dump, vm.vmobj_of(cap), proto, E.UpList(), prog.globals)
        st = E.make_stepper(vm, lf)
        s0, order, _ = prog.walk_fixpoint(vm, lf, st, E.WALK_LIMIT)
        info = dict(order.info)
        link = vm.kstack_link
        nodes = dict(order)
        stobj, ins, edges_n = {}, 0, 0
        pending = set()
        for k, n in order:
            for ns in E._node_successors(n):
                try:
                    kk = ns.key(link)
                except Exception:
                    continue
                edges_n += 1
                stobj.setdefault(kk, ns)
                if kk not in nodes:
                    pending.add(kk)
        new_states = len(stobj)
        errs = collections.Counter()
        for k, n in order:
            e = getattr(n, "error", None)
            if e:
                errs[str(e)[:140]] += 1
        rep = RS.report(lf)
        rs = lf.retsites
        conv = {
            "proto": proto_key, "walk_info": {a: b for a, b in info.items() if a != "missing"},
            "states": len(order), "blocks_distinct_instructions": len({(k[0], k[1]) for k, _ in order}),
            "pending_successor_states": len(pending),
            "successor_edges": edges_n, "distinct_successor_states": new_states,
            "dedup_hit_rate": round(1 - new_states / edges_n, 4) if edges_n else None,
            "error_nodes": sum(errs.values()), "error_causes": errs.most_common(12),
            "state_duplication": CS.summary(order, 6),
            "helper_summary": {k: rep.get(k) for k in ("summaries", "summary_hits", "summary_misses", "summary_hit_rate",
                                                         "summary_unusable_link", "summary_cell_signature_misses",
                                                         "summary_rejected")},
            "retsite": {k: v for k, v in rep.items() if k not in ("helpers", "summaries", "summary_rejected")},
            "depth_growth_quarantined": {"%s:%s:%s" % k: v for k, v in EP.DIAG.depth_growth.items()},
            "path_sensitive_overlay": EP.PATHOV, "helper_summaries_on": __import__(
                "obfuscators.luraph_v15_1.helpersum", fromlist=["ON"]).ON,
        }
        res["convergence"] = conv
        res["state_diff"] = SD.report(order, stobj, link, facts=rs.facts, top=4, pairs=3)
        res["helper_facts"] = {
            "steps": {"%s:%s" % k: {"n": f["n"], "pure": f["pure"], "why": f["why"], "exit": f["exit"], "op": f["op"],
                                    "cell_signatures_observed": len(f["sigs"]), "self_modifying_passes": f["wrote"]}
                      for k, f in sorted(rs.facts.items())},
            "summaries": {"%s:%s" % k: {a: b for a, b in v.items()} for k, v in rs.summaries.items()},
            "rejected": {"%s:%s" % k: v for k, v in rs.rejected.items()},
        }
        if oracle:
            res["decode_divergence"] = _replay(prog, vm, lf, order, nodes, pending, proto_key, source, dump, E)

    run_big_stack(main)
    for name, doc in res.items():
        with open(os.path.join(outdir, name + ".json"), "w") as f:
            f.write(_jd(doc))
    return res


def _replay(prog, vm, lf, order, nodes, pending, proto_key, source, dump, E):
    """Frontier replay of the real trace over the lifted CFG: the first real step the lifted graph cannot follow."""
    from obfuscators.luraph_v15_1 import trace_oracle as TO, vmmap as VM, opcode_maps as OM
    from obfuscators.luraph_v15_1 import engine_patch as EP
    root = VM.load_ast(source)
    orc = TO.load(dump, TO.mode_of_tag_from_source(root))
    aids = sorted(orc.aids_of(proto_key))
    if not aids:
        return {"error": "no runtime activation of this proto in the trace"}
    rseq = orc.sequence[aids[0]]
    col = []
    for m, p, o in rseq:
        if col and col[-1][0] == m and col[-1][1] == p:
            col[-1] = (m, p, o)
        else:
            col.append((m, p, o))
    mpk = OM.load(source)
    kind = {}
    for m_, x_ in mpk.items():
        for sp in x_.handlers():
            kind[(m_, sp.opcode)] = sp.kind
    from obfuscators.luraph_v15_1 import conformance as CF
    with open(source, encoding="latin-1") as fh:
        lines = fh.read().split("\n")
    scrub = CF.scrub_map(mpk, lines, lambda blk: VM.text_of(lines, blk))
    opof = {k: getattr(n, "op", None) for k, n in order}
    bypc = collections.defaultdict(list)
    for k, _ in order:
        bypc[(k[0], k[1])].append(k)

    def same(m, real, lift):
        return real == lift or scrub.get((m, real)) == lift
    realpcs = {(m, p) for m, p, o in col}
    out = {"real_steps": len(col), "real_distinct_pcs": len(realpcs),
           "real_pcs_covered_by_lifted_cfg": len(realpcs & set(bypc)),
           "lifted_pcs_not_in_real_run": len(set(bypc) - realpcs)}
    rsx = lf.retsites
    front = {k for k in bypc.get((col[0][0], col[0][1]), []) if opof.get(k) and opof[k][1] == col[0][2]}
    idx, failed = 1, None
    while idx < len(col):
        m, p, o = col[idx]
        skip = [k for k in front if any((a_[0], a_[1]) == (m, p) for a_ in rsx.sum_apps.get(k, ()))]
        if skip:
            ex = [a_[2] for k in skip for a_ in rsx.sum_apps[k] if (a_[0], a_[1]) == (m, p)][0]
            while idx < len(col) and col[idx][1] != ex:
                idx += 1
            idx += 1
            if idx >= len(col):
                break
            m, p, o = col[idx]
        nxt = set()
        for k in front:
            for nk in prog.edges.get(k, ()):
                if nk[0] == m and nk[1] == p and opof.get(nk) and same(m, o, opof[nk][1]):
                    nxt.add(nk)
        if not nxt:
            failed = idx
            break
        front = nxt
        idx += 1
    out["replayed_real_steps"] = idx if failed is None else failed
    out["first_failure_step"] = failed
    if failed is None:
        out["classification"] = "REPLAY_COMPLETE"
        return out
    m, p, o = col[failed]
    out["failing_real_step"] = {"mode": m, "pc": p, "real_opcode": o}
    out["context"] = col[max(0, failed - 6):failed + 2]
    pcs_front = sorted({k[1] for k in front})
    succ_all = set()
    for k in front:
        succ_all |= set(prog.edges.get(k, ()))
    unexplored = [nk for nk in succ_all if nk not in nodes]
    at_target = [nk for nk in succ_all if nk[0] == m and nk[1] == p]
    out["frontier_pcs"] = pcs_front[:12]
    out["frontier_successors"] = len(succ_all)
    out["frontier_successors_unexplored"] = len(unexplored)
    if at_target:
        ops = sorted({str(opof.get(nk)) for nk in at_target if nk in nodes})
        out["classification"] = "DECODE_DIFFERS" if ops else "UNEXPLORED_FRONTIER"
        out["lifter_ops_at_target"] = ops
        W = EP.DIAG.writes
        cells = {}
        for (pk, idx_), slot in W.items():
            if idx_ == p and str(pk) == "1" or (idx_ == p and str(pk) == str(proto_key)):
                cells = {a: [(str(x.get("writer")), str(x.get("new"))) for x in v] for a, v in slot.items()}
        out["writers_of_failing_cell"] = cells
    elif unexplored:
        out["classification"] = "UNEXPLORED_FRONTIER"
        out["note"] = "the lifted CFG has a successor edge towards this point that was never stepped (pending work)"
    else:
        out["classification"] = "MISSING_TRANSITION"
        out["note"] = "every successor of the frontier was stepped and none reaches the real next instruction"
    return out


if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    if len(a) != 4:
        sys.exit(__doc__)
    r = run(a[0], a[1], a[2], a[3], oracle="--oracle" in sys.argv)
    c = r["convergence"]
    print("states", c["states"], "pending", c["pending_successor_states"], "dedup_hit_rate", c["dedup_hit_rate"],
          "closed", c["walk_info"].get("closed"), "stop", c["walk_info"].get("final_stop"))
    if "decode_divergence" in r:
        d = r["decode_divergence"]
        print("replay", d.get("replayed_real_steps"), "/", d.get("real_steps"), d.get("classification"))

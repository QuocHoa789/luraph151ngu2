"""Evidence-based opcode semantics for Luraph v15.1 (round 2, phase 7).

`opcode_maps` classifies a handler from the *shape of its source* with weak rules (a
"MOVE" there is "a plain store").  That is a hypothesis.  This module only names an
opcode when the *behaviour the lifter observed* supports the name:

  for every (mode, opcode) the lifted instructions (IR trees of the finished walks) are
  reduced to a *shape* (what is written where, from what kind of value; calls; branch
  conditions; return / fall-through).  An opcode gets a semantic name only if

    * it was lifted at least MIN_SAMPLES times, and
    * one shape accounts for at least DOMINANT of the samples, and
    * that shape has a rule below.

  Otherwise it is `UNKNOWN` (never guessed) and the report says why.  The real behaviour
  trace adds `real_samples` (how often the real run executed that opcode) and, when the
  static kind from opcode_maps disagrees with the observed behaviour, `agrees_with_static`
  is false and the confidence is reduced - a disagreement is reported, not hidden.
"""
from collections import Counter

MIN_SAMPLES = 3
DOMINANT = 0.9

# shape token -> semantic name (single-write shapes)
_WRITE_RULES = {
    "R<-const": "LOADK",
    "R<-reg": "MOVE",
    "R<-index": "GETTABLE",
    "R<-upval": "GETUPVAL",
    "R<-global": "GETGLOBAL",
    "R<-closure": "CLOSURE",
    "R<-newtable": "NEWTABLE",
    "R<-call-result": "CALL_RESULT",
    "U<-reg": "SETUPVAL",
    "U<-const": "SETUPVAL",
}


def _value_token(v, E):
    if isinstance(v, E.Const):
        return "const"
    if isinstance(v, E.Reg):
        return "reg"
    if isinstance(v, E.Bin):
        return "bin:" + str(v.op)
    if isinstance(v, E.Un):
        return "un:" + str(v.op)
    if isinstance(v, E.Index):
        return "index"
    if isinstance(v, E.Upval):
        return "upval"
    if isinstance(v, E.Global):
        return "global"
    if isinstance(v, E.TempVal):
        return "call-result"
    if isinstance(v, E.ClosureExpr):
        return "closure"
    if isinstance(v, E.S.NewTable):
        return "newtable"
    return type(v).__name__


def shape_of(node, E):
    """Sorted tuple of tokens describing everything an instruction's IR tree does."""
    toks = set()
    stack = [node]
    while stack:
        n = stack.pop()
        if n is None:
            continue
        for st in n.stmts:
            if isinstance(st, E.Assign):
                tgt = st.target
                if isinstance(tgt, E.Reg):
                    if tgt.n >= 900000:                    # virtual key register (engine bookkeeping)
                        continue
                    toks.add("R<-" + _value_token(st.value, E))
                elif isinstance(tgt, E.Upval):
                    toks.add("U<-" + _value_token(st.value, E))
                else:
                    toks.add("%s<-%s" % (type(tgt).__name__, _value_token(st.value, E)))
            elif isinstance(st, E.CallStmt):
                toks.add("call:" + (st.fn.name if isinstance(st.fn, E.Global) else "reg"))
            else:
                toks.add(type(st).__name__)
        if n.cond is not None:
            c = n.cond
            toks.add("cond:" + (str(c.op) if isinstance(c, E.Bin) else type(c).__name__))
            stack.append(n.then)
            stack.append(n.els)
        elif isinstance(n.outcome, E.Ret):
            toks.add("return")
        elif isinstance(n.outcome, E.Next):
            toks.add("next")
    return tuple(sorted(toks))


class Semantic:
    __slots__ = ("mode", "opcode", "name", "confidence", "evidence", "samples", "shapes", "static_kind",
                 "agrees_with_static", "real_samples")

    def as_dict(self):
        return {k: getattr(self, k) for k in self.__slots__}


def name_of_shape(shape):
    """Semantic name for a dominant shape, or None.  Only shapes that say what the
    instruction does on their own are named; a shape that needs the operand values to be
    understood stays unnamed."""
    s = [t for t in shape if t != "next"]
    if "return" in shape and len(s) == 1:
        return "RETURN"
    if len(s) == 0:
        return "NOP"                                        # nothing observable: decode / prologue effect only
    if len(s) == 1:
        t = s[0]
        if t in _WRITE_RULES:
            return _WRITE_RULES[t]
        if t.startswith("R<-bin:"):
            return "BINOP_" + t[len("R<-bin:"):].upper()
        if t.startswith("R<-un:"):
            return "UNOP_" + t[len("R<-un:"):].upper()
        if t.startswith("call:"):
            return "CALL" if t == "call:reg" else "CALL_" + t[5:].upper()
        if t.startswith("cond:Compare"):
            return "TEST_" + t[len("cond:Compare"):].upper()
        if t == "cond:Reg":
            return "TEST"
    if len(s) == 2 and "call:reg" in s and any(x in ("R<-call-result",) for x in s):
        return "CALL"
    return None


_STATIC_COMPAT = {
    "RETURN": {"RETURN"},
    "MOVE": {"MOVE", "LOADK", "GETUPVAL", "GETGLOBAL", "GETTABLE", "SETUPVAL", "NOP", "NEWTABLE", "CLOSURE"},
    "ARITH": None,                                          # any BINOP_/UNOP_
    "CALL": {"CALL", "CALL_RESULT"},
    "CLOSURE": {"CLOSURE"},
    "NEWTABLE": {"NEWTABLE"},
    "COMPARE": None,
    "COND_JUMP": None,
}


def _agrees(static_kind, name):
    if static_kind is None or name is None:
        return None
    if static_kind in ("UNKNOWN", "EXPAND", "MODE_SWITCH", "JUMP", "BLOB_DECRYPT", "SELF_REWRITE"):
        return None
    ok = _STATIC_COMPAT.get(static_kind, "other")
    if ok == "other":
        return None
    if ok is None:
        if static_kind == "ARITH":
            return name.startswith(("BINOP_", "UNOP_"))
        if static_kind == "COMPARE":
            return name.startswith("TEST")
        if static_kind == "COND_JUMP":
            return name.startswith("TEST")
        return None
    return name in ok


class Collector:
    def __init__(self):
        self.reset()

    def reset(self):
        self.shapes = {}                # (mode, opcode) -> Counter(shape)

    def observe(self, mode, opcode, node, E):
        if not isinstance(opcode, int) or isinstance(opcode, bool) or getattr(node, "error", None):
            return
        try:
            self.shapes.setdefault((mode, opcode), Counter())[shape_of(node, E)] += 1
        except Exception:
            pass

    def semantic(self, mode, opcode, static_kind=None, real_samples=0):
        c = self.shapes.get((mode, opcode))
        sp = Semantic()
        sp.mode, sp.opcode, sp.static_kind, sp.real_samples = mode, opcode, static_kind, real_samples
        sp.name, sp.confidence, sp.agrees_with_static = "UNKNOWN", 0.0, None
        if not c:
            sp.samples, sp.shapes = 0, []
            sp.evidence = ["never lifted"]
            return sp
        n = sum(c.values())
        shape, top = c.most_common(1)[0]
        sp.samples = n
        sp.shapes = [{"shape": list(s), "count": k} for s, k in c.most_common(4)]
        if n < MIN_SAMPLES:
            sp.evidence = ["only %d lifted sample(s) (need %d)" % (n, MIN_SAMPLES)]
            return sp
        if top / n < DOMINANT:
            sp.evidence = ["no dominant shape: %s" % ", ".join("%d x %s" % (k, "+".join(s) or "-") for s, k in c.most_common(3))]
            return sp
        name = name_of_shape(shape)
        if name is None:
            sp.evidence = ["dominant shape %s has no semantic rule" % ("+".join(shape) or "-")]
            return sp
        sp.name = name
        conf = 0.5 + 0.1 * min(n, 5)
        if real_samples:
            conf += 0.1
        sp.agrees_with_static = _agrees(static_kind, name)
        if sp.agrees_with_static is False:
            conf = min(conf, 0.4)
        sp.confidence = round(min(conf, 0.95), 2)
        sp.evidence = ["%d of %d lifted samples reduce to %s" % (top, n, "+".join(shape) or "-")]
        if real_samples:
            sp.evidence.append("executed %d time(s) by the real run" % real_samples)
        if sp.agrees_with_static is False:
            sp.evidence.append("static kind %s disagrees with the observed behaviour" % static_kind)
        return sp


COLLECTOR = Collector()


def semantic_of(mode, opcode, mappers=None):
    """Semantic of (mode, opcode) from what was observed; static kind only for the cross-check."""
    kind = None
    try:
        sp0 = (mappers or {}).get(mode).get(opcode)
        kind = sp0.kind if sp0 is not None else None
    except Exception:
        pass
    return COLLECTOR.semantic(mode, opcode, kind)


def report(mappers, oracle=None):
    """Semantic evidence report: one row per (mode, opcode) lifted at least once."""
    real = Counter()
    if oracle:
        for (_aid, mode, _pc), d in oracle.executed.items():
            for op, cnt in d.items():
                real[(mode, op)] += cnt
    rows = []
    for (mode, op) in sorted(COLLECTOR.shapes, key=lambda x: (str(x[0]), x[1])):
        sp = semantic_of(mode, op, mappers)
        sp.real_samples = real.get((mode, op), 0)
        sp = COLLECTOR.semantic(mode, op, sp.static_kind, sp.real_samples)
        rows.append(sp.as_dict())
    named = sum(1 for r in rows if r["name"] != "UNKNOWN")
    return {"opcodes_lifted": len(rows), "named": named, "unknown": len(rows) - named,
            "disagree_with_static": sum(1 for r in rows if r["agrees_with_static"] is False),
            "rows": rows}

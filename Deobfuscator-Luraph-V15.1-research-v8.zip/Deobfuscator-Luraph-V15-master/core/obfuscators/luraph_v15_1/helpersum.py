"""Helper summaries (phase 8): outlined helpers that are pure pass-through transfers.

WHAT THE SAMPLE'S "HELPER" IS (source-derived, see V15.1-PHASE8.md)
    The phase-6/7 return-site abstraction treats 239:13794..13803 as a subroutine that
    is called from thousands of places and returns through `pc = r62 + c`.  Measured on
    the real run, its ten instructions neither read nor write a VM register, a decode-key
    local, a pack, a carried local or the loop stack: it is a trampoline.  What it does
    to the *caller state* is exactly "pc := link + c".  Stepping it once per caller
    state (exact clones) multiplies states by the number of distinct caller contexts;
    abstracting the link into a token (phase 6) makes the exit a dispatch over a growing
    table, i.e. a continuation the exit state cannot tell apart from the other callers'.

THE SUMMARY
    inputs   : the link register (the only jump register read), nothing else
    outputs  : the continuation pc (link + off) and the jump registers the exit consumed
    effects  : none on registers, keys, packs, locals, loop stack, instruction overlay
               (its own first-execution decode runs once, in the exact first traversal
               that the summary is learned from, and is already applied to the shared
               overlay / buffers by then)
    pipeline : caller state --extract link--> summary --> continuation state
    The summary is learned from steps the engine actually executed (read/write sets are
    observed, not assumed) and is only created when EVERY observed step of the chain was
    pure.  A helper that fails any criterion keeps the bounded context-sensitive token
    abstraction and the reason is reported (`rejected`).

No sample address or register number appears here.
"""

import os

ON = os.environ.get("DEVIRT_V151_HELPERSUM", "1") not in ("0", "")
_PATHOV = os.environ.get("DEVIRT_V151_PATHOV", "1") not in ("0", "")   # overlay travels in the state: a helper that writes instruction cells is not a pure summary
MAX_CHAIN = int(os.environ.get("DEVIRT_V151_SUM_CHAIN", "64") or 64)


def _int(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _affine(x):
    from obfuscators.luraph_v15_1.retsite import affine
    return affine(x)


def _facts(rs, mode, pc):
    return rs.facts.setdefault((mode, pc), {"n": 0, "pure": True, "why": None, "exit": None, "drop": None, "op": None,
                                             "sigs": set(), "wrote": 0})


_MISSING = object()


def cell_sig(lf, ov, pc):
    """What the instruction overlay says about the cells of instruction `pc` (pristine cells are constants of the
    program, so only overlay entries distinguish two states): the decode of `pc` is a function of this."""
    arrays = getattr(lf, "proto_arrays", None) or ()
    if ov is None:
        return ()
    out = []
    for a in sorted(arrays):
        v = ov.get((a, pc), _MISSING)
        if v is not _MISSING:
            out.append((a, repr(v)))
    return tuple(out)


def note_step(lf, rs, state, ns, keys, kvals, nstmts, ndec, link):
    """Record the read/write behaviour of one executed step (state -> ns, `ns` before link tokenisation)."""
    if not ON or state is None or ns is None:
        return
    mode, pc = state.mode, state.pc
    if not (_int(mode) and _int(pc)):
        return
    if not (_int(ns.pc) and _int(ns.mode)) and _int(ns.mode) and _affine(ns.pc) is not None:
        return                                            # `pc = reg + c` the walk could not resolve (token exit / register not
                                                          # tracked yet): no evidence either way
    f = _facts(rs, mode, pc)
    f["n"] += 1
    op = getattr(lf, "last_op", None)
    f["op"] = tuple(op) if op else None
    why = None
    wrote = False
    jin, jout = dict(state.jregs), dict(ns.jregs)
    links = getattr(lf, "link_regs", None) or ()
    jread = set(getattr(lf, "jread", ()) or ())
    exit_ = None
    if nstmts:
        why = "emits %d IR statement(s) (register/table/call effects)" % nstmts
    elif ndec:
        why = "data-dependent branch"
    elif not (_int(ns.pc) and _int(ns.mode)):
        why = "symbolic successor"
    elif getattr(lf, "mutated", False) and ns.pc == pc:
        why = "in-place instruction expansion"
    elif keys != getattr(state, "keys", ()):
        why = "changes decode keys"
    elif kvals != getattr(state, "kvals", ()):
        why = "changes tracked register constants"
    elif ns.packs != state.packs:
        why = "changes register packs"
    elif ns.locs != state.locs:
        why = "changes carried locals"
    elif ns.kstack is not state.kstack and ns.kstack != state.kstack:
        why = "changes the loop stack"
    else:
        arrays = getattr(lf, "proto_arrays", None) or ()
        ov = lf.ov.d if getattr(lf, "ov", None) is not None else {}
        for k in ov:
            if isinstance(k, tuple) and len(k) == 2 and k[0] in arrays and (k[1] != pc or _PATHOV):
                wrote = True                      # a one-shot self-modification (first-execution decode): not evidence of purity,
                break                             # but it must not poison the passes that run on the already-decoded cells
    if why is None:
        for r, v in jout.items():
            if r not in jin or jin[r] != v:
                why = "defines a jump register"
                break
    if why is None:
        cand = [r for r in jread if r in links and _int(jin.get(r))]
        if len(cand) == 1 and ns.pc != pc + 1:
            r = cand[0]
            exit_ = (r, ns.pc - jin[r], ns.mode, tuple(sorted(set(jin) - set(jout))))
        elif cand:
            why = "reads %d link registers" % len(cand)
        elif ns.mode != mode or ns.pc != pc + 1:
            why = "non-sequential transfer without a link register"
        else:
            drop = tuple(sorted(set(jin) - set(jout)))
            if drop:
                why = "consumes jump registers"
    if why is None and wrote:
        f["wrote"] += 1
        return
    new_sig = False
    if why is None:
        sig = cell_sig(lf, state.ov, pc)
        new_sig = sig not in f["sigs"]
        f["sigs"].add(sig)
    if why is not None:
        f["pure"] = False
        f["why"] = f["why"] or why
        return
    if exit_ is not None:
        if f["exit"] is not None and f["exit"] != exit_:
            f["pure"] = False
            f["why"] = "inconsistent exit form"
            return
        first = f["exit"] is None
        f["exit"] = exit_
        if first or new_sig:
            try_all(lf, rs)
    elif new_sig:
        try_all(lf, rs)                                   # a pass on newly decoded cells can complete a pending chain


def try_all(lf, rs):
    for ent in sorted(rs.entries_seen):
        if ent in rs.summaries or ent in rs.rejected:
            continue
        try_summarize(lf, rs, ent)


def try_summarize(lf, rs, ent):
    mode, pc = ent
    chain = []
    for _ in range(MAX_CHAIN):
        f = rs.facts.get((mode, pc))
        if f is None:
            return None                                   # not traversed yet: try again later
        if not f["pure"]:
            rs.rejected[ent] = "step %s:%s is not pure: %s" % (mode, pc, f["why"])
            return None
        if not f["sigs"]:
            return None                                   # only self-modifying passes observed so far: try again later
        chain.append(pc)
        if f["exit"] is not None:
            r, off, emode, drop = f["exit"]
            rs.summaries[ent] = {"entry": ent, "exit_pc": pc, "reg": r, "off": off, "exit_mode": emode,
                                 "drop": drop, "chain": chain, "observed_steps": sum(rs.facts[(mode, p)]["n"] for p in chain)}
            return rs.summaries[ent]
        pc += 1
    rs.rejected[ent] = "no exit within %d steps" % MAX_CHAIN
    return None


def apply(lf, rs, state, ns, ent, jr, link):
    """Replace the entered helper state `ns` by the caller's continuation.  -> True if applied."""
    summ = rs.summaries.get(ent)
    if summ is None:
        return False
    K = jr.get(summ["reg"])
    if not _int(K):
        rs.sum_unusable += 1
        return False
    ov = getattr(ns, "ov", None)
    mode = ent[0]
    for cpc in summ["chain"]:
        if cell_sig(lf, ov, cpc) not in rs.facts[(mode, cpc)]["sigs"]:
            rs.sum_sig_miss += 1     # the helper's cells are not in a decode the summary was observed on
            return False
    ns.pc = K + summ["off"]
    ns.mode = summ["exit_mode"]
    for r in summ["drop"]:
        jr.pop(r, None)
    ns.jregs = tuple(sorted(jr.items(), key=lambda kv: kv[0]))
    rs.sum_hits += 1
    try:
        src = state.key(link) if state is not None else None
    except Exception:
        src = None
    if src is not None:
        rs.sum_apps.setdefault(src, set()).add((ent[0], ent[1], summ["exit_pc"]))
    return True

"""Luraph v15.1 devirtualization entry point.

The symbolic lifter is the shared v15 engine, loaded as a *private copy*
bound to the v15.1 mapper (see engine.py); the v15 module is not modified or
imported here.  Recovery ceilings are raised a little for 15.1's larger
dispatcher graphs (override with the usual DEVIRT_* environment variables).
"""
import os

_DEFAULTS = {
    "DEVIRT_WALK_LIMIT": "450000",
    "DEVIRT_MAX_STATES": "1800000",
    "DEVIRT_RECOVERY_LIMIT": "350000",
    "DEVIRT_MAX_RECOVERY_ROUNDS": "24",
    "DEVIRT_RECOVERY_STALL": "20000",
}
for _k, _v in _DEFAULTS.items():
    os.environ.setdefault(_k, _v)

from obfuscators.luraph_v15_1 import engine as _engine  # noqa: E402

_E = _engine.load()
globals().update({k: v for k, v in vars(_E).items() if not (k.startswith("__") and k.endswith("__"))})
ENGINE = _E

# Luraph v15.1 backend

Status: **PARTIAL** (see `V15.1-STATUS.md` for the measured result). V15 is untouched.

## Pipeline

```
detector ─► bootstrap locator ─► (dynamic harness: the script's own bootstrap decodes the stream)
        ─► dispatcher detection (vmmap.py: 4 direct + 4 predicate-form dispatch loops)
        ─► per-mode opcode map (opcode_maps.py: OpcodeSpec per (mode, opcode); never guessed)
        ─► instruction normalisation (ir_bridge.py: NEXT/JUMP/COND_JUMP/RETURN/CALL/ADVANCE(n)/MODE_SWITCH/EXPAND_AND_REEXECUTE)
        ─► dynamic instruction expansion (instruction_expander.py, bounded + cycle-detected)
        ─► closure / proto recovery (closure.py)
        ─► shared v15 lifter / CFG / SSA / printer (private engine copy, engine.py + engine_patch.py)
```

| module | role |
|---|---|
| `vmmap.py` | finds every dispatcher (`direct`: `if op<K` tree; `predicate`: `local p=op<K ... if p then`), both maker layouts (14-param legacy-shaped, 16-param new), `detect_v151_backend(ast)`, handler resolution per opcode, instrumentation patch |
| `opcode_maps.py` | `get_opcode_mapper(mode, mappers)`; `OpcodeSpec(mode, opcode, kind, pc_effect, advance, operands, features, confidence, source)`; shared leaves such as `if S<75 … elseif S~=76 … else …` are **specialised per opcode** |
| `bootstrap.py` | locates VM table, entry method (`ZV`), step methods, blob (`LPH$…`, 977 820 chars), helper slots; reports a confidence |
| `stream_decoder.py` | `DumpStreams` (decoded instruction arrays from the harness dump) and `decrypt_blob` (the in-place BLOB_DECRYPT handler, exact; test runs the real handler under Luau and compares) |
| `instruction_expander.py` | records decode-in-place + re-execute events; bounds `DEVIRT_MAX_REEXEC_PER_PC` (128), `DEVIRT_MAX_EXPANSIONS` (2 000 000) |
| `closure.py` | closure graph (`P`/`pq` from the dump, plus edges recorded while lifting); `DEVIRT_MAX_CLOSURE_NODES` |
| `ir_bridge.py` | `NormInstr`, `V151_UNKNOWN(mode, opcode, operands)` diagnostic statement |
| `engine.py` / `engine_patch.py` | private copy of the v15 `devirt.py` + v15.1 specialisations (factory resolution, wide buffer ops through the byte overlay, restart replay of XOR decryptors, `MAX_RANGE` bounds). The v15 module is never modified or monkey-patched |
| `debug_report.py` | `--debug-v151` output |

## `--debug-v151`

```
node deob.js sample/v15.1/sa-obfuscated.lua.txt -o out.lua --debug-v151        # full run, report after lifting
node deob.js sample/v15.1/sa-obfuscated.lua.txt --no-devirt --debug-v151       # static part only
python3 core/obfuscators/luraph_v15_1/debug_report.py FILE [DUMP.protos.json]  # standalone
```
Lines: `detected`, `backend mode`, `dispatcher`, `opcode count`, `bootstrap`, `stream decoded`, `closures recovered`, `expansions`, `unknown opcodes`, `closures lifted`, `IR instructions`. Values the lifter did not produce in the current process are printed as `n/a`, never invented.

## Where this implementation differs from the original task text (source wins)

1. *"stream decoder after bootstrap parser"*: the stream is produced by a per-script state machine in the script itself; it is **not** re-implemented offline (it is regenerated per obfuscation). The harness runs the real bootstrap and the decoded arrays are read from its dump. Only the run-time in-place blob decryption is implemented statically.
2. *"4 legacy dispatchers have no modes"*: they do (`73/97/239/56`, mode variable switched with `break`).
3. *"proto = maker's second argument"*: false; a proto is the table of **all** maker parameters and a closure is made in two steps (maker → factory → VM closure, `w[i](W,nil,nil)`).
4. Decrypt handlers are **non-idempotent XOR layers**; walk restarts must replay from the initial state (done in `engine_patch._walk`).
5. Only the legacy-shaped VM (mode 73 first) ever runs for the sample; the 4 predicate-form dispatchers are mapped and classified but executed only if a proto reaches them.

## SAMPLE-SPECIFIC HEURISTICS
`opcode_maps.RULES/classify` (kind rules over handler features), `bootstrap.KEY_CONSTANTS` (54337324, 16843009, 536870911), `stream_decoder.OFFSET_KEY/STRIDE_KEY`, and handler variable names in `tests/test_v151.py::DecryptMatchesHandler`. A different v15.1 build may need them revisited; classifications carry a confidence < 1 for that reason.

## Known gaps
See `V15.1-STATUS.md` ("Remaining").


## Round 2 additions

* `dataflow.py`, `conformance.py`, `semantics.py`, `validator.py`, `gate.py` (new): key-register data flow, trace
  conformance replay, evidence-based opcode semantics, verdict model, gate/report writer.
* `engine_patch.py`: decode-key local carrying (`State151`, `_Acc151`), pending/symbolic keys, lowering budget and
  memory guard; `driver.py`: emits final Luau only on PASS, caps the address space (`DEOB_V151_MEM_MB`).
* Environment knobs: `DEVIRT_V151_KVALS` (tracked register constants, default off), `DEVIRT_LOWER_BUDGET`,
  `DEVIRT_LOWER_BLOCKS`, `DEVIRT_PLATEAU`, `DEOB_V151_MEM_MB`, `DEOB_V151_NO_TRACE_REQUIRED`, `DEOB_KEEP_PARTIAL`.
* Remaining blocker (return-address cloning of outlined helpers) and measured numbers: `V15.1-STATUS.md`.

## Phase 6 knobs
| Variable | Default | Meaning |
|---|---|---|
| `DEVIRT_V151_RETSITE` | on | return-site abstraction for outlined helpers (`retsite.py`) |
| `DEVIRT_V151_RETSITE_MIN` | 12 | per helper ENTRY: a helper with at most this many distinct tuples of live link-register constants is cloned exactly; only larger ones are abstracted (phase 7: the bound is per entry, not per register) |
| `DEVIRT_V151_RETCTX` | on | return tokens/tables are keyed by the helper entry's non-link context (phase 7); `0` = v6 keying, ablation only |
| `DEVIRT_V151_DEFER` | on | record newly found jump/link/pack-unstable registers and restart once after `DEVIRT_V151_DEFER_SLACK` more states instead of once per register |
| `DEVIRT_V151_DEFER_SLACK` | 1500 | states the walk continues after the first deferred discovery |
| `DEVIRT_V151_MAX_UNPACK` | 1024 | an `unpack` of the register file longer than this is an unresolved node (infeasible decode), never materialised; `0` = off |
| `DEVIRT_V151_DEPTH_WIDEN` | 0 (off) | saturate the loop-stack depth component of the state key at N |
| `DEVIRT_V151_HELPERSUM` | on | helper summaries (`helpersum.py`, phase 8): a helper whose every observed step is pure (no register / key / pack / local / loop-stack / instruction-cell effect) is replaced at its call by the caller's continuation; `0` = ablation |
| `DEVIRT_V151_SUM_CHAIN` | 64 | longest helper chain a summary may cover |
| `DEVIRT_V151_PATHOV` | on | the instruction-array overlay (in-place decryptor writes) travels IN the state and is part of its identity instead of one flow-insensitive global overlay; `0` = v7 behaviour, ablation only |
| `DEVIRT_V151_ORDER` | novel | worklist order of the walk: `lifo` (v15 depth first), `fifo` (breadth first), `novel` (LIFO, never-visited instruction first); the fixed point is order independent, the budget-limited result is not |
| `DEVIRT_V151_NOVEL_WINDOW` | 512 | how many of the newest worklist entries `novel` inspects |
| `DEVIRT_V151_DEPTH_CAP` | 24 | quarantine of an unbounded loop-stack push loop: more distinct depths than this for one state shape are not stepped (error node, reported in `depth_growth`); `0` = off |
| `DEOB_V151_TRACE_KEYS` | off | harness records the decode-key locals into the trace (diagnostic keys `2^52 + key`) |
| `DEVIRT_V151_PERSIST` | on | keep what a walk learned (jump/link registers, carried locals) across restarts and lifts in one process |
| `DEVIRT_LOWER_BLOCKS` | 12000 | lowering block ceiling (a safeguard; reported as PARTIAL, never silent truncation) |

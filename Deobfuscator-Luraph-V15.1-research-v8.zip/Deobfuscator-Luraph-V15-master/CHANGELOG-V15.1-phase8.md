# Changelog — V15.1 phase 8 (research-v8)

Baseline: research-v7. Verdict of the sample: PARTIAL (unchanged). V15 protected files: byte-identical (hash log in
`research/phase8/logs/v15_hash_comparison.log`).

## Fixed
* **Flow-insensitive instruction overlay** (`engine_patch.py`, `DEVIRT_V151_PATHOV`, default on): the in-place decryptor writes
  travel in `State.ov` and are part of the state identity; the stepper's global overlay is a read-through proxy of the state
  being stepped. Before: a decryptor that only runs later in the real program was applied to earlier cells (cell 5683 decoded
  114 instead of 65).
* **Overlay identity by `id()`** (`engine.py` PATCHES): symbolic values stored into instruction arrays are identified by
  structure; a loop re-storing the same expression no longer creates a new state per iteration.
* **Helper summary poisoned by a one-shot self-decode** (`helpersum.py`): a pass that writes instruction cells is recorded
  apart and is neither evidence of purity nor of impurity; application requires the helper's cells to be in a decode the
  summary was observed pure on (`cell_sig`).
* **Conformance** (`conformance.py`): scrub equivalence in both directions (first activation = decryptor, later activation =
  decoded no-op), still reported apart from the strict `ratio`; `ratio_all_real_steps` for runs with summaries.

## Added
* `helpersum.py` — helper summaries from observed read/write sets (`DEVIRT_V151_HELPERSUM`, `DEVIRT_V151_SUM_CHAIN`).
* `state_diff.py` — exact differing components between states, with produced/read/observable/param/genuine answers.
* `phase8_report.py` — convergence, state-diff, helper-facts and decode-divergence (real-trace frontier replay) reports.
* Worklist order policy `DEVIRT_V151_ORDER` (`lifo`/`fifo`/`novel`, default `novel`), `DEVIRT_V151_NOVEL_WINDOW`.
* Loop-stack growth quarantine `DEVIRT_V151_DEPTH_CAP` (24; reported in `depth_growth`, never silent).
* Return-token context includes decode keys / tracked constants (`lf.v151_frame`) and, through the state key, the overlay.
* Harness diagnostic `DEOB_V151_TRACE_KEYS` (decode-key records in the trace).
* Tests: `tests/test_v151_phase8.py` (19), `test_v151_phase8b.py` (19), `test_v151_phase8c.py` (16).
* Docs: `V15.1-PHASE8.md`, `TEST-RESULTS-V15.1-phase8.md`, `research/phase8/` (logs, reports, probes, metrics, hashes).

## Not changed
`core/obfuscators/luraph_v15/{__init__,devirt,driver,vmmap}.py`, shared `core/{backend,codegen,structure,ir,luasym}.py`,
installer / Termux setup, validator rules.

## Known remaining
The proto-1 CFG still does not close inside the 15 000-state walk limit (587 pending, `diverging`); no devirtualized source is
emitted. See `V15.1-PHASE8.md` §10.
